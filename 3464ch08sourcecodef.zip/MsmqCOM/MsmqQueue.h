/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#ifndef __MSMQQUEUE_H_
#define __MSMQQUEUE_H_

//
//  Includes
//
#include "resource.h"       // main symbols


//-------------------------------------------------------------------------------
//	Class:	CMsmqQueue
//
//	This class implements IMSMQQueue
//-------------------------------------------------------------------------------
class ATL_NO_VTABLE CMsmqQueue : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMsmqQueue, &CLSID_MSMQQueue>,
	public IDispatchImpl<IMSMQQueue, &IID_IMSMQQueue, &LIBID_MSMQ>
{
public:
    //-------------------------------------------------------------------------------
    //	C++ and ATL construtor and destructors
    //-------------------------------------------------------------------------------
	CMsmqQueue();

    HRESULT     FinalConstruct();
    void        FinalRelease();

    //-------------------------------------------------------------------------------
    //	ATL Interface Map and class declarations
    //-------------------------------------------------------------------------------
	BEGIN_COM_MAP(CMsmqQueue)
		COM_INTERFACE_ENTRY(IMSMQQueue)
		COM_INTERFACE_ENTRY(IDispatch)
	END_COM_MAP()

	DECLARE_REGISTRY_RESOURCEID(IDR_MSMQQUEUE)
	DECLARE_PROTECT_FINAL_CONSTRUCT()


public:
// IMSMQQueue
	STDMETHOD(get_Access)(LONG * plAccess);
	STDMETHOD(get_ShareMode)(LONG * plShareMode);
	STDMETHOD(get_QueueInfo)(IMSMQQueueInfo * * ppqinfo);
	STDMETHOD(get_Handle)(LONG * plHandle);
	STDMETHOD(get_IsOpen)(SHORT * pisOpen);
	STDMETHOD(Close)();
	STDMETHOD(Receive)(VARIANT * Transaction, VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg);
	STDMETHOD(Peek)(VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg);
	STDMETHOD(EnableNotification)(IMSMQEvent * Event, VARIANT * Cursor, VARIANT * ReceiveTimeout);
	STDMETHOD(Reset)();
	STDMETHOD(ReceiveCurrent)(VARIANT * Transaction, VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg);
	STDMETHOD(PeekNext)(VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg);
	STDMETHOD(PeekCurrent)(VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg);

    //-------------------------------------------------------------------------------
    //	SetQueueInfo
    //
    //  Sets the QueueInfo owner.
    //-------------------------------------------------------------------------------
	void        SetQueueInfo(IMSMQQueueInfo* pQueueInfo) { m_spQueueInfo = pQueueInfo; }

    //-------------------------------------------------------------------------------
    //	Open
    //
    //  Open's queue with given acces and share mode.
    //-------------------------------------------------------------------------------
	HRESULT     Open(BSTR bstrFormatName, LONG lAccess, LONG lShareMode);


protected:
// Attributes

    QUEUEHANDLE             m_qHandle;
    HANDLE                  m_hCursor;
    LONG                    m_lAccess;
    LONG                    m_lShareMode;
    CComPtr<IMSMQQueueInfo> m_spQueueInfo;
    CComPtr<IMSMQEvent>     m_spQueueEvent;

};


//
//  COM Object creator class
//
typedef CComObject<CMsmqQueue>*		CMsmqQueuePtr;


#endif //__MSMQQUEUE_H_
