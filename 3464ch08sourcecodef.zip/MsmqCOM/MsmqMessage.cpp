/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

//
//  Includes
//
#include "stdafx.h"
#include "MsmqCOM.h"
#include "MsmqMessage.h"
#include "MsmqQueueInfo.h"

//
//  Constants
//
#define MSMQMSG_NUMPROPS_SEND   16
#define MSMQMSG_NUMPROPS_RECV   25
#define MSMQMSG_STRBUFFER_SIZE  256


//-------------------------------------------------------------------------------
CMsmqMessage::CMsmqMessage() :
    m_lClass(MQMSG_CLASS_NORMAL),
    m_lDelivery(MQMSG_DELIVERY_EXPRESS),
    m_lTrace(MQMSG_TRACE_NONE),
    m_lPriority(3),
    m_lJournal(MQMSG_JOURNAL_NONE),
    m_lAppSpecific(0),
    m_guidSrcMachine(IID_NULL),
    m_lBodyLength(0),
    m_lBodyType(VT_EMPTY),
    m_lAck(MQMSG_ACKNOWLEDGMENT_NONE),
    m_lMaxTimeToReach(INFINITE),
    m_lMaxTimeToRecv(INFINITE),
    m_dtSentTime(0.0),
    m_dtArrivedTime(0.0)
{
    memset( m_ucID, 0, sizeof(m_ucID) );
    memset( m_ucCorrelationID, 0, sizeof(m_ucCorrelationID) );
}

//-------------------------------------------------------------------------------
HRESULT CMsmqMessage::FinalConstruct()
{
    HRESULT hr = S_OK;

    return(hr);
}

//-------------------------------------------------------------------------------
void CMsmqMessage::FinalRelease()
{
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Class(LONG * plClass)
{
    //  Check pointer
	if (plClass == NULL)
		return E_POINTER;

    //  Get value
    *plClass = m_lClass;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_PrivLevel(LONG * plPrivLevel)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_PrivLevel(LONG plPrivLevel)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_AuthLevel(LONG * plAuthLevel)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_AuthLevel(LONG plAuthLevel)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_IsAuthenticated(SHORT * pisAuthenticated)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Delivery(LONG * plDelivery)
{
    //  Check pointer
	if (plDelivery == NULL)
		return E_POINTER;

    //  Get value
    *plDelivery = m_lDelivery;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_Delivery(LONG plDelivery)
{
    //  Set value
    m_lDelivery = plDelivery;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Trace(LONG * plTrace)
{
    //  Check pointer
	if (plTrace == NULL)
		return E_POINTER;
		
    //  Get value
    *plTrace = m_lTrace;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_Trace(LONG plTrace)
{
    //  Set value
    m_lTrace = plTrace;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Priority(LONG * plPriority)
{
    //  Check pointer
	if (plPriority == NULL)
		return E_POINTER;
		
    //  Get value
    *plPriority = m_lPriority;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_Priority(LONG plPriority)
{
    //  Set value
    m_lPriority = plPriority;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Journal(LONG * plJournal)
{
    //  Check pointer
	if (plJournal == NULL)
		return E_POINTER;
		
    //  Get value
    *plJournal = m_lJournal;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_Journal(LONG plJournal)
{
    //  Set value
    m_lJournal = plJournal;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_ResponseQueueInfo(IMSMQQueueInfo * * ppqinfoResponse)
{
    //  Check pointer
	if (ppqinfoResponse == NULL)
		return E_POINTER;
	
	if (m_spRespQueueInfo == NULL)
		return S_FALSE;

    //  Get object	
	return m_spRespQueueInfo->QueryInterface(IID_IMSMQQueueInfo, (void**) ppqinfoResponse);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::putref_ResponseQueueInfo(IMSMQQueueInfo * ppqinfoResponse)
{
    //  Set object
    m_spRespQueueInfo = ppqinfoResponse;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_AppSpecific(LONG * plAppSpecific)
{
    //  Check pointer
	if (plAppSpecific == NULL)
		return E_POINTER;
		
    //  Get value
    *plAppSpecific = m_lAppSpecific;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_AppSpecific(LONG plAppSpecific)
{
    //  Set value
    m_lAppSpecific = plAppSpecific;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_SourceMachineGuid(BSTR * pbstrGuidSrcMachine)
{
    //  Check pointer
	if (pbstrGuidSrcMachine == NULL)
		return E_POINTER;
		
    //  Get value as a BSTR
    CComBSTR    bstrValue(m_guidSrcMachine);

    *pbstrGuidSrcMachine = bstrValue.Detach();
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_BodyLength(LONG * pcbBody)
{
    //  Check pointer
	if (pcbBody == NULL)
		return E_POINTER;
		
    //  Get value
    *pcbBody = m_lBodyLength;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Body(VARIANT * pvarBody)
{
    CComVariant varValue;

    //  Check pointer
	if (pvarBody == NULL)
		return E_POINTER;

    //  Clear return item
    ::VariantInit( pvarBody );

    //  Copy value
    varValue = m_varBody;
		
    //  Return result
	return varValue.Detach(pvarBody);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_Body(VARIANT pvarBody)
{
    HRESULT                 hr;
    CComPtr<IPersistStream> spPS;

    //  Set body and body type (allow only MSMQ supported types)
    //  Streamed and storage objects not supported
    switch( pvarBody.vt )
    {
        case VT_I1:
        case VT_I2:
        case VT_I4:
        case VT_UI1:
        case VT_UI2:
        case VT_UI4:
        case VT_R4:
        case VT_R8:
        case VT_CY:
        case VT_DATE:
        case VT_BSTR:
        case VT_BOOL:
        case VT_ARRAY|VT_UI1:
            //  Allowable types
            m_varBody = pvarBody;
            m_lBodyType = pvarBody.vt;
            break;

        case VT_UNKNOWN:
        case VT_DISPATCH:
            //  Check for IPersistStream interface
            hr = pvarBody.pdispVal->QueryInterface( IID_IPersistStream, (void**) &spPS );
            if( FAILED(hr) )
                return MQ_ERROR_INVALID_PARAMETER;

            //  Persistable object
            m_varBody = pvarBody;
            m_lBodyType = VT_STREAMED_OBJECT;
            break;

        case VT_VARIANT|VT_BYREF:
            //  Referenced variant; save to the embedded variant
            hr = put_Body( *(pvarBody.pvarVal) );
            break;

        default:
            //  Not allowed
            return MQ_ERROR_INVALID_PARAMETER;
            break;
    }

    //  Return status
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_AdminQueueInfo(IMSMQQueueInfo * * ppqinfoAdmin)
{
    //  Check pointer
	if (ppqinfoAdmin == NULL)
		return E_POINTER;
	
	if( !m_spAdminQueueInfo )
		return S_FALSE;
		
    //  Get object	
	return m_spAdminQueueInfo->QueryInterface(IID_IMSMQQueueInfo, (void**) ppqinfoAdmin);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::putref_AdminQueueInfo(IMSMQQueueInfo * ppqinfoAdmin)
{
    //  Set object
    m_spAdminQueueInfo = ppqinfoAdmin;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Id(VARIANT * pvarMsgId)
{
    //  Check pointer
	if (pvarMsgId == NULL)
		return E_POINTER;

    //  Get ID as a string
    CComBSTR    bstrValue( sizeof(m_ucID), LPOLESTR(m_ucID) );
    CComVariant varValue;
    		
    varValue = LPOLESTR(bstrValue);

	return varValue.Detach(pvarMsgId);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_CorrelationId(VARIANT * pvarMsgId)
{
    //  Check pointer
	if (pvarMsgId == NULL)
		return E_POINTER;
		
    //  Get ID as a string
    CComBSTR    bstrValue( sizeof(m_ucCorrelationID), LPOLESTR(m_ucCorrelationID) );
    CComVariant varValue;
    		
    varValue = LPOLESTR(bstrValue);

	return varValue.Detach(pvarMsgId);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_CorrelationId(VARIANT pvarMsgId)
{
    //  Copy the characters directly
    ::memcpy( m_ucCorrelationID, pvarMsgId.bstrVal, sizeof(m_ucCorrelationID) );
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Ack(LONG * plAck)
{
    //  Check pointer
	if (plAck == NULL)
		return E_POINTER;
		
    //  Get value
    *plAck = m_lAck;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_Ack(LONG plAck)
{
    //  Set value
    m_lAck = plAck;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_Label(BSTR * pbstrLabel)
{
    //  Check pointer
	if (pbstrLabel == NULL)
		return E_POINTER;
		
    //  Get value
	return m_bstrLabel.CopyTo(pbstrLabel);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_Label(BSTR pbstrLabel)
{
    //  Set value
    m_bstrLabel = pbstrLabel;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_MaxTimeToReachQueue(LONG * plMaxTimeToReachQueue)
{
    //  Check pointer
	if (plMaxTimeToReachQueue == NULL)
		return E_POINTER;
		
    //  Get value
    *plMaxTimeToReachQueue = m_lMaxTimeToReach;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_MaxTimeToReachQueue(LONG plMaxTimeToReachQueue)
{
    //  Set value
    m_lMaxTimeToReach = plMaxTimeToReachQueue;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_MaxTimeToReceive(LONG * plMaxTimeToReceive)
{
    //  Check pointer
	if (plMaxTimeToReceive == NULL)
		return E_POINTER;
		
    //  Get value
    *plMaxTimeToReceive = m_lMaxTimeToRecv;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_MaxTimeToReceive(LONG plMaxTimeToReceive)
{
    //  Set value
    m_lMaxTimeToRecv = plMaxTimeToReceive;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_HashAlgorithm(LONG * plHashAlg)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_HashAlgorithm(LONG plHashAlg)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_EncryptAlgorithm(LONG * plEncryptAlg)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_EncryptAlgorithm(LONG plEncryptAlg)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_SentTime(VARIANT * pvarSentTime)
{
    //  Check pointer
	if (pvarSentTime == NULL)
		return E_POINTER;
		
    //  Get date
    pvarSentTime->vt = VT_DATE;
    pvarSentTime->date = m_dtSentTime;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_ArrivedTime(VARIANT * plArrivedTime)
{
    //  Check pointer
	if (plArrivedTime == NULL)
		return E_POINTER;
		
    //  Get date
    plArrivedTime->vt = VT_DATE;
    plArrivedTime->date = m_dtArrivedTime;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_DestinationQueueInfo(IMSMQQueueInfo * * ppqinfoDest)
{
    //  Check pointer
	if (ppqinfoDest == NULL)
		return E_POINTER;
		
	if( !m_spDestQueueInfo )
		return S_FALSE;
		
    //  Get object	
	return m_spDestQueueInfo->QueryInterface(IID_IMSMQQueueInfo, (void**) ppqinfoDest);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::putref_DestinationQueueInfo(IMSMQQueueInfo * ppqinfoResponse)
{
    //  Set object
    m_spDestQueueInfo = ppqinfoResponse;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_SenderCertificate(VARIANT * pvarSenderCert)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_SenderCertificate(VARIANT pvarSenderCert)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_SenderId(VARIANT * pvarSenderId)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::get_SenderIdType(LONG * plSenderIdType)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::put_SenderIdType(LONG plSenderIdType)
{
    //  Not supported on CE
	return E_NOTIMPL;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::Send(IMSMQQueue * DestinationQueue, VARIANT * Transaction)
{
    HRESULT         hr;
    QUEUEHANDLE     qHandle;
    ITransaction*   pTransaction;
	MQMSGPROPS	    msgProps;
	MSGPROPID	    aMsgPropId[MSMQMSG_NUMPROPS_SEND];     
	MQPROPVARIANT   aMsgPropVar[MSMQMSG_NUMPROPS_SEND];
    int             i = 0;
    DWORD           dwBodyLength = 0;
    UCHAR*          pucBodyBuffer = NULL;
    HGLOBAL         hStreamMem = NULL;
    CComBSTR        bstrAdminQueueName,
                    bstrRespQueueName,
                    bstrDestQueueName;

  
    //  Check pointers
    if( !DestinationQueue || !Transaction )
        return E_INVALIDARG;

    //  Check optional parameters
    pTransaction = (Transaction->vt == VT_ERROR) ? NULL : (ITransaction*) Transaction->iVal;


    //  Get the queue handle
    hr = DestinationQueue->get_Handle( (LONG*) &qHandle );
    if( FAILED(hr) )
        return hr;


	//  Set the properties of the message
	aMsgPropId[i]		    = PROPID_M_DELIVERY;
	aMsgPropVar[i].vt       = VT_UI1;
    aMsgPropVar[i].bVal     = UCHAR(m_lDelivery);
	i++;
     
	aMsgPropId[i]		    = PROPID_M_TRACE;
	aMsgPropVar[i].vt       = VT_UI1;
    aMsgPropVar[i].bVal     = UCHAR(m_lTrace);
	i++;
     
	aMsgPropId[i]		    = PROPID_M_PRIORITY;
	aMsgPropVar[i].vt       = VT_UI1;
    aMsgPropVar[i].bVal     = UCHAR(m_lPriority);
	i++;

	aMsgPropId[i]		    = PROPID_M_JOURNAL;
	aMsgPropVar[i].vt       = VT_UI1;
    aMsgPropVar[i].bVal     = UCHAR(m_lJournal);
	i++;

    aMsgPropId[i]           = PROPID_M_APPSPECIFIC;
    aMsgPropVar[i].vt       = VT_UI4;
    aMsgPropVar[i].ulVal    = m_lAppSpecific;
    i++;

    aMsgPropId[i]           = PROPID_M_MSGID;
    aMsgPropVar[i].vt       = VT_VECTOR|VT_UI1;
    aMsgPropVar[i].caub.pElems = m_ucID;
    aMsgPropVar[i].caub.cElems = sizeof(m_ucID);
    i++;

    aMsgPropId[i]           = PROPID_M_CORRELATIONID;
    aMsgPropVar[i].vt       = VT_VECTOR|VT_UI1;
    aMsgPropVar[i].caub.pElems = m_ucCorrelationID;
    aMsgPropVar[i].caub.cElems = sizeof(m_ucCorrelationID);
    i++;

    aMsgPropId[i]           = PROPID_M_ACKNOWLEDGE;
    aMsgPropVar[i].vt       = VT_UI1;
    aMsgPropVar[i].bVal     = UCHAR(m_lAck);
    i++;

	aMsgPropId[i]		    = PROPID_M_LABEL;
	aMsgPropVar[i].vt       = VT_LPWSTR;
    aMsgPropVar[i].pwszVal  = m_bstrLabel;
	i++;

    aMsgPropId[i]           = PROPID_M_TIME_TO_REACH_QUEUE;
    aMsgPropVar[i].vt       = VT_UI4; 
    aMsgPropVar[i].ulVal    = m_lMaxTimeToReach;
    i++;

    aMsgPropId[i]           = PROPID_M_TIME_TO_BE_RECEIVED;
    aMsgPropVar[i].vt       = VT_UI4; 
    aMsgPropVar[i].ulVal    = m_lMaxTimeToRecv;
    i++;


    //  Check for a response queue name
    if( m_spRespQueueInfo )
    {
        //  Get the format name of the queue
        hr = m_spRespQueueInfo->get_FormatName( &bstrRespQueueName );
        if( SUCCEEDED(hr) )
        {
            aMsgPropId[i]           = PROPID_M_RESP_QUEUE;
            aMsgPropVar[i].vt       = VT_LPWSTR;
            aMsgPropVar[i].pwszVal  = bstrRespQueueName;
            i++;
        }
    }

    //  Check for a admin queue name
    if( m_spAdminQueueInfo )
    {
        //  Get the format name of the queue
        hr = m_spAdminQueueInfo->get_FormatName( &bstrAdminQueueName );
        if( SUCCEEDED(hr) )
        {
            aMsgPropId[i]           = PROPID_M_ADMIN_QUEUE;
            aMsgPropVar[i].vt       = VT_LPWSTR;
            aMsgPropVar[i].pwszVal  = bstrAdminQueueName;
            i++;
        }
    }

    //  Check for a destination queue name
    if( m_spDestQueueInfo )
    {
        //  Get the format name of the queue
        hr = m_spDestQueueInfo->get_FormatName( &bstrDestQueueName );
        if( SUCCEEDED(hr) )
        {
            aMsgPropId[i]           = PROPID_M_DEST_QUEUE;
            aMsgPropVar[i].vt       = VT_LPWSTR;
            aMsgPropVar[i].pwszVal  = bstrDestQueueName;
            i++;
        }
    }


	//  Set the PROPID_M_BODY_TYPE property.
	aMsgPropId[i]		    = PROPID_M_BODY_TYPE;
	aMsgPropVar[i].vt       = VT_UI4;
	aMsgPropVar[i].ulVal    = m_lBodyType;
	i++;

	//  Set the PROPID_M_BODY property.
    switch( m_lBodyType )
    {
        case VT_I1:
        case VT_UI1:
            dwBodyLength = sizeof(m_varBody.bVal);
            pucBodyBuffer = (UCHAR*) &(m_varBody.bVal);
            break;

        case VT_I2:
        case VT_UI2:
            dwBodyLength = sizeof(m_varBody.iVal);
            pucBodyBuffer = (UCHAR*) &(m_varBody.iVal);
            break;

        case VT_I4:
        case VT_UI4:
            dwBodyLength = sizeof(m_varBody.lVal);
            pucBodyBuffer = (UCHAR*) &(m_varBody.lVal);
            break;

        case VT_R4:
            dwBodyLength = sizeof(m_varBody.fltVal);
            pucBodyBuffer = (UCHAR*) &(m_varBody.fltVal);
            break;

        case VT_R8:
            dwBodyLength = sizeof(m_varBody.dblVal);
            pucBodyBuffer = (UCHAR*) &(m_varBody.dblVal);
            break;

        case VT_CY:
            dwBodyLength = sizeof(m_varBody.cyVal);
            pucBodyBuffer = (UCHAR*) &(m_varBody.cyVal);
            break;

        case VT_DATE:
            dwBodyLength = sizeof(m_varBody.date);
            pucBodyBuffer = (UCHAR*) &(m_varBody.date);
            break;

        case VT_BSTR:
            dwBodyLength = ::SysStringByteLen(m_varBody.bstrVal);
            pucBodyBuffer = (UCHAR*) m_varBody.bstrVal;
            break;

        case VT_BOOL:
            dwBodyLength = sizeof(m_varBody.boolVal);
            pucBodyBuffer = (UCHAR*) &(m_varBody.boolVal);
            break;

        case VT_ARRAY|VT_UI1:
            dwBodyLength = m_varBody.parray->rgsabound[0].cElements;
            pucBodyBuffer = (UCHAR*) m_varBody.parray->pvData;
            break;

        case VT_STREAMED_OBJECT:
            //  Persist the object to memory
            hr = ObjectToStream( m_varBody.punkVal, &hStreamMem, &dwBodyLength );
            if( FAILED(hr) )
            {
                ::LocalFree( hStreamMem );
                return hr;
            }

            //  Set the buffer info
            pucBodyBuffer = (UCHAR*) hStreamMem;
            break;

        default:
            break;
    }
    
    aMsgPropId[i]		        = PROPID_M_BODY;
	aMsgPropVar[i].vt           = VT_VECTOR | VT_UI1;
	aMsgPropVar[i].caub.cElems  = dwBodyLength;
	aMsgPropVar[i].caub.pElems  = pucBodyBuffer;
	i++;

  
	// Initialize the MQMSGPROPS structure.
	msgProps.cProp		= i;
	msgProps.aPropID	= aMsgPropId;
	msgProps.aPropVar	= aMsgPropVar;
	msgProps.aStatus	= NULL;
  

	// Send message to queue.
	hr = MQSendMessage( qHandle, &msgProps, pTransaction );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("MQSendMessage failed  %x\r\n"), hr ); 

        //  Remove any stream buffer
        if( hStreamMem )
            ::LocalFree( hStreamMem );

        return hr;
    }

    //  Remove any stream buffer
    if( hStreamMem )
        ::LocalFree( hStreamMem );

    //  Return result
    return S_OK;  
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqMessage::AttachCurrentSecurityContext()
{
    //  Not supported on CE
	return E_NOTIMPL;
}


//-------------------------------------------------------------------------------
HRESULT CMsmqMessage::Receive( QUEUEHANDLE qHandle, HANDLE hCursor, DWORD dwTimeout, DWORD dwAction, bool bWantDestQueue, bool bWantBody )
{
    HRESULT             hr;
	MQMSGPROPS	        msgProps;
	MSGPROPID	        aMsgPropId[MSMQMSG_NUMPROPS_RECV];     
	MQPROPVARIANT       aMsgPropVar[MSMQMSG_NUMPROPS_RECV];
    HRESULT             aHresults[MSMQMSG_NUMPROPS_RECV];
    int                 i = 0;
    WCHAR               strLabel[MSMQMSG_STRBUFFER_SIZE],
                        strRespQueueName[MSMQMSG_STRBUFFER_SIZE],
                        strAdminQueueName[MSMQMSG_STRBUFFER_SIZE],
                        strDestQueueName[MSMQMSG_STRBUFFER_SIZE];
    UCHAR*              pucBodyBuffer = NULL;
    CComPtr<IDispatch>  spDispatch;



    //  Clear out pointers
    m_varBody.Clear();
    m_spRespQueueInfo.Release();
    m_spAdminQueueInfo.Release();
    m_spDestQueueInfo.Release();

    //  Clear BSTR buffers
    ::memset( strLabel, 0, MSMQMSG_STRBUFFER_SIZE*sizeof(WCHAR) );
    ::memset( strRespQueueName, 0, MSMQMSG_STRBUFFER_SIZE*sizeof(WCHAR) );
    ::memset( strAdminQueueName, 0, MSMQMSG_STRBUFFER_SIZE*sizeof(WCHAR) );
    ::memset( strDestQueueName, 0, MSMQMSG_STRBUFFER_SIZE*sizeof(WCHAR) );


	//  Get the properties of the message
	aMsgPropId[i]		    = PROPID_M_CLASS;               // 0
	aMsgPropVar[i].vt       = VT_UI2;
	i++;
     
	aMsgPropId[i]		    = PROPID_M_DELIVERY;            // 1
	aMsgPropVar[i].vt       = VT_UI1;
	i++;
     
	aMsgPropId[i]		    = PROPID_M_TRACE;               // 2
	aMsgPropVar[i].vt       = VT_UI1;
	i++;
     
	aMsgPropId[i]		    = PROPID_M_JOURNAL;             // 3
	aMsgPropVar[i].vt       = VT_UI1;
	i++;

    aMsgPropId[i]           = PROPID_M_APPSPECIFIC;         // 4
	aMsgPropVar[i].vt       = VT_UI4;
    i++;

    aMsgPropId[i]           = PROPID_M_SRC_MACHINE_ID;      // 5
	aMsgPropVar[i].vt       = VT_CLSID;
	aMsgPropVar[i].puuid    = &m_guidSrcMachine;
    i++;

    aMsgPropId[i]           = PROPID_M_BODY_SIZE;           // 6
    aMsgPropVar[i].vt       = VT_UI4; 
    i++;

    aMsgPropId[i]           = PROPID_M_BODY_TYPE;           // 7
    aMsgPropVar[i].vt       = VT_UI4; 
    i++;

    aMsgPropId[i]           = PROPID_M_MSGID;               // 8
    aMsgPropVar[i].vt       = VT_VECTOR|VT_UI1;
    aMsgPropVar[i].caub.pElems = m_ucID;
    aMsgPropVar[i].caub.cElems = sizeof(m_ucID);
    i++;

    aMsgPropId[i]           = PROPID_M_CORRELATIONID;       // 9
    aMsgPropVar[i].vt       = VT_VECTOR|VT_UI1;
    aMsgPropVar[i].caub.pElems = m_ucCorrelationID;
    aMsgPropVar[i].caub.cElems = sizeof(m_ucCorrelationID);
    i++;

    aMsgPropId[i]           = PROPID_M_ACKNOWLEDGE;         // 10
	aMsgPropVar[i].vt       = VT_UI1;
    i++;

    aMsgPropId[i]           = PROPID_M_LABEL_LEN;           // 11
    aMsgPropVar[i].vt       = VT_UI4;
    aMsgPropVar[i].ulVal    = MSMQMSG_STRBUFFER_SIZE;
    i++;

    aMsgPropId[i]           = PROPID_M_LABEL;               // 12
    aMsgPropVar[i].vt       = VT_LPWSTR;
    aMsgPropVar[i].pwszVal  = strLabel;
    i++;

    aMsgPropId[i]           = PROPID_M_TIME_TO_REACH_QUEUE; // 13
    aMsgPropVar[i].vt       = VT_UI4; 
    i++;

    aMsgPropId[i]           = PROPID_M_TIME_TO_BE_RECEIVED; // 14
    aMsgPropVar[i].vt       = VT_UI4; 
    i++;

    aMsgPropId[i]           = PROPID_M_SENTTIME;            // 15
    aMsgPropVar[i].vt       = VT_UI4;
    i++;
    
    aMsgPropId[i]           = PROPID_M_ARRIVEDTIME;         // 16
    aMsgPropVar[i].vt       = VT_UI4;
    i++;
    

    aMsgPropId[i]           = PROPID_M_RESP_QUEUE_LEN;      // 17
    aMsgPropVar[i].vt       = VT_UI4;
    aMsgPropVar[i].ulVal    = MSMQMSG_STRBUFFER_SIZE;
    i++;

    aMsgPropId[i]           = PROPID_M_RESP_QUEUE;          // 18
    aMsgPropVar[i].vt       = VT_LPWSTR;
    aMsgPropVar[i].pwszVal  = strRespQueueName;
    i++;
     
    aMsgPropId[i]           = PROPID_M_ADMIN_QUEUE_LEN;     // 19
    aMsgPropVar[i].vt       = VT_UI4;
    aMsgPropVar[i].ulVal    = MSMQMSG_STRBUFFER_SIZE;
    i++;

    aMsgPropId[i]           = PROPID_M_ADMIN_QUEUE;         // 20
    aMsgPropVar[i].vt       = VT_LPWSTR;
    aMsgPropVar[i].pwszVal  = strAdminQueueName;
    i++;
     
    aMsgPropId[i]           = PROPID_M_DEST_QUEUE_LEN;      // 21
    aMsgPropVar[i].vt       = VT_UI4;
    aMsgPropVar[i].ulVal    = MSMQMSG_STRBUFFER_SIZE;
    i++;

    aMsgPropId[i]           = PROPID_M_DEST_QUEUE;          // 22
    aMsgPropVar[i].vt       = VT_LPWSTR;
    aMsgPropVar[i].pwszVal  = strDestQueueName;
    i++;


    //  Add a request for the body, using a fixed size buffer
    //  If the body can't be retrieved, retry with a new buffer
    if( bWantBody )
    {
	    MQMSGPROPS	        msgPropsPriv;
	    MSGPROPID	        aMsgPropIdPriv[1];     
	    MQPROPVARIANT       aMsgPropVarPriv[1];
        HRESULT             aHresultsPriv[1];
        DWORD               dwActionPriv;


        //  Peek for the body size to allocate the appropriate buffer size
        aMsgPropIdPriv[0]           = PROPID_M_BODY_SIZE;
        aMsgPropVarPriv[0].vt       = VT_UI4; 

        // Initialize the MQMSGPROPS structure.
        msgPropsPriv.cProp		= 1;
        msgPropsPriv.aPropID	= aMsgPropIdPriv;
        msgPropsPriv.aPropVar	= aMsgPropVarPriv;
        msgPropsPriv.aStatus	= aHresultsPriv;

        //  Alter the dwAction to look at the correct message
        switch( dwAction )
        {
            case MQ_ACTION_RECEIVE:
            case MQ_ACTION_PEEK_CURRENT:
                //  Peek current message for body length
                dwActionPriv = MQ_ACTION_PEEK_CURRENT;
                break;                

            case MQ_ACTION_PEEK_NEXT:
                //  Peek next message for body length
                //  then peek current when getting everything else
                dwActionPriv = MQ_ACTION_PEEK_NEXT;
                dwAction = MQ_ACTION_PEEK_CURRENT;
                break;                
        }

        //  Peek the message
	    hr = MQReceiveMessage( qHandle, dwTimeout, dwActionPriv, &msgPropsPriv, NULL, NULL, hCursor, NULL );
        if( FAILED(hr) )
        {
            //  Recv failed
		    ATLTRACE( _T("MQReceiveMessage failed  %x\r\n"), hr ); 
            goto ErrorCleanup;
        }



        //  Allocate a buffer for the body if there is one
        if( aMsgPropVarPriv[0].ulVal > 0 )
        {
            //  Allocate the buffer
            pucBodyBuffer = new UCHAR[aMsgPropVarPriv[0].ulVal];
            if( !pucBodyBuffer )
                return E_OUTOFMEMORY;

            //  Setup the msgprops for the body
            aMsgPropId[i]               = PROPID_M_BODY;        // 23
            aMsgPropVar[i].vt           = VT_VECTOR|VT_UI1;
            aMsgPropVar[i].caub.pElems  = pucBodyBuffer;
            aMsgPropVar[i].caub.cElems  = aMsgPropVarPriv[0].ulVal;
            i++;        
        }
    }


	// Initialize the MQMSGPROPS structure.
	msgProps.cProp		= i;
	msgProps.aPropID	= aMsgPropId;
	msgProps.aPropVar	= aMsgPropVar;
	msgProps.aStatus	= aHresults;
  


    //  Receive the message
	hr = MQReceiveMessage( qHandle, dwTimeout, dwAction, &msgProps, NULL, NULL, hCursor, NULL );
    if( FAILED(hr) )
    {
        //  Recv failed
		ATLTRACE( _T("MQReceiveMessage failed  %x\r\n"), hr ); 
        goto ErrorCleanup;
    }


    //  Copy over properties
    m_lClass            = aMsgPropVar[0].uiVal;
    m_lDelivery         = aMsgPropVar[1].bVal;
    m_lTrace            = aMsgPropVar[2].bVal;
    m_lJournal          = aMsgPropVar[3].bVal;
    m_lAppSpecific      = aMsgPropVar[4].ulVal;
    m_lBodyLength       = aMsgPropVar[6].ulVal;
    m_lBodyType         = aMsgPropVar[7].ulVal;
    m_lAck              = aMsgPropVar[10].bVal;
    m_bstrLabel         = strLabel;
    m_lMaxTimeToReach   = aMsgPropVar[13].ulVal;
    m_lMaxTimeToRecv    = aMsgPropVar[14].ulVal;
    m_dtSentTime        = UTC_DATE_DELTA + double(aMsgPropVar[15].ulVal)/UTC_DAYSECS;
    m_dtArrivedTime     = UTC_DATE_DELTA + double(aMsgPropVar[16].ulVal)/UTC_DAYSECS;



    //  Create Resp QueueInfo object
    if( aMsgPropVar[17].ulVal > 0 )
    {
        CMsmqQueueInfoPtr   pQueueInfo;

        //  Create the object
        hr = CComObject<CMsmqQueueInfo>::CreateInstance( &pQueueInfo );
        if( FAILED(hr) )
        {
		    ATLTRACE( _T("CComObject<CMsmqQueueInfo>::CreateInstance failed  %x\r\n"), hr ); 
            goto ErrorCleanup;
        }

        //  Set the object's format name
        hr = pQueueInfo->put_FormatName( CComBSTR(strRespQueueName) );
        if( FAILED(hr) )
        {
		    ATLTRACE( _T("put_FormatName failed  %x\r\n"), hr ); 
            goto ErrorCleanup;
        }

        //  Set the smart pointer                    
        m_spRespQueueInfo = pQueueInfo;
    }


    //  Create Admin QueueInfo object
    if( aMsgPropVar[19].ulVal > 0 )
    {
        CMsmqQueueInfoPtr   pQueueInfo;

        //  Create the object
        hr = CComObject<CMsmqQueueInfo>::CreateInstance( &pQueueInfo );
        if( FAILED(hr) )
        {
		    ATLTRACE( _T("CComObject<CMsmqQueueInfo>::CreateInstance failed  %x\r\n"), hr ); 
            goto ErrorCleanup;
        }

        //  Set the object's format name
        hr = pQueueInfo->put_FormatName( CComBSTR(strAdminQueueName) );
        if( FAILED(hr) )
        {
		    ATLTRACE( _T("put_FormatName failed  %x\r\n"), hr ); 
            goto ErrorCleanup;
        }

        //  Set the smart pointer                    
        m_spAdminQueueInfo = pQueueInfo;
    }


    //  Create Dest QueueInfo object
    if( bWantDestQueue && aMsgPropVar[21].ulVal > 0 )
    {
        CMsmqQueueInfoPtr   pQueueInfo;

        //  Create the object
        hr = CComObject<CMsmqQueueInfo>::CreateInstance( &pQueueInfo );
        if( FAILED(hr) )
        {
		    ATLTRACE( _T("CComObject<CMsmqQueueInfo>::CreateInstance failed  %x\r\n"), hr ); 
            goto ErrorCleanup;
        }

        //  Set the object's format name
        hr = pQueueInfo->put_FormatName( CComBSTR(strDestQueueName) );
        if( FAILED(hr) )
        {
		    ATLTRACE( _T("put_FormatName failed  %x\r\n"), hr ); 
            goto ErrorCleanup;
        }

        //  Set the smart pointer                    
        m_spDestQueueInfo = pQueueInfo;
    }


    //  Convert body bytes into variant
    if( bWantBody && m_lBodyLength > 0 )
    {
        switch( m_lBodyType )
        {
            case VT_I1:
            case VT_UI1:
                m_varBody = *((BYTE*) pucBodyBuffer);
                break;

            case VT_I2:
            case VT_UI2:
                m_varBody = *((short*) pucBodyBuffer);
                break;

            case VT_I4:
            case VT_UI4:
                m_varBody = *((long*) pucBodyBuffer);
                break;

            case VT_R4:
                m_varBody = *((float*) pucBodyBuffer);
                break;

            case VT_R8:
                m_varBody = *((double*) pucBodyBuffer);
                break;

            case VT_CY:
                m_varBody = *((CY*) pucBodyBuffer);
                break;

            case VT_DATE:
                m_varBody = *((DATE*) pucBodyBuffer);
                m_varBody.vt = VT_DATE;
                break;

            case VT_BSTR:
                {
                    CComBSTR    bstrData(m_lBodyLength/2, LPCOLESTR(pucBodyBuffer));

                    m_varBody.vt = VT_BSTR;
                    m_varBody.bstrVal = bstrData.Detach();
                }
                break;

            case VT_BOOL:
                m_varBody = *((BOOL*) pucBodyBuffer);
                break;

            case VT_STREAMED_OBJECT:
                //  Load the object from the memory buffer
                hr = StreamToObject( pucBodyBuffer, &spDispatch );
                if( FAILED(hr) )
                    goto ErrorCleanup;

                //  Set the body object
                m_varBody = spDispatch;
                break;

            case VT_ARRAY|VT_UI1:
            default:
                //  Default is an array of bytes
                {
                    SAFEARRAY*      psaiNew; 
                    SAFEARRAYBOUND  aDim[1]; 
                    BYTE            *pvData;

                    //  Allocate a SAFEARRAY for the data
                    aDim[0].lLbound = 1; 
                    aDim[0].cElements = m_lBodyLength; 

                    psaiNew = ::SafeArrayCreate( VT_UI1, 1, aDim );
                    if (psaiNew == NULL)
                    {
                        hr = E_OUTOFMEMORY;
                        goto ErrorCleanup;
                    }

                    //  Grab the pointer to the array memory
                    hr = ::SafeArrayAccessData( psaiNew, (void **) &pvData );
                    if( FAILED(hr) )
                    {
                        //  Cleanup
                        ::SafeArrayDestroy( psaiNew );
                        hr = E_OUTOFMEMORY;
                        goto ErrorCleanup;
                    }

                    //  Copy the body to the array
                    ::memcpy( pvData, pucBodyBuffer, m_lBodyLength );

                    //  Remove lock on array memory
                    ::SafeArrayUnaccessData( psaiNew );
    

                    //  Set return variant
                    m_varBody.vt = VT_ARRAY | VT_UI1;
                    m_varBody.parray = psaiNew;
                }
                break;
        }
    }


ErrorCleanup:

    //  Free memory
    if( pucBodyBuffer )
        delete [] pucBodyBuffer;

    //  Return result
    return hr;
}

//-------------------------------------------------------------------------------
HRESULT CMsmqMessage::ObjectToStream( IUnknown* pUnknown, HGLOBAL* hStreamMem, DWORD* pdwSize )
{
    HRESULT                     hr;
    CComPtr<IStream>            spStream;
    CComPtr<IPersistStream>     spPS;
    LARGE_INTEGER               lPos;
    ULARGE_INTEGER              ulSize;


    //  Create a stream on a memory buffer
    hr = ::CreateStreamOnHGlobal( NULL, FALSE, &spStream );
    if( FAILED(hr) )
        return hr;

    //  Get the IPersistStream interface to the object
    hr = pUnknown->QueryInterface( IID_IPersistStream, (void**) &spPS );
    if( FAILED(hr) )
        return hr;

    //  Save the object to the stream
    hr = WCE_ATL_FCTN(OleSaveToStream)( spPS, spStream );
    if( FAILED(hr) )
        return hr;

    //  Get the total size of the stream in bytes
    lPos.QuadPart = 0;
    hr = spStream->Seek( lPos, STREAM_SEEK_END, &ulSize );
    if( FAILED(hr) )
        return hr;
    
    *pdwSize = DWORD(ulSize.QuadPart);

    //  Get the buffer created for the stream
    hr = ::GetHGlobalFromStream( spStream, hStreamMem );
    if( FAILED(hr) )
        return hr;

    //  Return status
    return S_OK;
}

//-------------------------------------------------------------------------------
HRESULT CMsmqMessage::StreamToObject( HGLOBAL hStreamMem, IDispatch** ppDispatch )
{
    HRESULT                     hr;
    CComPtr<IStream>            spStream;

    //  Create a stream on a memory buffer
    hr = ::CreateStreamOnHGlobal( hStreamMem, FALSE, &spStream );
    if( FAILED(hr) )
        return hr;

    //  Load the object and get dispatch pointer
    hr = WCE_ATL_FCTN(OleLoadFromStream)( spStream, IID_IDispatch, (void**) ppDispatch );
    if( FAILED(hr) )
        return hr;

    //  Return status
    return S_OK;
}
