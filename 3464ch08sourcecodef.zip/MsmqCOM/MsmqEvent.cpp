/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

//
//  Includes
//
#include "stdafx.h"
#include "MsmqCOM.h"
#include "MsmqEvent.h"


//-------------------------------------------------------------------------------
CMsmqEvent::CMsmqEvent()
{
}

//-------------------------------------------------------------------------------
HRESULT CMsmqEvent::FinalConstruct()
{
    HRESULT hr = S_OK;
    RECT        rect;

    //  Create an invisible window for MSMQ messages
    rect.left   = 0;
    rect.right  = 0;
    rect.top    = 0;
    rect.bottom = 0;

    m_hWnd = Create(
                NULL, 
                rect, 
                TEXT("CE_MsmqEventWindow"), 
                WS_POPUP, 
                WS_EX_NOANIMATION|WS_EX_TOOLWINDOW);

    //  Check result
    if( !m_hWnd )
        return HRESULT_FROM_WIN32(::GetLastError());


    return(hr);
}

//-------------------------------------------------------------------------------
void CMsmqEvent::FinalRelease()
{
    //  Delete the window
    if( m_hWnd )
        DestroyWindow();
}

//-------------------------------------------------------------------------------
HRESULT CMsmqEvent::AsyncPeek( IMSMQQueue* pQueue, DWORD dwTimeout )
{
    HANDLE  hThread;
    DWORD   dwId;


    //  Set up MsmqEvent object
    m_spQueue = pQueue;
    m_dwTimeout = dwTimeout;

    //  Create a new thread to load the document
    hThread = ::CreateThread( NULL, 0, Thread_Async, this, 0, &dwId );
    if( hThread == NULL )
        return E_FAIL;

    //  Return result
    return S_OK;
}

//-------------------------------------------------------------------------------
LRESULT CMsmqEvent::OnMsmqEvent(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    //  Fire MSMQ event
    switch( uMsg )
    {
        case WM_MSMQ_ARRIVED:
            //  Fire failed event
            Fire_Arrived( m_spQueue, 0 );
            break;

        case WM_MSMQ_ARRIVEDERROR:
            //  Fire failed event
            Fire_ArrivedError( m_spQueue, lParam, 0 );
            break;

        default:
            //  Unknown
            bHandled = false;
            break;
    }

    return 0;
}

//-------------------------------------------------------------------------------
DWORD WINAPI CMsmqEvent::Thread_Async( LPVOID lpParameter )
{
    CMsmqEvent*     thisPtr = (CMsmqEvent*) lpParameter;
    HRESULT         hr;
    QUEUEHANDLE     qHandle;
    MQMSGPROPS      msgProps;


    //  Check pointer
    if( !thisPtr )
        return E_FAIL;

    //  Get the queue handle
    hr = thisPtr->m_spQueue->get_Handle( (LONG*) &qHandle );
    if( FAILED(hr) )
    {
        //  Fire failed event
        thisPtr->PostMessage( WM_MSMQ_ARRIVEDERROR, 0, hr );
        return 0;
    }

	// Initialize the MQMSGPROPS structure.
	msgProps.cProp	    = 0;
	msgProps.aPropID	= NULL;
	msgProps.aPropVar	= NULL;
	msgProps.aStatus	= NULL;


    //  Peek for the message
	hr = MQReceiveMessage( qHandle, thisPtr->m_dwTimeout, MQ_ACTION_PEEK_CURRENT, &msgProps, NULL, NULL, NULL, NULL );

    //  Post windows message to fire event
    if( SUCCEEDED(hr) )
    {
        //  Fire success event
        thisPtr->PostMessage( WM_MSMQ_ARRIVED );
    }
    else
    {
        //  Fire failed event
        thisPtr->PostMessage( WM_MSMQ_ARRIVEDERROR, 0, hr );
    }

    //  Exit the thread
    return 0;
}
