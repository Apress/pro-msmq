/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#ifndef __MSMQEVENT_H_
#define __MSMQEVENT_H_

//
//  Includes
//
#include "resource.h"       // main symbols
#include "MsmqCOMCP.h"

//
//  Defines
//
#define WM_MSMQ_ARRIVED         (WM_USER + 1)
#define WM_MSMQ_ARRIVEDERROR    (WM_USER + 2)


//-------------------------------------------------------------------------------
//	Class:	CMsmqEvent
//
//	This class implements IMSMQEvent and _DMSMQEventEvents
//-------------------------------------------------------------------------------
class ATL_NO_VTABLE CMsmqEvent : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMsmqEvent, &CLSID_MSMQEvent>,
    public CWindowImpl<CMsmqEvent>,
	public IDispatchImpl<IMSMQEvent, &IID_IMSMQEvent, &LIBID_MSMQ>,
	public CProxy_DMSMQEventEvents< CMsmqEvent >,
	public IConnectionPointContainerImpl<CMsmqEvent>
{
public:
    //-------------------------------------------------------------------------------
    //	C++ and ATL construtor and destructors
    //-------------------------------------------------------------------------------
	CMsmqEvent();

    HRESULT     FinalConstruct();
    void        FinalRelease();

    //-------------------------------------------------------------------------------
    //	ATL Interface Map and class declarations
    //-------------------------------------------------------------------------------
	BEGIN_COM_MAP(CMsmqEvent)
	    COM_INTERFACE_ENTRY(IMSMQEvent)
	    COM_INTERFACE_ENTRY(IDispatch)
	    COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
        COM_INTERFACE_ENTRY_THIS()
	END_COM_MAP()

    BEGIN_CONNECTION_POINT_MAP(CMsmqEvent)
	    CONNECTION_POINT_ENTRY(DIID__DMSMQEventEvents)
    END_CONNECTION_POINT_MAP()

	DECLARE_REGISTRY_RESOURCEID(IDR_MSMQEVENT)
	DECLARE_PROTECT_FINAL_CONSTRUCT()

    DECLARE_WND_CLASS(TEXT("CE_MsmqEvent"))

    BEGIN_MSG_MAP(CMsmqEvent)
        MESSAGE_HANDLER(WM_MSMQ_ARRIVED, OnMsmqEvent)
        MESSAGE_HANDLER(WM_MSMQ_ARRIVEDERROR, OnMsmqEvent)
    END_MSG_MAP()

public:
    //-------------------------------------------------------------------------------
    //	AsyncPeek
    //
    //  Peeks for the message asynchronously
    //-------------------------------------------------------------------------------
	HRESULT     AsyncPeek( IMSMQQueue* pQueue, DWORD dwTimeout );


    //-------------------------------------------------------------------------------
    //	OnMsmqEvent
    //
    //  Handles the user event for posting events on the object thread
    //-------------------------------------------------------------------------------
    LRESULT OnMsmqEvent(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

    //-------------------------------------------------------------------------------
    //	Thread_Async
    //
    //  Static thread function to perform async receive.
    //
    static
    DWORD WINAPI    Thread_Async(
                        LPVOID lpParameter );


protected:
    // Attributes

    CComPtr<IMSMQQueue>     m_spQueue;
    DWORD                   m_dwTimeout;

};

#endif //__MSMQEVENT_H_
