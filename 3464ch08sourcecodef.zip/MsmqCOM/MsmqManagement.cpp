/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

//
//  Includes
//
#include "stdafx.h"
#include "MsmqCOM.h"
#include "MsmqManagement.h"
#include "MsmqQueueInfo.h"
#include "mqmgmt.h"


//
//  Constants
//
#define MSMQMGMT_NUMPROPS_GET   2
 

//-------------------------------------------------------------------------------
CMsmqManagement::CMsmqManagement()
{
}

//-------------------------------------------------------------------------------
HRESULT CMsmqManagement::FinalConstruct()
{
    HRESULT         hr = S_OK;

    //  Load attributes
    hr = Refresh();

    //  Return result        
    return(hr);
}

//-------------------------------------------------------------------------------
void CMsmqManagement::FinalRelease()
{
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqManagement::get_Type(BSTR * pbstrType)
{
    //  Check pointer
	if (pbstrType == NULL)
		return E_POINTER;

    //  Return value		
	return m_bstrType.CopyTo( pbstrType );
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqManagement::get_PrivateQueueCount(LONG * plCount)
{
    //  Check pointer
	if (plCount == NULL)
		return E_POINTER;

    //  Return count
    *plCount = m_saPrivateQueues.GetSize();		
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqManagement::get_PrivateQueue(LONG lIndex, IMSMQQueueInfo * * ppqinfoQueue)
{
    HRESULT             hr;
    CMsmqQueueInfoPtr   pQueueInfo;

    //  Check pointer
	if (ppqinfoQueue == NULL)
		return E_POINTER;

    //  Check bounds
    if( lIndex < 0 || lIndex >= m_saPrivateQueues.GetSize() )
        return E_INVALIDARG;


    //  Create the object
    hr = CComObject<CMsmqQueueInfo>::CreateInstance( &pQueueInfo );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqQueueInfo>::CreateInstance failed  %x\r\n"), hr ); 
        return hr;
    }

    //  Set the object's format name
    hr = pQueueInfo->put_FormatName( m_saPrivateQueues[lIndex] );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("put_FormatName failed  %x\r\n"), hr ); 
        delete pQueueInfo;
        return hr;
    }

    //  AddRef and return the object
    return pQueueInfo->QueryInterface(ppqinfoQueue);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqManagement::Refresh()
{
    HRESULT         hr = S_OK;
	MQMGMTPROPS	    mp;
	PROPID		    aPropID[MSMQMGMT_NUMPROPS_GET];
	PROPVARIANT	    aPropVar[MSMQMGMT_NUMPROPS_GET];
	int				i = 0;


    //  Clear out current attribute values
    m_bstrType.Empty();
    m_saPrivateQueues.RemoveAll();


    //  Setup the properties of the queue
	aPropID[i]          = PROPID_MGMT_MSMQ_TYPE;        // 0
	aPropVar[i].vt      = VT_NULL;
    i++;

	aPropID[i]          = PROPID_MGMT_MSMQ_PRIVATEQ;    // 1
	aPropVar[i].vt      = VT_NULL;
    i++;

    //  Initialize the MQQUEUEPROPS structure
	mp.cProp    = i;
	mp.aPropID  = aPropID;
	mp.aPropVar = aPropVar;
	mp.aStatus  = NULL;


    //  Get the machine properties
    hr = MQMgmtGetInfo( NULL, OLESTR("MACHINE"), &mp );
    if (FAILED(hr))
    {
		ATLTRACE( _T("MQCreateQueue failed  %x\r\n"), hr ); 
        return hr;
    }


    //  Copy the parameter and free the MQ memory
    m_bstrType = aPropVar[0].pwszVal;
    MQFreeMemory(aPropVar[0].pwszVal);


    for( DWORD j = 0; j < aPropVar[1].calpwstr.cElems; j++ )
    {
        m_saPrivateQueues.Add( CComBSTR(aPropVar[1].calpwstr.pElems[j]) );
        MQFreeMemory( aPropVar[1].calpwstr.pElems[j] );
    }

    //  Return result        
    return(hr);
}

