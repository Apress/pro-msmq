/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

//
//  Includes
//
#include "stdafx.h"
#include "MsmqCOM.h"
#include "MsmqQueueInfo.h"
#include "MsmqQueue.h"
#include "mqmgmt.h"


//
//  Constants
//
#define MSMQQUEUEINFO_NUMPROPS_GET      11
#define MSMQQUEUEINFO_NUMPROPS_SET      8


//-------------------------------------------------------------------------------
CMsmqQueueInfo::CMsmqQueueInfo() :
    m_guidQueue(IID_NULL),
    m_guidType(IID_NULL),
    m_lQuota(INFINITE),
    m_lJournal(MQ_JOURNAL_NONE),
    m_lJournalQuota(INFINITE),
    m_lBasePriority(0),
    m_dtCreateTime(0.0),
    m_dtModifyTime(0.0),
    m_sTransactional(MQ_TRANSACTIONAL_NONE)                         
{
}

//-------------------------------------------------------------------------------
HRESULT CMsmqQueueInfo::FinalConstruct()
{
    HRESULT hr = S_OK;

    return(hr);
}

//-------------------------------------------------------------------------------
void CMsmqQueueInfo::FinalRelease()
{
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_QueueGuid(BSTR * pbstrGuidQueue)
{
    //  Check pointer
	if (pbstrGuidQueue == NULL)
		return E_POINTER;

    //  Convert the GUID to a BSTR and return
    CComBSTR    bstrValue(m_guidQueue);

    *pbstrGuidQueue = bstrValue.Detach();
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_ServiceTypeGuid(BSTR * pbstrGuidServiceType)
{
    //  Check pointer
	if (pbstrGuidServiceType == NULL)
		return E_POINTER;
		
    //  Convert the GUID to a BSTR and return
    CComBSTR    bstrValue(m_guidType);

    *pbstrGuidServiceType = bstrValue.Detach();
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_ServiceTypeGuid(BSTR pbstrGuidServiceType)
{
    //  Convert BSTR to a GUID and set value
	return CLSIDFromString(pbstrGuidServiceType, &m_guidType);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_Label(BSTR * pbstrLabel)
{
    //  Check pointer
	if (pbstrLabel == NULL)
		return E_POINTER;

    //  Get value		
	return m_bstrLabel.CopyTo(pbstrLabel);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_Label(BSTR pbstrLabel)
{
    //  Set value
    m_bstrLabel = pbstrLabel;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_PathName(BSTR * pbstrPathName)
{
    //  Check pointer
	if (pbstrPathName == NULL)
		return E_POINTER;
		
    //  Get value		
	return m_bstrPathName.CopyTo(pbstrPathName);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_PathName(BSTR pbstrPathName)
{
    //  Set value
    m_bstrPathName = pbstrPathName;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_FormatName(BSTR * pbstrFormatName)
{
    //  Check pointer
	if (pbstrFormatName == NULL)
		return E_POINTER;
		
    //  Get value		
	return m_bstrFormatName.CopyTo(pbstrFormatName);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_FormatName(BSTR pbstrFormatName)
{
    //  Set value
    m_bstrFormatName = pbstrFormatName;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_IsTransactional(SHORT * pisTransactional)
{
    //  Check pointer
	if (pisTransactional == NULL)
		return E_POINTER;
		
    //  Get value		
	*pisTransactional = m_sTransactional;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_PrivLevel(LONG * plPrivLevel)
{
    //  Check pointer
	if (plPrivLevel == NULL)
		return E_POINTER;
		
	//  Only MQ_PRIV_LEVEL_NONE supported
	*plPrivLevel = MQ_PRIV_LEVEL_NONE;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_PrivLevel(LONG plPrivLevel)
{
	//  Only MQ_PRIV_LEVEL_NONE supported
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_Journal(LONG * plJournal)
{
    //  Check pointer
	if (plJournal == NULL)
		return E_POINTER;

    //  Get value
    *plJournal = m_lJournal;	
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_Journal(LONG plJournal)
{
    //  Set value
    m_lJournal = plJournal;	
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_Quota(LONG * plQuota)
{
    //  Check pointer
	if (plQuota == NULL)
		return E_POINTER;
		
    //  Get value
    *plQuota = m_lQuota;	
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_Quota(LONG plQuota)
{
    //  Set value
    m_lQuota = plQuota;	
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_BasePriority(LONG * plBasePriority)
{
    //  Check pointer
	if (plBasePriority == NULL)
		return E_POINTER;
		
    //  Get value
    *plBasePriority = m_lBasePriority;	
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_BasePriority(LONG plBasePriority)
{
    //  Set value
    m_lBasePriority = plBasePriority;	
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_CreateTime(VARIANT * pvarCreateTime)
{
    //  Check pointer
	if (pvarCreateTime == NULL)
		return E_POINTER;

    //  Get date
    pvarCreateTime->vt = VT_DATE;
    pvarCreateTime->date = m_dtCreateTime;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_ModifyTime(VARIANT * pvarModifyTime)
{
    //  Check pointer
	if (pvarModifyTime == NULL)
		return E_POINTER;
		
    //  Get date
    pvarModifyTime->vt = VT_DATE;
    pvarModifyTime->date = m_dtModifyTime;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_Authenticate(LONG * plAuthenticate)
{
    //  Check pointer
	if (plAuthenticate == NULL)
		return E_POINTER;
		
	//  Only MQ_AUTHENTICATE_NONE supported
	*plAuthenticate = MQ_AUTHENTICATE_NONE;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_Authenticate(LONG plAuthenticate)
{
	//  Only MQ_AUTHENTICATE_NONE supported
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_JournalQuota(LONG * plJournalQuota)
{
    //  Check pointer
	if (plJournalQuota == NULL)
		return E_POINTER;
		
    //  Get value
    *plJournalQuota = m_lJournalQuota;	
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::put_JournalQuota(LONG plJournalQuota)
{
    //  Set value
    m_lJournalQuota = plJournalQuota;	
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::get_IsWorldReadable(SHORT * pisWorldReadable)
{
    //  Check pointer
	if (pisWorldReadable == NULL)
		return E_POINTER;

    //  Security not supported on CE
    *pisWorldReadable = 1;		
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::Create(VARIANT_BOOL IsTransactional, VARIANT_BOOL IsWorldReadable)
{
    HRESULT         hr;
	MQQUEUEPROPS	qp;
	PROPID			aPropID[MSMQQUEUEINFO_NUMPROPS_SET];
	PROPVARIANT		aPropVar[MSMQQUEUEINFO_NUMPROPS_SET];
	int				i = 0;
	DWORD			ccNeededSize = 256;
    CComBSTR        bstrFormatName(ccNeededSize);


    //  Setup the properties of the queue
	aPropID[i]          = PROPID_Q_PATHNAME;
	aPropVar[i].vt      = VT_LPWSTR;
	aPropVar[i].pwszVal = BSTR(m_bstrPathName);
    i++;

	aPropID[i]          = PROPID_Q_LABEL;
	aPropVar[i].vt      = VT_LPWSTR;
	aPropVar[i].pwszVal = BSTR(m_bstrLabel);
    i++;

    aPropID[i]          = PROPID_Q_TYPE;
    aPropVar[i].vt      = VT_CLSID;
    aPropVar[i].puuid   = &m_guidType;
    i++;

    aPropID[i]          = PROPID_Q_QUOTA;
    aPropVar[i].vt      = VT_UI4;
    aPropVar[i].ulVal   = m_lQuota;
    i++;

	aPropID[i]          = PROPID_Q_JOURNAL;
	aPropVar[i].vt      = VT_UI1;
	aPropVar[i].bVal    = UCHAR(m_lJournal);
    i++;

    aPropID[i]          = PROPID_Q_JOURNAL_QUOTA;
    aPropVar[i].vt      = VT_UI4;
    aPropVar[i].ulVal   = m_lJournalQuota;
    i++;

    aPropID[i]          = PROPID_Q_BASEPRIORITY;
    aPropVar[i].vt      = VT_I2;
    aPropVar[i].iVal    = SHORT(m_lBasePriority);
    i++;

    if( IsTransactional == VARIANT_TRUE )
    {
        aPropID[i]          = PROPID_Q_TRANSACTION;
        aPropVar[i].vt      = VT_UI1;
        aPropVar[i].iVal    = MQ_TRANSACTIONAL;
        i++;

        m_sTransactional    = MQ_TRANSACTIONAL;
    }

    //  Initialize the MQQUEUEPROPS structure
	qp.cProp    = i;
	qp.aPropID  = aPropID;
	qp.aPropVar = aPropVar;
	qp.aStatus  = NULL;


    //  Create the queue
	hr = MQCreateQueue (NULL, &qp, bstrFormatName, &ccNeededSize);
	if( hr == MQ_ERROR_QUEUE_EXISTS )
	{
        //  Queue already exists
		ATLTRACE( _T("Queue %s exists\r\n"), m_bstrPathName );
		MQPathNameToFormatName(m_bstrPathName, bstrFormatName, &ccNeededSize);
	}
	else if( FAILED(hr) )
	{
		ATLTRACE( _T("MQCreateQueue failed  %x\r\n"), hr ); 
		return hr;
	}
 
    //  Set the format name
    m_bstrFormatName = bstrFormatName;


    //  Return result
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::Delete()
{
    HRESULT     hr;

    //  Check for a valid format name
    if( !m_bstrFormatName ) 
    {
        DWORD			ccNeededSize = 256;
        CComBSTR        bstrFormatName(ccNeededSize);

		MQPathNameToFormatName(m_bstrPathName, bstrFormatName, &ccNeededSize);
        m_bstrFormatName = bstrFormatName;
    }

    //  Get the properties of the queue
    hr = MQDeleteQueue( BSTR(m_bstrFormatName) );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("MQDeleteQueue failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Return result
    return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::Purge()
{
    HRESULT     hr;
	CComBSTR	bstrBuffer(TEXT("QUEUE="));

    //  Check for a valid format name
    if( !m_bstrFormatName ) 
    {
        DWORD			ccNeededSize = 256;
        CComBSTR        bstrFormatName(ccNeededSize);

		MQPathNameToFormatName(m_bstrPathName, bstrFormatName, &ccNeededSize);
        m_bstrFormatName = bstrFormatName;
    }

    //  Purge the queue of messages
	bstrBuffer += m_bstrFormatName;
    hr = MQMgmtAction(NULL, BSTR(bstrBuffer), TEXT("PURGE"));
    if( FAILED(hr) )
    {
		ATLTRACE( _T("MQPurge failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Return result
    return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::Open(LONG Access, LONG ShareMode, IMSMQQueue * * ppq)
{
    HRESULT         hr;
    CMsmqQueuePtr   pQueueObj;


    //  Check pointer
	if (ppq == NULL)
		return E_POINTER;

    //  Check for a valid format name
    if( !m_bstrFormatName ) 
    {
        //  Try to convert path name to format name
        if( m_bstrPathName )
        {
	        DWORD		ccNeededSize = 256;
            CComBSTR    bstrFormatName(ccNeededSize);

            //  Convert from path name to format name
            hr = MQPathNameToFormatName(m_bstrPathName, bstrFormatName, &ccNeededSize);
            if( FAILED(hr) )
                return hr;

            //  Set the format name
            m_bstrFormatName = bstrFormatName;            
        }
        else
        {
		    ATLTRACE( _T("Illegal format name\r\n") );         
            return MQ_ERROR_ILLEGAL_FORMATNAME;
        }
    }

    //  Create a queue object
    hr = CComObject<CMsmqQueue>::CreateInstance( &pQueueObj );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqQueue>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Open the queue
    hr = pQueueObj->Open( m_bstrFormatName, Access, ShareMode );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CMsmqQueue::Open failed  %x\r\n"), hr );
        delete pQueueObj;
		return hr;
	}

    //  Set the owner info
    pQueueObj->SetQueueInfo( this );

    //  Return AddRef'd object
    return pQueueObj->QueryInterface(ppq);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::Refresh()
{
    HRESULT         hr;
	MQQUEUEPROPS	qp;
	PROPID			aPropID[MSMQQUEUEINFO_NUMPROPS_GET];
	PROPVARIANT		aPropVar[MSMQQUEUEINFO_NUMPROPS_GET];
	int				i = 0;


    //  Check for a valid format name
    if( !m_bstrFormatName ) 
    {
		ATLTRACE( _T("Illegal format name\r\n") );         
        return MQ_ERROR_ILLEGAL_FORMATNAME;
    }

    //  Get the properties of the queue
	aPropID[i]          = PROPID_Q_PATHNAME;        // 0
	aPropVar[i].vt      = VT_NULL;
    i++;

	aPropID[i]          = PROPID_Q_LABEL;           // 1
	aPropVar[i].vt      = VT_NULL;
    i++;

    aPropID[i]          = PROPID_Q_QUOTA;           // 2
    aPropVar[i].vt      = VT_UI4;
    i++;

	aPropID[i]          = PROPID_Q_JOURNAL;         // 3
	aPropVar[i].vt      = VT_UI1;
    i++;

    aPropID[i]          = PROPID_Q_JOURNAL_QUOTA;   // 4
    aPropVar[i].vt      = VT_UI4;
    i++;

    aPropID[i]          = PROPID_Q_BASEPRIORITY;    // 5
    aPropVar[i].vt      = VT_I2;
    i++;

    aPropID[i]          = PROPID_Q_CREATE_TIME;     // 6
    aPropVar[i].vt      = VT_I4;
    i++;

    aPropID[i]          = PROPID_Q_MODIFY_TIME;     // 7
    aPropVar[i].vt      = VT_I4;
    i++;

    aPropID[i]          = PROPID_Q_TYPE;            // 8
    aPropVar[i].vt      = VT_CLSID;
    aPropVar[i].puuid   = &m_guidType;
    i++;

    aPropID[i]          = PROPID_Q_INSTANCE;        // 9
    aPropVar[i].vt      = VT_CLSID;
    aPropVar[i].puuid   = &m_guidQueue;
    i++;

    aPropID[i]          = PROPID_Q_TRANSACTION;     // 10
    aPropVar[i].vt      = VT_UI1;
    i++;



    //  Initialize the MQQUEUEPROPS structure
	qp.cProp    = i;
	qp.aPropID  = aPropID;
	qp.aPropVar = aPropVar;
	qp.aStatus  = NULL;


    //  Get the properties of the queue
    hr = MQGetQueueProperties( BSTR(m_bstrFormatName), &qp );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("MQGetQueueProperties failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Copy the queue properties
    m_bstrPathName =    aPropVar[0].pwszVal;
    m_bstrLabel =       aPropVar[1].pwszVal;
    m_lQuota =          aPropVar[2].ulVal;
	m_lJournal =        aPropVar[3].bVal;
    m_lJournalQuota =   aPropVar[4].ulVal;
    m_lBasePriority =   aPropVar[5].iVal;
    m_dtCreateTime =    UTC_DATE_DELTA + double(aPropVar[6].lVal)/UTC_DAYSECS;
    m_dtModifyTime =    UTC_DATE_DELTA + double(aPropVar[7].lVal)/UTC_DAYSECS;
	m_sTransactional =  aPropVar[10].bVal;

    //  Free MSMQ allocated memory
    MQFreeMemory( aPropVar[0].pwszVal );
    MQFreeMemory( aPropVar[1].pwszVal );

    //  Return result
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueueInfo::Update()
{
    HRESULT         hr;
	MQQUEUEPROPS	qp;
	PROPID			aPropID[MSMQQUEUEINFO_NUMPROPS_SET];
	PROPVARIANT		aPropVar[MSMQQUEUEINFO_NUMPROPS_SET];
	int				i = 0;


    //  Check for a valid format name
    if( !m_bstrFormatName ) 
    {
		ATLTRACE( _T("Illegal format name\r\n") );         
        return MQ_ERROR_ILLEGAL_FORMATNAME;
    }

    //  Set the properties of the queue
    //  Note - Pathname and Journal cannot be changed after queue created
	aPropID[i]          = PROPID_Q_LABEL;
	aPropVar[i].vt      = VT_LPWSTR;
	aPropVar[i].pwszVal = BSTR(m_bstrLabel);
    i++;

    aPropID[i]          = PROPID_Q_TYPE;
    aPropVar[i].vt      = VT_CLSID;
    aPropVar[i].puuid   = &m_guidType;
    i++;

    aPropID[i]          = PROPID_Q_QUOTA;
    aPropVar[i].vt      = VT_UI4;
    aPropVar[i].ulVal   = m_lQuota;
    i++;

    aPropID[i]          = PROPID_Q_JOURNAL_QUOTA;
    aPropVar[i].vt      = VT_UI4;
    aPropVar[i].ulVal   = m_lJournalQuota;
    i++;

    aPropID[i]          = PROPID_Q_BASEPRIORITY;
    aPropVar[i].vt      = VT_I2;
    aPropVar[i].iVal    = SHORT(m_lBasePriority);
    i++;


    //  Initialize the MQQUEUEPROPS structure
	qp.cProp    = i;
	qp.aPropID  = aPropID;
	qp.aPropVar = aPropVar;
	qp.aStatus  = NULL;


    //  Set the properties of the queue
    hr = MQSetQueueProperties( BSTR(m_bstrFormatName), &qp );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("MQSetQueueProperties failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Return result
	return S_OK;
}

