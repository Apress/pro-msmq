/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#ifndef __MSMQMANAGEMENT_H_
#define __MSMQMANAGEMENT_H_

#include "resource.h"       // main symbols

//-------------------------------------------------------------------------------
//	Class:	CMsmqManagement
//
//	This class implements IMSMQManagement
//-------------------------------------------------------------------------------
class ATL_NO_VTABLE CMsmqManagement : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMsmqManagement, &CLSID_MSMQManagement>,
	public IDispatchImpl<IMSMQManagement, &IID_IMSMQManagement, &LIBID_MSMQ>
{
public:
    //-------------------------------------------------------------------------------
    //	C++ and ATL construtor and destructors
    //-------------------------------------------------------------------------------
	CMsmqManagement();

    HRESULT     FinalConstruct();
    void        FinalRelease();

    //-------------------------------------------------------------------------------
    //	ATL Interface Map and class declarations
    //-------------------------------------------------------------------------------
	BEGIN_COM_MAP(CMsmqManagement)
	    COM_INTERFACE_ENTRY(IMSMQManagement)
	    COM_INTERFACE_ENTRY(IDispatch)
	END_COM_MAP()

    DECLARE_REGISTRY_RESOURCEID(IDR_MSMQMANAGEMENT)
    DECLARE_PROTECT_FINAL_CONSTRUCT()


public:
// IMSMQManagement
	STDMETHOD(get_Type)(BSTR * pbstrType);
	STDMETHOD(get_PrivateQueueCount)(LONG * plCount);
	STDMETHOD(get_PrivateQueue)(LONG lIndex, IMSMQQueueInfo * * ppqinfoQueue);
	STDMETHOD(Refresh)();


// Attributes
    CComBSTR                m_bstrType;
    CSimpleArray<CComBSTR>  m_saPrivateQueues;

};

#endif //__MSMQMANAGEMENT_H_
