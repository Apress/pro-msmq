/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

//
//  Includes
//
#include "stdafx.h"
#include "MsmqCOM.h"
#include "MsmqQueue.h"
#include "MsmqMessage.h"
#include "MsmqEvent.h"



//-------------------------------------------------------------------------------
CMsmqQueue::CMsmqQueue() :
    m_qHandle(INVALID_HANDLE_VALUE),
    m_hCursor(INVALID_HANDLE_VALUE),
    m_lAccess(0),
    m_lShareMode(0)
{
}

//-------------------------------------------------------------------------------
HRESULT CMsmqQueue::FinalConstruct()
{
    HRESULT hr = S_OK;

    return(hr);
}

//-------------------------------------------------------------------------------
void CMsmqQueue::FinalRelease()
{
    //  Close cursor and queue
    Close();
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::get_Access(LONG * plAccess)
{
    //  Check pointer
	if (plAccess == NULL)
		return E_POINTER;

    //  Get value
    *plAccess = m_lAccess;		
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::get_ShareMode(LONG * plShareMode)
{
    //  Check pointer
	if (plShareMode == NULL)
		return E_POINTER;
		
    //  Get value
    *plShareMode = m_lShareMode;		
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::get_QueueInfo(IMSMQQueueInfo * * ppqinfo)
{
    //  Check pointer
	if (ppqinfo == NULL)
		return E_POINTER;
		
    //  Get value
	return m_spQueueInfo->QueryInterface( IID_IMSMQQueueInfo, (void**) ppqinfo);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::get_Handle(LONG * plHandle)
{
    //  Check pointer
	if (plHandle == NULL)
		return E_POINTER;
		
    //  Get value
    *plHandle = LONG(m_qHandle);		
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::get_IsOpen(SHORT * pisOpen)
{
    //  Check pointer
	if (pisOpen == NULL)
		return E_POINTER;

    //  Get value
    *pisOpen = (m_qHandle == INVALID_HANDLE_VALUE) ? 0 : 1;  		
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::Close()
{
    //  Close the cursor and queue
    if( m_hCursor != INVALID_HANDLE_VALUE )
        MQCloseCursor( m_hCursor );

    if( m_qHandle != INVALID_HANDLE_VALUE )
        MQCloseQueue( m_qHandle );

    m_hCursor = INVALID_HANDLE_VALUE;
    m_qHandle = INVALID_HANDLE_VALUE;
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::Receive(VARIANT * Transaction, VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg)
{
    HRESULT         hr;
    bool            bWantDestQueue = false,
                    bWantBody = true;
    DWORD           dwTimeout = INFINITE;
    CMsmqMessagePtr pMessageObj;


    //  Check pointer
	if (ppmsg == NULL)
		return E_POINTER;

    if( !WantDestinationQueue || !WantBody || !ReceiveTimeout )
		return E_POINTER;

    //  Check optional parameters
    bWantDestQueue  = (WantDestinationQueue->vt == VT_ERROR) ? false : (WantDestinationQueue->boolVal == VARIANT_TRUE);
    bWantBody       = (WantBody->vt == VT_ERROR) ? true : (WantBody->boolVal == VARIANT_TRUE);
    dwTimeout       = (ReceiveTimeout->vt == VT_ERROR) ? INFINITE : ReceiveTimeout->iVal;
    		
    //  Create a message object
    hr = CComObject<CMsmqMessage>::CreateInstance( &pMessageObj );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqMessage>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Receive the message (no cursor)
    hr = pMessageObj->Receive( m_qHandle, NULL, dwTimeout, MQ_ACTION_RECEIVE, bWantDestQueue, bWantBody );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CMsmqMessage::Receive failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Return message object
	return pMessageObj->QueryInterface(ppmsg);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::Peek(VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg)
{
    HRESULT         hr;
    bool            bWantDestQueue = false,
                    bWantBody = true;
    DWORD           dwTimeout = INFINITE;
    CMsmqMessagePtr pMessageObj;


    //  Check pointer
	if (ppmsg == NULL)
		return E_POINTER;

    if( !WantDestinationQueue || !WantBody || !ReceiveTimeout )
		return E_POINTER;
		
    //  Check optional parameters
    bWantDestQueue  = (WantDestinationQueue->vt == VT_ERROR) ? false : (WantDestinationQueue->boolVal == VARIANT_TRUE);
    bWantBody       = (WantBody->vt == VT_ERROR) ? true : (WantBody->boolVal == VARIANT_TRUE);
    dwTimeout       = (ReceiveTimeout->vt == VT_ERROR) ? INFINITE : ReceiveTimeout->iVal;
    		
    //  Create a message object (no cursor)
    hr = CComObject<CMsmqMessage>::CreateInstance( &pMessageObj );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqMessage>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Peek at the message
    hr = pMessageObj->Receive( m_qHandle, NULL, dwTimeout, MQ_ACTION_PEEK_CURRENT, bWantDestQueue, bWantBody );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CMsmqMessage::Receive failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Return message object
	return pMessageObj->QueryInterface(ppmsg);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::EnableNotification(IMSMQEvent * Event, VARIANT * Cursor, VARIANT * ReceiveTimeout)
{
    HRESULT         hr;
    DWORD           dwTimeout = INFINITE;
    CMsmqEvent*     pEvent;


    //  Check pointer
	if (Event == NULL)
		return E_POINTER;

    if( !Cursor || !ReceiveTimeout )
		return E_POINTER;

    //  Get the base pointer to the CMsmqEvent
    hr = Event->QueryInterface( IID_NULL, (void**) &pEvent );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CMsmqMessage::EnableNotification invalid Event obj pointer\r\n") ); 
		return hr;
	}
    		
    //  Check optional parameters
    dwTimeout = (ReceiveTimeout->vt == VT_ERROR) ? INFINITE : ReceiveTimeout->iVal;


    //  Peek for a new message
    hr = pEvent->AsyncPeek( this, dwTimeout );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CMsmqEvent::AsyncPeek failed  %x\r\n"), hr ); 
		return hr;
	}


    //  Return status
	return hr;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::Reset()
{
    HRESULT     hr;

    //  Reset the cursor to the beginning of the queue by closing it and re-openning it
    if( m_hCursor != INVALID_HANDLE_VALUE )
        MQCloseCursor( m_hCursor );

    //  If this is open for reading, create a cursor handle
    if( m_lAccess == MQ_PEEK_ACCESS || m_lAccess == MQ_RECEIVE_ACCESS )
    {
        //  Create a cursor for random access to the queue contents
        hr = MQCreateCursor( m_qHandle, &m_hCursor );
        if( FAILED(hr) )
        {
		    ATLTRACE( _T("MQCreateCursor failed  %x\r\n"), hr ); 
		    return hr;
	    }
    }

    //  Return status
	return S_OK;
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::ReceiveCurrent(VARIANT * Transaction, VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg)
{
    HRESULT         hr;
    bool            bWantDestQueue = false,
                    bWantBody = true;
    DWORD           dwTimeout = INFINITE;
    CMsmqMessagePtr pMessageObj;


    //  Check pointer
	if (ppmsg == NULL)
		return E_POINTER;

    if( !WantDestinationQueue || !WantBody || !ReceiveTimeout )
		return E_POINTER;

		
    //  Check optional parameters
    bWantDestQueue  = (WantDestinationQueue->vt == VT_ERROR) ? false : (WantDestinationQueue->boolVal == VARIANT_TRUE);
    bWantBody       = (WantBody->vt == VT_ERROR) ? true : (WantBody->boolVal == VARIANT_TRUE);
    dwTimeout       = (ReceiveTimeout->vt == VT_ERROR) ? INFINITE : ReceiveTimeout->iVal;
    		
    //  Create a message object (no cursor)
    hr = CComObject<CMsmqMessage>::CreateInstance( &pMessageObj );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqMessage>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Receive the message using cursor
    hr = pMessageObj->Receive( m_qHandle, m_hCursor, dwTimeout, MQ_ACTION_RECEIVE, bWantDestQueue, bWantBody );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CMsmqMessage::Receive failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Return message object
	return pMessageObj->QueryInterface(ppmsg);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::PeekNext(VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg)
{
    HRESULT         hr;
    bool            bWantDestQueue = false,
                    bWantBody = true;
    DWORD           dwTimeout = INFINITE;
    CMsmqMessagePtr pMessageObj;


    //  Check pointer
	if (ppmsg == NULL)
		return E_POINTER;

    if( !WantDestinationQueue || !WantBody || !ReceiveTimeout )
		return E_POINTER;

		
    //  Check optional parameters
    bWantDestQueue  = (WantDestinationQueue->vt == VT_ERROR) ? false : (WantDestinationQueue->boolVal == VARIANT_TRUE);
    bWantBody       = (WantBody->vt == VT_ERROR) ? true : (WantBody->boolVal == VARIANT_TRUE);
    dwTimeout       = (ReceiveTimeout->vt == VT_ERROR) ? INFINITE : ReceiveTimeout->iVal;
    		
    //  Create a message object (no cursor)
    hr = CComObject<CMsmqMessage>::CreateInstance( &pMessageObj );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqMessage>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Peek at the next message using cursor
    hr = pMessageObj->Receive( m_qHandle, m_hCursor, dwTimeout, MQ_ACTION_PEEK_NEXT, bWantDestQueue, bWantBody );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CMsmqMessage::Receive failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Return message object
	return pMessageObj->QueryInterface(ppmsg);
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqQueue::PeekCurrent(VARIANT * WantDestinationQueue, VARIANT * WantBody, VARIANT * ReceiveTimeout, IMSMQMessage * * ppmsg)
{
    HRESULT         hr;
    bool            bWantDestQueue = false,
                    bWantBody = true;
    DWORD           dwTimeout = INFINITE;
    CMsmqMessagePtr pMessageObj;


    //  Check pointer
	if (ppmsg == NULL)
		return E_POINTER;

    if( !WantDestinationQueue || !WantBody || !ReceiveTimeout )
		return E_POINTER;

		
    //  Check optional parameters
    bWantDestQueue  = (WantDestinationQueue->vt == VT_ERROR) ? false : (WantDestinationQueue->boolVal == VARIANT_TRUE);
    bWantBody       = (WantBody->vt == VT_ERROR) ? true : (WantBody->boolVal == VARIANT_TRUE);
    dwTimeout       = (ReceiveTimeout->vt == VT_ERROR) ? INFINITE : ReceiveTimeout->iVal;
    		
    //  Create a message object (no cursor)
    hr = CComObject<CMsmqMessage>::CreateInstance( &pMessageObj );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqMessage>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Peek at the current message using cursor
    hr = pMessageObj->Receive( m_qHandle, m_hCursor, dwTimeout, MQ_ACTION_PEEK_CURRENT, bWantDestQueue, bWantBody );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CMsmqMessage::Receive failed  %x\r\n"), hr ); 
		return hr;
	}

    //  Return message object
	return pMessageObj->QueryInterface(ppmsg);
}


//-------------------------------------------------------------------------------
HRESULT CMsmqQueue::Open(BSTR bstrFormatName, LONG lAccess, LONG lShareMode)
{
    HRESULT     hr;

    //  Open the queue
	hr = MQOpenQueue( bstrFormatName, lAccess, lShareMode, &m_qHandle );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("MQDeleteQueue failed  %x\r\n"), hr ); 
		return hr;
	}

    //  If this is open for reading, create a cursor handle
    if( lAccess == MQ_PEEK_ACCESS || lAccess == MQ_RECEIVE_ACCESS )
    {
        //  Create a cursor for random access to the queue contents
        hr = MQCreateCursor( m_qHandle, &m_hCursor );
        if( FAILED(hr) )
        {
		    ATLTRACE( _T("MQCreateCursor failed  %x\r\n"), hr ); 
		    return hr;
	    }
    }

    //  Set access and mode properties
    m_lAccess = lAccess;
    m_lShareMode = lShareMode;

    //  Return result
    return S_OK;
}
