/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#ifndef __MSMQAPPLICATION_H_
#define __MSMQAPPLICATION_H_

//
//  Includes
//
#include "resource.h"       // main symbols


//-------------------------------------------------------------------------------
//	Class:	CMsmqApplication
//
//	This class implements IMSMQApplication
//-------------------------------------------------------------------------------
class ATL_NO_VTABLE CMsmqApplication : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMsmqApplication, &CLSID_MSMQApplication>,
	public IDispatchImpl<IMSMQApplication, &IID_IMSMQApplication, &LIBID_MSMQ>
{
public:
    //-------------------------------------------------------------------------------
    //	C++ and ATL construtor and destructors
    //-------------------------------------------------------------------------------
	CMsmqApplication();

    HRESULT     FinalConstruct();
    void        FinalRelease();

    //-------------------------------------------------------------------------------
    //	ATL Interface Map and class declarations
    //-------------------------------------------------------------------------------
    BEGIN_COM_MAP(CMsmqApplication)
        COM_INTERFACE_ENTRY(IMSMQApplication)
        COM_INTERFACE_ENTRY(IDispatch)
    END_COM_MAP()

    DECLARE_REGISTRY_RESOURCEID(IDR_MSMQAPPLICATION)
    DECLARE_PROTECT_FINAL_CONSTRUCT()

public:
// IMSMQApplication
	STDMETHOD(MachineIdOfMachineName)(BSTR MachineName, BSTR * pbstrGuid);

};

#endif //__MSMQAPPLICATION_H_
