/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#ifndef __MSMQQUEUEINFO_H_
#define __MSMQQUEUEINFO_H_

//
//  Includes
//
#include "resource.h"       // main symbols


//-------------------------------------------------------------------------------
//	Class:	CMsmqQueueInfo
//
//	This class implements IMSMQQueueInfo
//-------------------------------------------------------------------------------
class ATL_NO_VTABLE CMsmqQueueInfo : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMsmqQueueInfo, &CLSID_MSMQQueueInfo>,
	public IDispatchImpl<IMSMQQueueInfo, &IID_IMSMQQueueInfo, &LIBID_MSMQ>
{
public:
    //-------------------------------------------------------------------------------
    //	C++ and ATL construtor and destructors
    //-------------------------------------------------------------------------------
	CMsmqQueueInfo();

    HRESULT     FinalConstruct();
    void        FinalRelease();

    //-------------------------------------------------------------------------------
    //	ATL Interface Map and class declarations
    //-------------------------------------------------------------------------------
	BEGIN_COM_MAP(CMsmqQueueInfo)
		COM_INTERFACE_ENTRY(IMSMQQueueInfo)
		COM_INTERFACE_ENTRY(IDispatch)
	END_COM_MAP()

	DECLARE_REGISTRY_RESOURCEID(IDR_MSMQQUEUEINFO)
	DECLARE_PROTECT_FINAL_CONSTRUCT()


public:
// IMSMQQueueInfo
	STDMETHOD(get_QueueGuid)(BSTR * pbstrGuidQueue);
	STDMETHOD(get_ServiceTypeGuid)(BSTR * pbstrGuidServiceType);
	STDMETHOD(put_ServiceTypeGuid)(BSTR pbstrGuidServiceType);
	STDMETHOD(get_Label)(BSTR * pbstrLabel);
	STDMETHOD(put_Label)(BSTR pbstrLabel);
	STDMETHOD(get_PathName)(BSTR * pbstrPathName);
	STDMETHOD(put_PathName)(BSTR pbstrPathName);
	STDMETHOD(get_FormatName)(BSTR * pbstrFormatName);
	STDMETHOD(put_FormatName)(BSTR pbstrFormatName);
	STDMETHOD(get_IsTransactional)(SHORT * pisTransactional);
	STDMETHOD(get_PrivLevel)(LONG * plPrivLevel);
	STDMETHOD(put_PrivLevel)(LONG plPrivLevel);
	STDMETHOD(get_Journal)(LONG * plJournal);
	STDMETHOD(put_Journal)(LONG plJournal);
	STDMETHOD(get_Quota)(LONG * plQuota);
	STDMETHOD(put_Quota)(LONG plQuota);
	STDMETHOD(get_BasePriority)(LONG * plBasePriority);
	STDMETHOD(put_BasePriority)(LONG plBasePriority);
	STDMETHOD(get_CreateTime)(VARIANT * pvarCreateTime);
	STDMETHOD(get_ModifyTime)(VARIANT * pvarModifyTime);
	STDMETHOD(get_Authenticate)(LONG * plAuthenticate);
	STDMETHOD(put_Authenticate)(LONG plAuthenticate);
	STDMETHOD(get_JournalQuota)(LONG * plJournalQuota);
	STDMETHOD(put_JournalQuota)(LONG plJournalQuota);
	STDMETHOD(get_IsWorldReadable)(SHORT * pisWorldReadable);
	STDMETHOD(Create)(VARIANT_BOOL IsTransactional, VARIANT_BOOL IsWorldReadable);
	STDMETHOD(Delete)();
	STDMETHOD(Open)(LONG Access, LONG ShareMode, IMSMQQueue * * ppq);
	STDMETHOD(Refresh)();
	STDMETHOD(Update)();
	STDMETHOD(Purge)();

protected:
// Attributes

    CLSID           m_guidQueue;
    CLSID           m_guidType;  
    CComBSTR        m_bstrLabel;
    CComBSTR        m_bstrPathName;
    CComBSTR        m_bstrFormatName;
    LONG            m_lQuota;
    LONG            m_lJournal;
    LONG            m_lJournalQuota;
    LONG            m_lBasePriority;
    DATE            m_dtCreateTime;
    DATE            m_dtModifyTime;
    SHORT           m_sTransactional;
};

//
//  COM Object creator class
//
typedef CComObject<CMsmqQueueInfo>*	CMsmqQueueInfoPtr;


#endif // __MSMQQUEUEINFO_H_
