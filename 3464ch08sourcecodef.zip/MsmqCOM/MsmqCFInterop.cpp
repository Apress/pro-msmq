/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

//
//  Includes
//
#include "stdafx.h"
#include "MsmqCOM.h"
#include "MsmqQueueInfo.h"
#include "MsmqQueue.h"
#include "MsmqMessage.h"



//
//	DLL entry points for .NET Compact Framework MSMQ Wrapper class
//


#define	MSMQMSG_NUMPROPS_SEND	3


//-------------------------------------------------------------------------------
HRESULT	MsmqCOM_CreateQueue( BSTR strPath )	
{
	HRESULT				hr;
	CMsmqQueueInfoPtr	pQueueInfo;


    //  Create a queue info object
    hr = CComObject<CMsmqQueueInfo>::CreateInstance( &pQueueInfo );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqQueueInfo>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

	pQueueInfo->AddRef();


	//	Set the path name
	pQueueInfo->put_PathName( strPath );

	//	Create the queue
	hr = pQueueInfo->Create( VARIANT_FALSE, VARIANT_FALSE );	

	//	Release queue info obj
	pQueueInfo->Release();

	//	Result
	return hr;
}

//-------------------------------------------------------------------------------
HRESULT	MsmqCOM_PurgeQueue( BSTR strPath )	
{
	HRESULT				hr;
	CMsmqQueueInfoPtr	pQueueInfo;


    //  Create a queue info object
    hr = CComObject<CMsmqQueueInfo>::CreateInstance( &pQueueInfo );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqQueueInfo>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

	pQueueInfo->AddRef();


	//	Set the path name
	pQueueInfo->put_PathName( strPath );

	//	Purge the queue
	hr = pQueueInfo->Purge();	

	//	Release queue info obj
	pQueueInfo->Release();

	//	Result
	return hr;
}

//-------------------------------------------------------------------------------
HRESULT	MsmqCOM_DeleteQueue( BSTR strPath )	
{
	HRESULT				hr;
	CMsmqQueueInfoPtr	pQueueInfo;


    //  Create a queue info object
    hr = CComObject<CMsmqQueueInfo>::CreateInstance( &pQueueInfo );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqQueueInfo>::CreateInstance failed  %x\r\n"), hr ); 
		return hr;
	}

	pQueueInfo->AddRef();


	//	Set the path name
	pQueueInfo->put_PathName( strPath );

	//	Delete the queue
	hr = pQueueInfo->Delete();	

	//	Release queue info obj
	pQueueInfo->Release();

	//	Result
	return hr;
}

//-------------------------------------------------------------------------------
HANDLE	MsmqCOM_OpenQueue( BSTR strPath, int iAccess )	
{
	HRESULT				hr;
	CMsmqQueueInfoPtr	pQueueInfo;
	IMSMQQueue*			pQueue = NULL;


    //  Create a queue info object
    hr = CComObject<CMsmqQueueInfo>::CreateInstance( &pQueueInfo );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqQueueInfo>::CreateInstance failed  %x\r\n"), hr ); 
		return NULL;
	}

	pQueueInfo->AddRef();


	//	Set the path name
	pQueueInfo->put_PathName( strPath );

	//	Create the queue
	hr = pQueueInfo->Open( iAccess, CE_MQ_DENY_NONE, &pQueue );	
    if( FAILED(hr) )
    {
		ATLTRACE( _T("Queue open failed  %x\r\n"), hr ); 
		return NULL;
	}

	//	Release queue info obj
	pQueueInfo->Release();

	//	Result handle to interface
	return HANDLE(pQueue);
}

//-------------------------------------------------------------------------------
HRESULT	MsmqCOM_CloseQueue( HANDLE hQueueHandle )	
{
	IMSMQQueue*	pQueue = (IMSMQQueue*) hQueueHandle;

	//	Close the queue and release the queue object
	pQueue->Close();
	pQueue->Release();
	
	return S_OK;
}


//-------------------------------------------------------------------------------
HRESULT	MsmqCOM_Send( HANDLE hQueueHandle, BSTR strLabel, BSTR strBody )	
{
    HRESULT				hr;
	IMSMQQueue*			pQueue = (IMSMQQueue*) hQueueHandle;
	CMsmqMessagePtr		pMessage;
    CComVariant         varXact(0);


    //  Check pointers
    if( !hQueueHandle )
        return E_INVALIDARG;


    //  Create a message object
    hr = CComObject<CMsmqMessage>::CreateInstance( &pMessage );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("CComObject<CMsmqMessage>::CreateInstance failed  %x\r\n"), hr ); 
		return NULL;
	}

	pMessage->AddRef();


	//	Set the properties of the message
	pMessage->put_Label( strLabel );
	pMessage->put_Body( CComVariant(strBody) );


	//	Send the message to the queue
	hr = pMessage->Send( pQueue, &varXact );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("MQSendMessage failed  %x\r\n"), hr ); 
        return hr;
    }

	//	Release the message
	pMessage->Release();

	//	Result
	return hr;
}
