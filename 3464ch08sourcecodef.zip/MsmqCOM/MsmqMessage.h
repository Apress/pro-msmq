/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#ifndef __MSMQMESSAGE_H_
#define __MSMQMESSAGE_H_

//
//  Includes
//
#include "resource.h"       // main symbols

//-------------------------------------------------------------------------------
//	Class:	CMsmqMessage
//
//	This class implements IMSMQMessage
//-------------------------------------------------------------------------------
class ATL_NO_VTABLE CMsmqMessage : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CMsmqMessage, &CLSID_MSMQMessage>,
	public IDispatchImpl<IMSMQMessage, &IID_IMSMQMessage, &LIBID_MSMQ>
{
public:
    //-------------------------------------------------------------------------------
    //	C++ and ATL construtor and destructors
    //-------------------------------------------------------------------------------
	CMsmqMessage();

    HRESULT     FinalConstruct();
    void        FinalRelease();

    //-------------------------------------------------------------------------------
    //	ATL Interface Map and class declarations
    //-------------------------------------------------------------------------------
	BEGIN_COM_MAP(CMsmqMessage)
		COM_INTERFACE_ENTRY(IMSMQMessage)
		COM_INTERFACE_ENTRY(IDispatch)
	END_COM_MAP()

	DECLARE_REGISTRY_RESOURCEID(IDR_MSMQMESSAGE)
	DECLARE_PROTECT_FINAL_CONSTRUCT()

public:
// IMSMQMessage
	STDMETHOD(get_Class)(LONG * plClass);
	STDMETHOD(get_PrivLevel)(LONG * plPrivLevel);
	STDMETHOD(put_PrivLevel)(LONG plPrivLevel);
	STDMETHOD(get_AuthLevel)(LONG * plAuthLevel);
	STDMETHOD(put_AuthLevel)(LONG plAuthLevel);
	STDMETHOD(get_IsAuthenticated)(SHORT * pisAuthenticated);
	STDMETHOD(get_Delivery)(LONG * plDelivery);
	STDMETHOD(put_Delivery)(LONG plDelivery);
	STDMETHOD(get_Trace)(LONG * plTrace);
	STDMETHOD(put_Trace)(LONG plTrace);
	STDMETHOD(get_Priority)(LONG * plPriority);
	STDMETHOD(put_Priority)(LONG plPriority);
	STDMETHOD(get_Journal)(LONG * plJournal);
	STDMETHOD(put_Journal)(LONG plJournal);
	STDMETHOD(get_ResponseQueueInfo)(IMSMQQueueInfo * * ppqinfoResponse);
	STDMETHOD(putref_ResponseQueueInfo)(IMSMQQueueInfo * ppqinfoResponse);
	STDMETHOD(get_AppSpecific)(LONG * plAppSpecific);
	STDMETHOD(put_AppSpecific)(LONG plAppSpecific);
	STDMETHOD(get_SourceMachineGuid)(BSTR * pbstrGuidSrcMachine);
	STDMETHOD(get_BodyLength)(LONG * pcbBody);
	STDMETHOD(get_Body)(VARIANT * pvarBody);
	STDMETHOD(put_Body)(VARIANT pvarBody);
	STDMETHOD(get_AdminQueueInfo)(IMSMQQueueInfo * * ppqinfoAdmin);
	STDMETHOD(putref_AdminQueueInfo)(IMSMQQueueInfo * ppqinfoAdmin);
	STDMETHOD(get_Id)(VARIANT * pvarMsgId);
	STDMETHOD(get_CorrelationId)(VARIANT * pvarMsgId);
	STDMETHOD(put_CorrelationId)(VARIANT pvarMsgId);
	STDMETHOD(get_Ack)(LONG * plAck);
	STDMETHOD(put_Ack)(LONG plAck);
	STDMETHOD(get_Label)(BSTR * pbstrLabel);
	STDMETHOD(put_Label)(BSTR pbstrLabel);
	STDMETHOD(get_MaxTimeToReachQueue)(LONG * plMaxTimeToReachQueue);
	STDMETHOD(put_MaxTimeToReachQueue)(LONG plMaxTimeToReachQueue);
	STDMETHOD(get_MaxTimeToReceive)(LONG * plMaxTimeToReceive);
	STDMETHOD(put_MaxTimeToReceive)(LONG plMaxTimeToReceive);
	STDMETHOD(get_HashAlgorithm)(LONG * plHashAlg);
	STDMETHOD(put_HashAlgorithm)(LONG plHashAlg);
	STDMETHOD(get_EncryptAlgorithm)(LONG * plEncryptAlg);
	STDMETHOD(put_EncryptAlgorithm)(LONG plEncryptAlg);
	STDMETHOD(get_SentTime)(VARIANT * pvarSentTime);
	STDMETHOD(get_ArrivedTime)(VARIANT * plArrivedTime);
	STDMETHOD(get_DestinationQueueInfo)(IMSMQQueueInfo * * ppqinfoDest);
	STDMETHOD(putref_DestinationQueueInfo)(IMSMQQueueInfo * ppqinfoDest);
	STDMETHOD(get_SenderCertificate)(VARIANT * pvarSenderCert);
	STDMETHOD(put_SenderCertificate)(VARIANT pvarSenderCert);
	STDMETHOD(get_SenderId)(VARIANT * pvarSenderId);
	STDMETHOD(get_SenderIdType)(LONG * plSenderIdType);
	STDMETHOD(put_SenderIdType)(LONG plSenderIdType);
	STDMETHOD(Send)(IMSMQQueue * DestinationQueue, VARIANT * Transaction);
	STDMETHOD(AttachCurrentSecurityContext)();


    //-------------------------------------------------------------------------------
    //	Receive
    //
    //  Receives or peeks a message from the queue
    //-------------------------------------------------------------------------------
	HRESULT     Receive( QUEUEHANDLE qHandle, HANDLE hCursor, DWORD dwTimeout, DWORD dwAction, bool bWantDestQueue, bool bWantBody );


    //-------------------------------------------------------------------------------
    //	ObjectToStream
    //
    //  Persists the given object to a memory stream
    //-------------------------------------------------------------------------------
    HRESULT     ObjectToStream( IUnknown* pUnknown, HGLOBAL* hGlobal, DWORD* pdwSize );

    //-------------------------------------------------------------------------------
    //	StreamToObject
    //
    //  Loads the persisted object from a memory stream
    //-------------------------------------------------------------------------------
    HRESULT     StreamToObject( HGLOBAL hGlobal, IDispatch** ppDispatch );


protected:
// Attributes
    
    LONG        m_lClass;
    LONG        m_lDelivery;
    LONG        m_lTrace;
    LONG        m_lPriority;
    LONG        m_lJournal;
    LONG        m_lAppSpecific;
    CLSID       m_guidSrcMachine;
    LONG        m_lBodyLength;
    LONG        m_lBodyType;
    CComVariant m_varBody;
    UCHAR       m_ucID[20];
    UCHAR       m_ucCorrelationID[20];
    LONG        m_lAck;
    CComBSTR    m_bstrLabel;
    LONG        m_lMaxTimeToReach;
    LONG        m_lMaxTimeToRecv;
    DATE        m_dtSentTime;
    DATE        m_dtArrivedTime;

    CComPtr<IMSMQQueueInfo>     m_spRespQueueInfo;
    CComPtr<IMSMQQueueInfo>     m_spAdminQueueInfo;
    CComPtr<IMSMQQueueInfo>     m_spDestQueueInfo;

};


//
//  COM Object creator class
//
typedef CComObject<CMsmqMessage>*	CMsmqMessagePtr;


#endif //__MSMQMESSAGE_H_
