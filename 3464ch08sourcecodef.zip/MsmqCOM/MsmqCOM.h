/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.02.88 */
/* at Mon Jan 20 11:53:16 2003
 */
/* Compiler settings for MsmqCOM.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"

#ifndef __MsmqCOM_h__
#define __MsmqCOM_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IMSMQApplication_FWD_DEFINED__
#define __IMSMQApplication_FWD_DEFINED__
typedef interface IMSMQApplication IMSMQApplication;
#endif 	/* __IMSMQApplication_FWD_DEFINED__ */


#ifndef __IMSMQQueueInfo_FWD_DEFINED__
#define __IMSMQQueueInfo_FWD_DEFINED__
typedef interface IMSMQQueueInfo IMSMQQueueInfo;
#endif 	/* __IMSMQQueueInfo_FWD_DEFINED__ */


#ifndef __IMSMQQueue_FWD_DEFINED__
#define __IMSMQQueue_FWD_DEFINED__
typedef interface IMSMQQueue IMSMQQueue;
#endif 	/* __IMSMQQueue_FWD_DEFINED__ */


#ifndef __IMSMQMessage_FWD_DEFINED__
#define __IMSMQMessage_FWD_DEFINED__
typedef interface IMSMQMessage IMSMQMessage;
#endif 	/* __IMSMQMessage_FWD_DEFINED__ */


#ifndef __IMSMQEvent_FWD_DEFINED__
#define __IMSMQEvent_FWD_DEFINED__
typedef interface IMSMQEvent IMSMQEvent;
#endif 	/* __IMSMQEvent_FWD_DEFINED__ */


#ifndef ___DMSMQEventEvents_FWD_DEFINED__
#define ___DMSMQEventEvents_FWD_DEFINED__
typedef interface _DMSMQEventEvents _DMSMQEventEvents;
#endif 	/* ___DMSMQEventEvents_FWD_DEFINED__ */


#ifndef __IMSMQManagement_FWD_DEFINED__
#define __IMSMQManagement_FWD_DEFINED__
typedef interface IMSMQManagement IMSMQManagement;
#endif 	/* __IMSMQManagement_FWD_DEFINED__ */


#ifndef __MSMQApplication_FWD_DEFINED__
#define __MSMQApplication_FWD_DEFINED__

#ifdef __cplusplus
typedef class MSMQApplication MSMQApplication;
#else
typedef struct MSMQApplication MSMQApplication;
#endif /* __cplusplus */

#endif 	/* __MSMQApplication_FWD_DEFINED__ */


#ifndef __MSMQQueueInfo_FWD_DEFINED__
#define __MSMQQueueInfo_FWD_DEFINED__

#ifdef __cplusplus
typedef class MSMQQueueInfo MSMQQueueInfo;
#else
typedef struct MSMQQueueInfo MSMQQueueInfo;
#endif /* __cplusplus */

#endif 	/* __MSMQQueueInfo_FWD_DEFINED__ */


#ifndef __MSMQQueue_FWD_DEFINED__
#define __MSMQQueue_FWD_DEFINED__

#ifdef __cplusplus
typedef class MSMQQueue MSMQQueue;
#else
typedef struct MSMQQueue MSMQQueue;
#endif /* __cplusplus */

#endif 	/* __MSMQQueue_FWD_DEFINED__ */


#ifndef __MSMQMessage_FWD_DEFINED__
#define __MSMQMessage_FWD_DEFINED__

#ifdef __cplusplus
typedef class MSMQMessage MSMQMessage;
#else
typedef struct MSMQMessage MSMQMessage;
#endif /* __cplusplus */

#endif 	/* __MSMQMessage_FWD_DEFINED__ */


#ifndef __MSMQEvent_FWD_DEFINED__
#define __MSMQEvent_FWD_DEFINED__

#ifdef __cplusplus
typedef class MSMQEvent MSMQEvent;
#else
typedef struct MSMQEvent MSMQEvent;
#endif /* __cplusplus */

#endif 	/* __MSMQEvent_FWD_DEFINED__ */


#ifndef __MSMQManagement_FWD_DEFINED__
#define __MSMQManagement_FWD_DEFINED__

#ifdef __cplusplus
typedef class MSMQManagement MSMQManagement;
#else
typedef struct MSMQManagement MSMQManagement;
#endif /* __cplusplus */

#endif 	/* __MSMQManagement_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __MSMQ_LIBRARY_DEFINED__
#define __MSMQ_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: MSMQ
 * at Mon Jan 20 11:53:16 2003
 * using MIDL 3.02.88
 ****************************************/
/* [helpstring][version][uuid] */ 


typedef /* [helpstring][uuid] */ 
enum CEMQSHARE
    {	CE_MQ_DENY_NONE	= 0,
	CE_MQ_DENY_RECEIVE_SHARE	= 1
    }	CEMQSHARE;

typedef /* [helpstring][uuid] */ 
enum CEMQACCESS
    {	CE_MQ_RECEIVE_ACCESS	= 1,
	CE_MQ_SEND_ACCESS	= 2,
	CE_MQ_PEEK_ACCESS	= 32
    }	CEMQACCESS;

typedef /* [helpstring][uuid] */ 
enum CEMQTRANSACTION
    {	CE_MQ_NO_TRANSACTION	= 0,
	CE_MQ_SINGLE_MESSAGE	= 3
    }	CEMQTRANSACTION;









EXTERN_C const IID LIBID_MSMQ;

#ifndef __IMSMQApplication_INTERFACE_DEFINED__
#define __IMSMQApplication_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IMSMQApplication
 * at Mon Jan 20 11:53:16 2003
 * using MIDL 3.02.88
 ****************************************/
/* [object][oleautomation][dual][hidden][uuid] */ 



EXTERN_C const IID IID_IMSMQApplication;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("D7D6E085-DCCD-11D0-AA4B-0060970DEBAE")
    IMSMQApplication : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE MachineIdOfMachineName( 
            /* [in] */ BSTR MachineName,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrGuid) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMSMQApplicationVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMSMQApplication __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMSMQApplication __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMSMQApplication __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMSMQApplication __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMSMQApplication __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMSMQApplication __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMSMQApplication __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *MachineIdOfMachineName )( 
            IMSMQApplication __RPC_FAR * This,
            /* [in] */ BSTR MachineName,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrGuid);
        
        END_INTERFACE
    } IMSMQApplicationVtbl;

    interface IMSMQApplication
    {
        CONST_VTBL struct IMSMQApplicationVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMSMQApplication_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMSMQApplication_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMSMQApplication_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMSMQApplication_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMSMQApplication_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMSMQApplication_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMSMQApplication_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMSMQApplication_MachineIdOfMachineName(This,MachineName,pbstrGuid)	\
    (This)->lpVtbl -> MachineIdOfMachineName(This,MachineName,pbstrGuid)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQApplication_MachineIdOfMachineName_Proxy( 
    IMSMQApplication __RPC_FAR * This,
    /* [in] */ BSTR MachineName,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrGuid);


void __RPC_STUB IMSMQApplication_MachineIdOfMachineName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMSMQApplication_INTERFACE_DEFINED__ */


#ifndef __IMSMQQueueInfo_INTERFACE_DEFINED__
#define __IMSMQQueueInfo_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IMSMQQueueInfo
 * at Mon Jan 20 11:53:16 2003
 * using MIDL 3.02.88
 ****************************************/
/* [object][oleautomation][dual][hidden][uuid] */ 



EXTERN_C const IID IID_IMSMQQueueInfo;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("D7D6E07B-DCCD-11D0-AA4B-0060970DEBAE")
    IMSMQQueueInfo : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_QueueGuid( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidQueue) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_ServiceTypeGuid( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidServiceType) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_ServiceTypeGuid( 
            /* [in] */ BSTR pbstrGuidServiceType) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Label( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrLabel) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Label( 
            /* [in] */ BSTR pbstrLabel) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_PathName( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrPathName) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_PathName( 
            /* [in] */ BSTR pbstrPathName) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_FormatName( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrFormatName) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_FormatName( 
            /* [in] */ BSTR pbstrFormatName) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_IsTransactional( 
            /* [retval][out] */ short __RPC_FAR *pisTransactional) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_PrivLevel( 
            /* [retval][out] */ long __RPC_FAR *plPrivLevel) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_PrivLevel( 
            /* [in] */ long plPrivLevel) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Journal( 
            /* [retval][out] */ long __RPC_FAR *plJournal) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Journal( 
            /* [in] */ long plJournal) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Quota( 
            /* [retval][out] */ long __RPC_FAR *plQuota) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Quota( 
            /* [in] */ long plQuota) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_BasePriority( 
            /* [retval][out] */ long __RPC_FAR *plBasePriority) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_BasePriority( 
            /* [in] */ long plBasePriority) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_CreateTime( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvarCreateTime) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_ModifyTime( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvarModifyTime) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Authenticate( 
            /* [retval][out] */ long __RPC_FAR *plAuthenticate) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Authenticate( 
            /* [in] */ long plAuthenticate) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_JournalQuota( 
            /* [retval][out] */ long __RPC_FAR *plJournalQuota) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_JournalQuota( 
            /* [in] */ long plJournalQuota) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_IsWorldReadable( 
            /* [retval][out] */ short __RPC_FAR *pisWorldReadable) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Create( 
            /* [defaultvalue][in] */ VARIANT_BOOL IsTransactional,
            /* [defaultvalue][in] */ VARIANT_BOOL IsWorldReadable) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Delete( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Open( 
            /* [in] */ long Access,
            /* [in] */ long ShareMode,
            /* [retval][out] */ IMSMQQueue __RPC_FAR *__RPC_FAR *ppq) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Refresh( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Update( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Purge( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMSMQQueueInfoVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMSMQQueueInfo __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMSMQQueueInfo __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_QueueGuid )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidQueue);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ServiceTypeGuid )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidServiceType);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_ServiceTypeGuid )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ BSTR pbstrGuidServiceType);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Label )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrLabel);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Label )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ BSTR pbstrLabel);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PathName )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrPathName);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_PathName )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ BSTR pbstrPathName);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_FormatName )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrFormatName);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_FormatName )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ BSTR pbstrFormatName);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IsTransactional )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pisTransactional);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PrivLevel )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plPrivLevel);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_PrivLevel )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ long plPrivLevel);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Journal )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plJournal);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Journal )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ long plJournal);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Quota )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plQuota);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Quota )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ long plQuota);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BasePriority )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plBasePriority);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_BasePriority )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ long plBasePriority);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CreateTime )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvarCreateTime);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ModifyTime )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvarModifyTime);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Authenticate )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plAuthenticate);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Authenticate )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ long plAuthenticate);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_JournalQuota )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plJournalQuota);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_JournalQuota )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ long plJournalQuota);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IsWorldReadable )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pisWorldReadable);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Create )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [defaultvalue][in] */ VARIANT_BOOL IsTransactional,
            /* [defaultvalue][in] */ VARIANT_BOOL IsWorldReadable);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Delete )( 
            IMSMQQueueInfo __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            IMSMQQueueInfo __RPC_FAR * This,
            /* [in] */ long Access,
            /* [in] */ long ShareMode,
            /* [retval][out] */ IMSMQQueue __RPC_FAR *__RPC_FAR *ppq);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Refresh )( 
            IMSMQQueueInfo __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Update )( 
            IMSMQQueueInfo __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Purge )( 
            IMSMQQueueInfo __RPC_FAR * This);
        
        END_INTERFACE
    } IMSMQQueueInfoVtbl;

    interface IMSMQQueueInfo
    {
        CONST_VTBL struct IMSMQQueueInfoVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMSMQQueueInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMSMQQueueInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMSMQQueueInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMSMQQueueInfo_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMSMQQueueInfo_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMSMQQueueInfo_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMSMQQueueInfo_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMSMQQueueInfo_get_QueueGuid(This,pbstrGuidQueue)	\
    (This)->lpVtbl -> get_QueueGuid(This,pbstrGuidQueue)

#define IMSMQQueueInfo_get_ServiceTypeGuid(This,pbstrGuidServiceType)	\
    (This)->lpVtbl -> get_ServiceTypeGuid(This,pbstrGuidServiceType)

#define IMSMQQueueInfo_put_ServiceTypeGuid(This,pbstrGuidServiceType)	\
    (This)->lpVtbl -> put_ServiceTypeGuid(This,pbstrGuidServiceType)

#define IMSMQQueueInfo_get_Label(This,pbstrLabel)	\
    (This)->lpVtbl -> get_Label(This,pbstrLabel)

#define IMSMQQueueInfo_put_Label(This,pbstrLabel)	\
    (This)->lpVtbl -> put_Label(This,pbstrLabel)

#define IMSMQQueueInfo_get_PathName(This,pbstrPathName)	\
    (This)->lpVtbl -> get_PathName(This,pbstrPathName)

#define IMSMQQueueInfo_put_PathName(This,pbstrPathName)	\
    (This)->lpVtbl -> put_PathName(This,pbstrPathName)

#define IMSMQQueueInfo_get_FormatName(This,pbstrFormatName)	\
    (This)->lpVtbl -> get_FormatName(This,pbstrFormatName)

#define IMSMQQueueInfo_put_FormatName(This,pbstrFormatName)	\
    (This)->lpVtbl -> put_FormatName(This,pbstrFormatName)

#define IMSMQQueueInfo_get_IsTransactional(This,pisTransactional)	\
    (This)->lpVtbl -> get_IsTransactional(This,pisTransactional)

#define IMSMQQueueInfo_get_PrivLevel(This,plPrivLevel)	\
    (This)->lpVtbl -> get_PrivLevel(This,plPrivLevel)

#define IMSMQQueueInfo_put_PrivLevel(This,plPrivLevel)	\
    (This)->lpVtbl -> put_PrivLevel(This,plPrivLevel)

#define IMSMQQueueInfo_get_Journal(This,plJournal)	\
    (This)->lpVtbl -> get_Journal(This,plJournal)

#define IMSMQQueueInfo_put_Journal(This,plJournal)	\
    (This)->lpVtbl -> put_Journal(This,plJournal)

#define IMSMQQueueInfo_get_Quota(This,plQuota)	\
    (This)->lpVtbl -> get_Quota(This,plQuota)

#define IMSMQQueueInfo_put_Quota(This,plQuota)	\
    (This)->lpVtbl -> put_Quota(This,plQuota)

#define IMSMQQueueInfo_get_BasePriority(This,plBasePriority)	\
    (This)->lpVtbl -> get_BasePriority(This,plBasePriority)

#define IMSMQQueueInfo_put_BasePriority(This,plBasePriority)	\
    (This)->lpVtbl -> put_BasePriority(This,plBasePriority)

#define IMSMQQueueInfo_get_CreateTime(This,pvarCreateTime)	\
    (This)->lpVtbl -> get_CreateTime(This,pvarCreateTime)

#define IMSMQQueueInfo_get_ModifyTime(This,pvarModifyTime)	\
    (This)->lpVtbl -> get_ModifyTime(This,pvarModifyTime)

#define IMSMQQueueInfo_get_Authenticate(This,plAuthenticate)	\
    (This)->lpVtbl -> get_Authenticate(This,plAuthenticate)

#define IMSMQQueueInfo_put_Authenticate(This,plAuthenticate)	\
    (This)->lpVtbl -> put_Authenticate(This,plAuthenticate)

#define IMSMQQueueInfo_get_JournalQuota(This,plJournalQuota)	\
    (This)->lpVtbl -> get_JournalQuota(This,plJournalQuota)

#define IMSMQQueueInfo_put_JournalQuota(This,plJournalQuota)	\
    (This)->lpVtbl -> put_JournalQuota(This,plJournalQuota)

#define IMSMQQueueInfo_get_IsWorldReadable(This,pisWorldReadable)	\
    (This)->lpVtbl -> get_IsWorldReadable(This,pisWorldReadable)

#define IMSMQQueueInfo_Create(This,IsTransactional,IsWorldReadable)	\
    (This)->lpVtbl -> Create(This,IsTransactional,IsWorldReadable)

#define IMSMQQueueInfo_Delete(This)	\
    (This)->lpVtbl -> Delete(This)

#define IMSMQQueueInfo_Open(This,Access,ShareMode,ppq)	\
    (This)->lpVtbl -> Open(This,Access,ShareMode,ppq)

#define IMSMQQueueInfo_Refresh(This)	\
    (This)->lpVtbl -> Refresh(This)

#define IMSMQQueueInfo_Update(This)	\
    (This)->lpVtbl -> Update(This)

#define IMSMQQueueInfo_Purge(This)	\
    (This)->lpVtbl -> Purge(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_QueueGuid_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidQueue);


void __RPC_STUB IMSMQQueueInfo_get_QueueGuid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_ServiceTypeGuid_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidServiceType);


void __RPC_STUB IMSMQQueueInfo_get_ServiceTypeGuid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_ServiceTypeGuid_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ BSTR pbstrGuidServiceType);


void __RPC_STUB IMSMQQueueInfo_put_ServiceTypeGuid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_Label_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrLabel);


void __RPC_STUB IMSMQQueueInfo_get_Label_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_Label_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ BSTR pbstrLabel);


void __RPC_STUB IMSMQQueueInfo_put_Label_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_PathName_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrPathName);


void __RPC_STUB IMSMQQueueInfo_get_PathName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_PathName_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ BSTR pbstrPathName);


void __RPC_STUB IMSMQQueueInfo_put_PathName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_FormatName_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrFormatName);


void __RPC_STUB IMSMQQueueInfo_get_FormatName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_FormatName_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ BSTR pbstrFormatName);


void __RPC_STUB IMSMQQueueInfo_put_FormatName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_IsTransactional_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pisTransactional);


void __RPC_STUB IMSMQQueueInfo_get_IsTransactional_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_PrivLevel_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plPrivLevel);


void __RPC_STUB IMSMQQueueInfo_get_PrivLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_PrivLevel_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ long plPrivLevel);


void __RPC_STUB IMSMQQueueInfo_put_PrivLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_Journal_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plJournal);


void __RPC_STUB IMSMQQueueInfo_get_Journal_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_Journal_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ long plJournal);


void __RPC_STUB IMSMQQueueInfo_put_Journal_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_Quota_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plQuota);


void __RPC_STUB IMSMQQueueInfo_get_Quota_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_Quota_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ long plQuota);


void __RPC_STUB IMSMQQueueInfo_put_Quota_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_BasePriority_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plBasePriority);


void __RPC_STUB IMSMQQueueInfo_get_BasePriority_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_BasePriority_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ long plBasePriority);


void __RPC_STUB IMSMQQueueInfo_put_BasePriority_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_CreateTime_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvarCreateTime);


void __RPC_STUB IMSMQQueueInfo_get_CreateTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_ModifyTime_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvarModifyTime);


void __RPC_STUB IMSMQQueueInfo_get_ModifyTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_Authenticate_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plAuthenticate);


void __RPC_STUB IMSMQQueueInfo_get_Authenticate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_Authenticate_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ long plAuthenticate);


void __RPC_STUB IMSMQQueueInfo_put_Authenticate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_JournalQuota_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plJournalQuota);


void __RPC_STUB IMSMQQueueInfo_get_JournalQuota_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_put_JournalQuota_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ long plJournalQuota);


void __RPC_STUB IMSMQQueueInfo_put_JournalQuota_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_get_IsWorldReadable_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pisWorldReadable);


void __RPC_STUB IMSMQQueueInfo_get_IsWorldReadable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_Create_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [defaultvalue][in] */ VARIANT_BOOL IsTransactional,
    /* [defaultvalue][in] */ VARIANT_BOOL IsWorldReadable);


void __RPC_STUB IMSMQQueueInfo_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_Delete_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This);


void __RPC_STUB IMSMQQueueInfo_Delete_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_Open_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This,
    /* [in] */ long Access,
    /* [in] */ long ShareMode,
    /* [retval][out] */ IMSMQQueue __RPC_FAR *__RPC_FAR *ppq);


void __RPC_STUB IMSMQQueueInfo_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_Refresh_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This);


void __RPC_STUB IMSMQQueueInfo_Refresh_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_Update_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This);


void __RPC_STUB IMSMQQueueInfo_Update_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueueInfo_Purge_Proxy( 
    IMSMQQueueInfo __RPC_FAR * This);


void __RPC_STUB IMSMQQueueInfo_Purge_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMSMQQueueInfo_INTERFACE_DEFINED__ */


#ifndef __IMSMQQueue_INTERFACE_DEFINED__
#define __IMSMQQueue_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IMSMQQueue
 * at Mon Jan 20 11:53:16 2003
 * using MIDL 3.02.88
 ****************************************/
/* [object][oleautomation][dual][hidden][uuid] */ 



EXTERN_C const IID IID_IMSMQQueue;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("D7D6E076-DCCD-11D0-AA4B-0060970DEBAE")
    IMSMQQueue : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Access( 
            /* [retval][out] */ long __RPC_FAR *plAccess) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_ShareMode( 
            /* [retval][out] */ long __RPC_FAR *plShareMode) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_QueueInfo( 
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfo) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Handle( 
            /* [retval][out] */ long __RPC_FAR *plHandle) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_IsOpen( 
            /* [retval][out] */ short __RPC_FAR *pisOpen) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Receive( 
            /* [optional][in] */ VARIANT __RPC_FAR *Transaction,
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Peek( 
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE EnableNotification( 
            /* [in] */ IMSMQEvent __RPC_FAR *Event,
            /* [optional][in] */ VARIANT __RPC_FAR *Cursor,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Reset( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE ReceiveCurrent( 
            /* [optional][in] */ VARIANT __RPC_FAR *Transaction,
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE PeekNext( 
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE PeekCurrent( 
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMSMQQueueVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMSMQQueue __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMSMQQueue __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMSMQQueue __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMSMQQueue __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMSMQQueue __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMSMQQueue __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMSMQQueue __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Access )( 
            IMSMQQueue __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plAccess);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ShareMode )( 
            IMSMQQueue __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plShareMode);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_QueueInfo )( 
            IMSMQQueue __RPC_FAR * This,
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfo);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Handle )( 
            IMSMQQueue __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plHandle);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IsOpen )( 
            IMSMQQueue __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pisOpen);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IMSMQQueue __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Receive )( 
            IMSMQQueue __RPC_FAR * This,
            /* [optional][in] */ VARIANT __RPC_FAR *Transaction,
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Peek )( 
            IMSMQQueue __RPC_FAR * This,
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *EnableNotification )( 
            IMSMQQueue __RPC_FAR * This,
            /* [in] */ IMSMQEvent __RPC_FAR *Event,
            /* [optional][in] */ VARIANT __RPC_FAR *Cursor,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Reset )( 
            IMSMQQueue __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReceiveCurrent )( 
            IMSMQQueue __RPC_FAR * This,
            /* [optional][in] */ VARIANT __RPC_FAR *Transaction,
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PeekNext )( 
            IMSMQQueue __RPC_FAR * This,
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PeekCurrent )( 
            IMSMQQueue __RPC_FAR * This,
            /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
            /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
            /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);
        
        END_INTERFACE
    } IMSMQQueueVtbl;

    interface IMSMQQueue
    {
        CONST_VTBL struct IMSMQQueueVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMSMQQueue_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMSMQQueue_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMSMQQueue_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMSMQQueue_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMSMQQueue_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMSMQQueue_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMSMQQueue_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMSMQQueue_get_Access(This,plAccess)	\
    (This)->lpVtbl -> get_Access(This,plAccess)

#define IMSMQQueue_get_ShareMode(This,plShareMode)	\
    (This)->lpVtbl -> get_ShareMode(This,plShareMode)

#define IMSMQQueue_get_QueueInfo(This,ppqinfo)	\
    (This)->lpVtbl -> get_QueueInfo(This,ppqinfo)

#define IMSMQQueue_get_Handle(This,plHandle)	\
    (This)->lpVtbl -> get_Handle(This,plHandle)

#define IMSMQQueue_get_IsOpen(This,pisOpen)	\
    (This)->lpVtbl -> get_IsOpen(This,pisOpen)

#define IMSMQQueue_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define IMSMQQueue_Receive(This,Transaction,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)	\
    (This)->lpVtbl -> Receive(This,Transaction,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)

#define IMSMQQueue_Peek(This,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)	\
    (This)->lpVtbl -> Peek(This,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)

#define IMSMQQueue_EnableNotification(This,Event,Cursor,ReceiveTimeout)	\
    (This)->lpVtbl -> EnableNotification(This,Event,Cursor,ReceiveTimeout)

#define IMSMQQueue_Reset(This)	\
    (This)->lpVtbl -> Reset(This)

#define IMSMQQueue_ReceiveCurrent(This,Transaction,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)	\
    (This)->lpVtbl -> ReceiveCurrent(This,Transaction,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)

#define IMSMQQueue_PeekNext(This,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)	\
    (This)->lpVtbl -> PeekNext(This,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)

#define IMSMQQueue_PeekCurrent(This,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)	\
    (This)->lpVtbl -> PeekCurrent(This,WantDestinationQueue,WantBody,ReceiveTimeout,ppmsg)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_get_Access_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plAccess);


void __RPC_STUB IMSMQQueue_get_Access_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_get_ShareMode_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plShareMode);


void __RPC_STUB IMSMQQueue_get_ShareMode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_get_QueueInfo_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfo);


void __RPC_STUB IMSMQQueue_get_QueueInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_get_Handle_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plHandle);


void __RPC_STUB IMSMQQueue_get_Handle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_get_IsOpen_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pisOpen);


void __RPC_STUB IMSMQQueue_get_IsOpen_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_Close_Proxy( 
    IMSMQQueue __RPC_FAR * This);


void __RPC_STUB IMSMQQueue_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_Receive_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [optional][in] */ VARIANT __RPC_FAR *Transaction,
    /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
    /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
    /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
    /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);


void __RPC_STUB IMSMQQueue_Receive_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_Peek_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
    /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
    /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
    /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);


void __RPC_STUB IMSMQQueue_Peek_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_EnableNotification_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [in] */ IMSMQEvent __RPC_FAR *Event,
    /* [optional][in] */ VARIANT __RPC_FAR *Cursor,
    /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout);


void __RPC_STUB IMSMQQueue_EnableNotification_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_Reset_Proxy( 
    IMSMQQueue __RPC_FAR * This);


void __RPC_STUB IMSMQQueue_Reset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_ReceiveCurrent_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [optional][in] */ VARIANT __RPC_FAR *Transaction,
    /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
    /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
    /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
    /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);


void __RPC_STUB IMSMQQueue_ReceiveCurrent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_PeekNext_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
    /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
    /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
    /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);


void __RPC_STUB IMSMQQueue_PeekNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQQueue_PeekCurrent_Proxy( 
    IMSMQQueue __RPC_FAR * This,
    /* [optional][in] */ VARIANT __RPC_FAR *WantDestinationQueue,
    /* [optional][in] */ VARIANT __RPC_FAR *WantBody,
    /* [optional][in] */ VARIANT __RPC_FAR *ReceiveTimeout,
    /* [retval][out] */ IMSMQMessage __RPC_FAR *__RPC_FAR *ppmsg);


void __RPC_STUB IMSMQQueue_PeekCurrent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMSMQQueue_INTERFACE_DEFINED__ */


#ifndef __IMSMQMessage_INTERFACE_DEFINED__
#define __IMSMQMessage_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IMSMQMessage
 * at Mon Jan 20 11:53:16 2003
 * using MIDL 3.02.88
 ****************************************/
/* [object][oleautomation][dual][hidden][uuid] */ 



EXTERN_C const IID IID_IMSMQMessage;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("D7D6E074-DCCD-11D0-AA4B-0060970DEBAE")
    IMSMQMessage : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Class( 
            /* [retval][out] */ long __RPC_FAR *plClass) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_PrivLevel( 
            /* [retval][out] */ long __RPC_FAR *plPrivLevel) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_PrivLevel( 
            /* [in] */ long plPrivLevel) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_AuthLevel( 
            /* [retval][out] */ long __RPC_FAR *plAuthLevel) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_AuthLevel( 
            /* [in] */ long plAuthLevel) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_IsAuthenticated( 
            /* [retval][out] */ short __RPC_FAR *pisAuthenticated) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Delivery( 
            /* [retval][out] */ long __RPC_FAR *plDelivery) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Delivery( 
            /* [in] */ long plDelivery) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Trace( 
            /* [retval][out] */ long __RPC_FAR *plTrace) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Trace( 
            /* [in] */ long plTrace) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Priority( 
            /* [retval][out] */ long __RPC_FAR *plPriority) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Priority( 
            /* [in] */ long plPriority) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Journal( 
            /* [retval][out] */ long __RPC_FAR *plJournal) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Journal( 
            /* [in] */ long plJournal) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_ResponseQueueInfo( 
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoResponse) = 0;
        
        virtual /* [propputref][id] */ HRESULT STDMETHODCALLTYPE putref_ResponseQueueInfo( 
            /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoResponse) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_AppSpecific( 
            /* [retval][out] */ long __RPC_FAR *plAppSpecific) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_AppSpecific( 
            /* [in] */ long plAppSpecific) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_SourceMachineGuid( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidSrcMachine) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_BodyLength( 
            /* [retval][out] */ long __RPC_FAR *pcbBody) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Body( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvarBody) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Body( 
            /* [in] */ VARIANT pvarBody) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_AdminQueueInfo( 
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoAdmin) = 0;
        
        virtual /* [propputref][id] */ HRESULT STDMETHODCALLTYPE putref_AdminQueueInfo( 
            /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoAdmin) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Id( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvarMsgId) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_CorrelationId( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvarMsgId) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_CorrelationId( 
            /* [in] */ VARIANT pvarMsgId) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Ack( 
            /* [retval][out] */ long __RPC_FAR *plAck) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Ack( 
            /* [in] */ long plAck) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Label( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrLabel) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_Label( 
            /* [in] */ BSTR pbstrLabel) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_MaxTimeToReachQueue( 
            /* [retval][out] */ long __RPC_FAR *plMaxTimeToReachQueue) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_MaxTimeToReachQueue( 
            /* [in] */ long plMaxTimeToReachQueue) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_MaxTimeToReceive( 
            /* [retval][out] */ long __RPC_FAR *plMaxTimeToReceive) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_MaxTimeToReceive( 
            /* [in] */ long plMaxTimeToReceive) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_HashAlgorithm( 
            /* [retval][out] */ long __RPC_FAR *plHashAlg) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_HashAlgorithm( 
            /* [in] */ long plHashAlg) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_EncryptAlgorithm( 
            /* [retval][out] */ long __RPC_FAR *plEncryptAlg) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_EncryptAlgorithm( 
            /* [in] */ long plEncryptAlg) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_SentTime( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvarSentTime) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_ArrivedTime( 
            /* [retval][out] */ VARIANT __RPC_FAR *plArrivedTime) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_DestinationQueueInfo( 
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoDest) = 0;
        
        virtual /* [propputref][id] */ HRESULT STDMETHODCALLTYPE putref_DestinationQueueInfo( 
            /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoDest) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_SenderCertificate( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvarSenderCert) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_SenderCertificate( 
            /* [in] */ VARIANT pvarSenderCert) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_SenderId( 
            /* [retval][out] */ VARIANT __RPC_FAR *pvarSenderId) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_SenderIdType( 
            /* [retval][out] */ long __RPC_FAR *plSenderIdType) = 0;
        
        virtual /* [propput][id] */ HRESULT STDMETHODCALLTYPE put_SenderIdType( 
            /* [in] */ long plSenderIdType) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Send( 
            /* [in] */ IMSMQQueue __RPC_FAR *DestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *Transaction) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE AttachCurrentSecurityContext( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMSMQMessageVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMSMQMessage __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMSMQMessage __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMSMQMessage __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Class )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plClass);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PrivLevel )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plPrivLevel);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_PrivLevel )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plPrivLevel);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AuthLevel )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plAuthLevel);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AuthLevel )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plAuthLevel);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_IsAuthenticated )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pisAuthenticated);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Delivery )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plDelivery);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Delivery )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plDelivery);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Trace )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plTrace);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Trace )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plTrace);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Priority )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plPriority);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Priority )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plPriority);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Journal )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plJournal);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Journal )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plJournal);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ResponseQueueInfo )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoResponse);
        
        /* [propputref][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *putref_ResponseQueueInfo )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoResponse);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AppSpecific )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plAppSpecific);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AppSpecific )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plAppSpecific);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SourceMachineGuid )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidSrcMachine);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BodyLength )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pcbBody);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Body )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvarBody);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Body )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ VARIANT pvarBody);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AdminQueueInfo )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoAdmin);
        
        /* [propputref][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *putref_AdminQueueInfo )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoAdmin);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Id )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvarMsgId);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_CorrelationId )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvarMsgId);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_CorrelationId )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ VARIANT pvarMsgId);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Ack )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plAck);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Ack )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plAck);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Label )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrLabel);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Label )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ BSTR pbstrLabel);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_MaxTimeToReachQueue )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plMaxTimeToReachQueue);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_MaxTimeToReachQueue )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plMaxTimeToReachQueue);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_MaxTimeToReceive )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plMaxTimeToReceive);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_MaxTimeToReceive )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plMaxTimeToReceive);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_HashAlgorithm )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plHashAlg);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_HashAlgorithm )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plHashAlg);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_EncryptAlgorithm )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plEncryptAlg);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_EncryptAlgorithm )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plEncryptAlg);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SentTime )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvarSentTime);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_ArrivedTime )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *plArrivedTime);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DestinationQueueInfo )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoDest);
        
        /* [propputref][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *putref_DestinationQueueInfo )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoDest);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SenderCertificate )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvarSenderCert);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SenderCertificate )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ VARIANT pvarSenderCert);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SenderId )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ VARIANT __RPC_FAR *pvarSenderId);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_SenderIdType )( 
            IMSMQMessage __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plSenderIdType);
        
        /* [propput][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_SenderIdType )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ long plSenderIdType);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Send )( 
            IMSMQMessage __RPC_FAR * This,
            /* [in] */ IMSMQQueue __RPC_FAR *DestinationQueue,
            /* [optional][in] */ VARIANT __RPC_FAR *Transaction);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AttachCurrentSecurityContext )( 
            IMSMQMessage __RPC_FAR * This);
        
        END_INTERFACE
    } IMSMQMessageVtbl;

    interface IMSMQMessage
    {
        CONST_VTBL struct IMSMQMessageVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMSMQMessage_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMSMQMessage_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMSMQMessage_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMSMQMessage_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMSMQMessage_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMSMQMessage_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMSMQMessage_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMSMQMessage_get_Class(This,plClass)	\
    (This)->lpVtbl -> get_Class(This,plClass)

#define IMSMQMessage_get_PrivLevel(This,plPrivLevel)	\
    (This)->lpVtbl -> get_PrivLevel(This,plPrivLevel)

#define IMSMQMessage_put_PrivLevel(This,plPrivLevel)	\
    (This)->lpVtbl -> put_PrivLevel(This,plPrivLevel)

#define IMSMQMessage_get_AuthLevel(This,plAuthLevel)	\
    (This)->lpVtbl -> get_AuthLevel(This,plAuthLevel)

#define IMSMQMessage_put_AuthLevel(This,plAuthLevel)	\
    (This)->lpVtbl -> put_AuthLevel(This,plAuthLevel)

#define IMSMQMessage_get_IsAuthenticated(This,pisAuthenticated)	\
    (This)->lpVtbl -> get_IsAuthenticated(This,pisAuthenticated)

#define IMSMQMessage_get_Delivery(This,plDelivery)	\
    (This)->lpVtbl -> get_Delivery(This,plDelivery)

#define IMSMQMessage_put_Delivery(This,plDelivery)	\
    (This)->lpVtbl -> put_Delivery(This,plDelivery)

#define IMSMQMessage_get_Trace(This,plTrace)	\
    (This)->lpVtbl -> get_Trace(This,plTrace)

#define IMSMQMessage_put_Trace(This,plTrace)	\
    (This)->lpVtbl -> put_Trace(This,plTrace)

#define IMSMQMessage_get_Priority(This,plPriority)	\
    (This)->lpVtbl -> get_Priority(This,plPriority)

#define IMSMQMessage_put_Priority(This,plPriority)	\
    (This)->lpVtbl -> put_Priority(This,plPriority)

#define IMSMQMessage_get_Journal(This,plJournal)	\
    (This)->lpVtbl -> get_Journal(This,plJournal)

#define IMSMQMessage_put_Journal(This,plJournal)	\
    (This)->lpVtbl -> put_Journal(This,plJournal)

#define IMSMQMessage_get_ResponseQueueInfo(This,ppqinfoResponse)	\
    (This)->lpVtbl -> get_ResponseQueueInfo(This,ppqinfoResponse)

#define IMSMQMessage_putref_ResponseQueueInfo(This,ppqinfoResponse)	\
    (This)->lpVtbl -> putref_ResponseQueueInfo(This,ppqinfoResponse)

#define IMSMQMessage_get_AppSpecific(This,plAppSpecific)	\
    (This)->lpVtbl -> get_AppSpecific(This,plAppSpecific)

#define IMSMQMessage_put_AppSpecific(This,plAppSpecific)	\
    (This)->lpVtbl -> put_AppSpecific(This,plAppSpecific)

#define IMSMQMessage_get_SourceMachineGuid(This,pbstrGuidSrcMachine)	\
    (This)->lpVtbl -> get_SourceMachineGuid(This,pbstrGuidSrcMachine)

#define IMSMQMessage_get_BodyLength(This,pcbBody)	\
    (This)->lpVtbl -> get_BodyLength(This,pcbBody)

#define IMSMQMessage_get_Body(This,pvarBody)	\
    (This)->lpVtbl -> get_Body(This,pvarBody)

#define IMSMQMessage_put_Body(This,pvarBody)	\
    (This)->lpVtbl -> put_Body(This,pvarBody)

#define IMSMQMessage_get_AdminQueueInfo(This,ppqinfoAdmin)	\
    (This)->lpVtbl -> get_AdminQueueInfo(This,ppqinfoAdmin)

#define IMSMQMessage_putref_AdminQueueInfo(This,ppqinfoAdmin)	\
    (This)->lpVtbl -> putref_AdminQueueInfo(This,ppqinfoAdmin)

#define IMSMQMessage_get_Id(This,pvarMsgId)	\
    (This)->lpVtbl -> get_Id(This,pvarMsgId)

#define IMSMQMessage_get_CorrelationId(This,pvarMsgId)	\
    (This)->lpVtbl -> get_CorrelationId(This,pvarMsgId)

#define IMSMQMessage_put_CorrelationId(This,pvarMsgId)	\
    (This)->lpVtbl -> put_CorrelationId(This,pvarMsgId)

#define IMSMQMessage_get_Ack(This,plAck)	\
    (This)->lpVtbl -> get_Ack(This,plAck)

#define IMSMQMessage_put_Ack(This,plAck)	\
    (This)->lpVtbl -> put_Ack(This,plAck)

#define IMSMQMessage_get_Label(This,pbstrLabel)	\
    (This)->lpVtbl -> get_Label(This,pbstrLabel)

#define IMSMQMessage_put_Label(This,pbstrLabel)	\
    (This)->lpVtbl -> put_Label(This,pbstrLabel)

#define IMSMQMessage_get_MaxTimeToReachQueue(This,plMaxTimeToReachQueue)	\
    (This)->lpVtbl -> get_MaxTimeToReachQueue(This,plMaxTimeToReachQueue)

#define IMSMQMessage_put_MaxTimeToReachQueue(This,plMaxTimeToReachQueue)	\
    (This)->lpVtbl -> put_MaxTimeToReachQueue(This,plMaxTimeToReachQueue)

#define IMSMQMessage_get_MaxTimeToReceive(This,plMaxTimeToReceive)	\
    (This)->lpVtbl -> get_MaxTimeToReceive(This,plMaxTimeToReceive)

#define IMSMQMessage_put_MaxTimeToReceive(This,plMaxTimeToReceive)	\
    (This)->lpVtbl -> put_MaxTimeToReceive(This,plMaxTimeToReceive)

#define IMSMQMessage_get_HashAlgorithm(This,plHashAlg)	\
    (This)->lpVtbl -> get_HashAlgorithm(This,plHashAlg)

#define IMSMQMessage_put_HashAlgorithm(This,plHashAlg)	\
    (This)->lpVtbl -> put_HashAlgorithm(This,plHashAlg)

#define IMSMQMessage_get_EncryptAlgorithm(This,plEncryptAlg)	\
    (This)->lpVtbl -> get_EncryptAlgorithm(This,plEncryptAlg)

#define IMSMQMessage_put_EncryptAlgorithm(This,plEncryptAlg)	\
    (This)->lpVtbl -> put_EncryptAlgorithm(This,plEncryptAlg)

#define IMSMQMessage_get_SentTime(This,pvarSentTime)	\
    (This)->lpVtbl -> get_SentTime(This,pvarSentTime)

#define IMSMQMessage_get_ArrivedTime(This,plArrivedTime)	\
    (This)->lpVtbl -> get_ArrivedTime(This,plArrivedTime)

#define IMSMQMessage_get_DestinationQueueInfo(This,ppqinfoDest)	\
    (This)->lpVtbl -> get_DestinationQueueInfo(This,ppqinfoDest)

#define IMSMQMessage_putref_DestinationQueueInfo(This,ppqinfoDest)	\
    (This)->lpVtbl -> putref_DestinationQueueInfo(This,ppqinfoDest)

#define IMSMQMessage_get_SenderCertificate(This,pvarSenderCert)	\
    (This)->lpVtbl -> get_SenderCertificate(This,pvarSenderCert)

#define IMSMQMessage_put_SenderCertificate(This,pvarSenderCert)	\
    (This)->lpVtbl -> put_SenderCertificate(This,pvarSenderCert)

#define IMSMQMessage_get_SenderId(This,pvarSenderId)	\
    (This)->lpVtbl -> get_SenderId(This,pvarSenderId)

#define IMSMQMessage_get_SenderIdType(This,plSenderIdType)	\
    (This)->lpVtbl -> get_SenderIdType(This,plSenderIdType)

#define IMSMQMessage_put_SenderIdType(This,plSenderIdType)	\
    (This)->lpVtbl -> put_SenderIdType(This,plSenderIdType)

#define IMSMQMessage_Send(This,DestinationQueue,Transaction)	\
    (This)->lpVtbl -> Send(This,DestinationQueue,Transaction)

#define IMSMQMessage_AttachCurrentSecurityContext(This)	\
    (This)->lpVtbl -> AttachCurrentSecurityContext(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Class_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plClass);


void __RPC_STUB IMSMQMessage_get_Class_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_PrivLevel_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plPrivLevel);


void __RPC_STUB IMSMQMessage_get_PrivLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_PrivLevel_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plPrivLevel);


void __RPC_STUB IMSMQMessage_put_PrivLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_AuthLevel_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plAuthLevel);


void __RPC_STUB IMSMQMessage_get_AuthLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_AuthLevel_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plAuthLevel);


void __RPC_STUB IMSMQMessage_put_AuthLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_IsAuthenticated_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pisAuthenticated);


void __RPC_STUB IMSMQMessage_get_IsAuthenticated_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Delivery_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plDelivery);


void __RPC_STUB IMSMQMessage_get_Delivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_Delivery_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plDelivery);


void __RPC_STUB IMSMQMessage_put_Delivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Trace_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plTrace);


void __RPC_STUB IMSMQMessage_get_Trace_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_Trace_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plTrace);


void __RPC_STUB IMSMQMessage_put_Trace_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Priority_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plPriority);


void __RPC_STUB IMSMQMessage_get_Priority_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_Priority_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plPriority);


void __RPC_STUB IMSMQMessage_put_Priority_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Journal_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plJournal);


void __RPC_STUB IMSMQMessage_get_Journal_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_Journal_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plJournal);


void __RPC_STUB IMSMQMessage_put_Journal_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_ResponseQueueInfo_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoResponse);


void __RPC_STUB IMSMQMessage_get_ResponseQueueInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propputref][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_putref_ResponseQueueInfo_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoResponse);


void __RPC_STUB IMSMQMessage_putref_ResponseQueueInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_AppSpecific_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plAppSpecific);


void __RPC_STUB IMSMQMessage_get_AppSpecific_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_AppSpecific_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plAppSpecific);


void __RPC_STUB IMSMQMessage_put_AppSpecific_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_SourceMachineGuid_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrGuidSrcMachine);


void __RPC_STUB IMSMQMessage_get_SourceMachineGuid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_BodyLength_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pcbBody);


void __RPC_STUB IMSMQMessage_get_BodyLength_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Body_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvarBody);


void __RPC_STUB IMSMQMessage_get_Body_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_Body_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ VARIANT pvarBody);


void __RPC_STUB IMSMQMessage_put_Body_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_AdminQueueInfo_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoAdmin);


void __RPC_STUB IMSMQMessage_get_AdminQueueInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propputref][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_putref_AdminQueueInfo_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoAdmin);


void __RPC_STUB IMSMQMessage_putref_AdminQueueInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Id_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvarMsgId);


void __RPC_STUB IMSMQMessage_get_Id_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_CorrelationId_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvarMsgId);


void __RPC_STUB IMSMQMessage_get_CorrelationId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_CorrelationId_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ VARIANT pvarMsgId);


void __RPC_STUB IMSMQMessage_put_CorrelationId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Ack_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plAck);


void __RPC_STUB IMSMQMessage_get_Ack_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_Ack_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plAck);


void __RPC_STUB IMSMQMessage_put_Ack_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_Label_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrLabel);


void __RPC_STUB IMSMQMessage_get_Label_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_Label_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ BSTR pbstrLabel);


void __RPC_STUB IMSMQMessage_put_Label_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_MaxTimeToReachQueue_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plMaxTimeToReachQueue);


void __RPC_STUB IMSMQMessage_get_MaxTimeToReachQueue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_MaxTimeToReachQueue_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plMaxTimeToReachQueue);


void __RPC_STUB IMSMQMessage_put_MaxTimeToReachQueue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_MaxTimeToReceive_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plMaxTimeToReceive);


void __RPC_STUB IMSMQMessage_get_MaxTimeToReceive_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_MaxTimeToReceive_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plMaxTimeToReceive);


void __RPC_STUB IMSMQMessage_put_MaxTimeToReceive_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_HashAlgorithm_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plHashAlg);


void __RPC_STUB IMSMQMessage_get_HashAlgorithm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_HashAlgorithm_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plHashAlg);


void __RPC_STUB IMSMQMessage_put_HashAlgorithm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_EncryptAlgorithm_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plEncryptAlg);


void __RPC_STUB IMSMQMessage_get_EncryptAlgorithm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_EncryptAlgorithm_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plEncryptAlg);


void __RPC_STUB IMSMQMessage_put_EncryptAlgorithm_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_SentTime_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvarSentTime);


void __RPC_STUB IMSMQMessage_get_SentTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_ArrivedTime_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *plArrivedTime);


void __RPC_STUB IMSMQMessage_get_ArrivedTime_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_DestinationQueueInfo_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoDest);


void __RPC_STUB IMSMQMessage_get_DestinationQueueInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propputref][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_putref_DestinationQueueInfo_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ IMSMQQueueInfo __RPC_FAR *ppqinfoDest);


void __RPC_STUB IMSMQMessage_putref_DestinationQueueInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_SenderCertificate_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvarSenderCert);


void __RPC_STUB IMSMQMessage_get_SenderCertificate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_SenderCertificate_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ VARIANT pvarSenderCert);


void __RPC_STUB IMSMQMessage_put_SenderCertificate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_SenderId_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ VARIANT __RPC_FAR *pvarSenderId);


void __RPC_STUB IMSMQMessage_get_SenderId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_get_SenderIdType_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plSenderIdType);


void __RPC_STUB IMSMQMessage_get_SenderIdType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propput][id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_put_SenderIdType_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ long plSenderIdType);


void __RPC_STUB IMSMQMessage_put_SenderIdType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_Send_Proxy( 
    IMSMQMessage __RPC_FAR * This,
    /* [in] */ IMSMQQueue __RPC_FAR *DestinationQueue,
    /* [optional][in] */ VARIANT __RPC_FAR *Transaction);


void __RPC_STUB IMSMQMessage_Send_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQMessage_AttachCurrentSecurityContext_Proxy( 
    IMSMQMessage __RPC_FAR * This);


void __RPC_STUB IMSMQMessage_AttachCurrentSecurityContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMSMQMessage_INTERFACE_DEFINED__ */


#ifndef __IMSMQEvent_INTERFACE_DEFINED__
#define __IMSMQEvent_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IMSMQEvent
 * at Mon Jan 20 11:53:16 2003
 * using MIDL 3.02.88
 ****************************************/
/* [object][oleautomation][dual][hidden][uuid] */ 



EXTERN_C const IID IID_IMSMQEvent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("D7D6E077-DCCD-11D0-AA4B-0060970DEBAE")
    IMSMQEvent : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IMSMQEventVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMSMQEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMSMQEvent __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMSMQEvent __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMSMQEvent __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMSMQEvent __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMSMQEvent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMSMQEvent __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IMSMQEventVtbl;

    interface IMSMQEvent
    {
        CONST_VTBL struct IMSMQEventVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMSMQEvent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMSMQEvent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMSMQEvent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMSMQEvent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMSMQEvent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMSMQEvent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMSMQEvent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IMSMQEvent_INTERFACE_DEFINED__ */


#ifndef ___DMSMQEventEvents_DISPINTERFACE_DEFINED__
#define ___DMSMQEventEvents_DISPINTERFACE_DEFINED__

/****************************************
 * Generated header for dispinterface: _DMSMQEventEvents
 * at Mon Jan 20 11:53:16 2003
 * using MIDL 3.02.88
 ****************************************/
/* [hidden][uuid] */ 



EXTERN_C const IID DIID__DMSMQEventEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    interface DECLSPEC_UUID("D7D6E078-DCCD-11D0-AA4B-0060970DEBAE")
    _DMSMQEventEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _DMSMQEventEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            _DMSMQEventEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            _DMSMQEventEvents __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            _DMSMQEventEvents __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            _DMSMQEventEvents __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            _DMSMQEventEvents __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            _DMSMQEventEvents __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            _DMSMQEventEvents __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } _DMSMQEventEventsVtbl;

    interface _DMSMQEventEvents
    {
        CONST_VTBL struct _DMSMQEventEventsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _DMSMQEventEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _DMSMQEventEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _DMSMQEventEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _DMSMQEventEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _DMSMQEventEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _DMSMQEventEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _DMSMQEventEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___DMSMQEventEvents_DISPINTERFACE_DEFINED__ */


#ifndef __IMSMQManagement_INTERFACE_DEFINED__
#define __IMSMQManagement_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IMSMQManagement
 * at Mon Jan 20 11:53:16 2003
 * using MIDL 3.02.88
 ****************************************/
/* [object][oleautomation][dual][hidden][uuid] */ 



EXTERN_C const IID IID_IMSMQManagement;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("CA85C58C-6F19-49C7-B5A1-7D2191E192E5")
    IMSMQManagement : public IDispatch
    {
    public:
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_Type( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrType) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_PrivateQueueCount( 
            /* [retval][out] */ long __RPC_FAR *plCount) = 0;
        
        virtual /* [propget][id] */ HRESULT STDMETHODCALLTYPE get_PrivateQueue( 
            /* [in] */ long lIndex,
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoQueue) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Refresh( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMSMQManagementVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMSMQManagement __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMSMQManagement __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMSMQManagement __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IMSMQManagement __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IMSMQManagement __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IMSMQManagement __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IMSMQManagement __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Type )( 
            IMSMQManagement __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrType);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PrivateQueueCount )( 
            IMSMQManagement __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *plCount);
        
        /* [propget][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_PrivateQueue )( 
            IMSMQManagement __RPC_FAR * This,
            /* [in] */ long lIndex,
            /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoQueue);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Refresh )( 
            IMSMQManagement __RPC_FAR * This);
        
        END_INTERFACE
    } IMSMQManagementVtbl;

    interface IMSMQManagement
    {
        CONST_VTBL struct IMSMQManagementVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMSMQManagement_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMSMQManagement_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMSMQManagement_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMSMQManagement_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IMSMQManagement_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IMSMQManagement_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IMSMQManagement_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IMSMQManagement_get_Type(This,pbstrType)	\
    (This)->lpVtbl -> get_Type(This,pbstrType)

#define IMSMQManagement_get_PrivateQueueCount(This,plCount)	\
    (This)->lpVtbl -> get_PrivateQueueCount(This,plCount)

#define IMSMQManagement_get_PrivateQueue(This,lIndex,ppqinfoQueue)	\
    (This)->lpVtbl -> get_PrivateQueue(This,lIndex,ppqinfoQueue)

#define IMSMQManagement_Refresh(This)	\
    (This)->lpVtbl -> Refresh(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQManagement_get_Type_Proxy( 
    IMSMQManagement __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrType);


void __RPC_STUB IMSMQManagement_get_Type_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQManagement_get_PrivateQueueCount_Proxy( 
    IMSMQManagement __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *plCount);


void __RPC_STUB IMSMQManagement_get_PrivateQueueCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [propget][id] */ HRESULT STDMETHODCALLTYPE IMSMQManagement_get_PrivateQueue_Proxy( 
    IMSMQManagement __RPC_FAR * This,
    /* [in] */ long lIndex,
    /* [retval][out] */ IMSMQQueueInfo __RPC_FAR *__RPC_FAR *ppqinfoQueue);


void __RPC_STUB IMSMQManagement_get_PrivateQueue_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IMSMQManagement_Refresh_Proxy( 
    IMSMQManagement __RPC_FAR * This);


void __RPC_STUB IMSMQManagement_Refresh_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMSMQManagement_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_MSMQApplication;

#ifdef __cplusplus

class DECLSPEC_UUID("E7D6E086-DCCD-11D0-AA4B-0060970DEBAE")
MSMQApplication;
#endif

EXTERN_C const CLSID CLSID_MSMQQueueInfo;

#ifdef __cplusplus

class DECLSPEC_UUID("E7D6E07C-DCCD-11D0-AA4B-0060970DEBAE")
MSMQQueueInfo;
#endif

EXTERN_C const CLSID CLSID_MSMQQueue;

#ifdef __cplusplus

class DECLSPEC_UUID("E7D6E079-DCCD-11D0-AA4B-0060970DEBAE")
MSMQQueue;
#endif

EXTERN_C const CLSID CLSID_MSMQMessage;

#ifdef __cplusplus

class DECLSPEC_UUID("E7D6E075-DCCD-11D0-AA4B-0060970DEBAE")
MSMQMessage;
#endif

EXTERN_C const CLSID CLSID_MSMQEvent;

#ifdef __cplusplus

class DECLSPEC_UUID("E7D6E07A-DCCD-11D0-AA4B-0060970DEBAE")
MSMQEvent;
#endif

EXTERN_C const CLSID CLSID_MSMQManagement;

#ifdef __cplusplus

class DECLSPEC_UUID("E8D91F44-F576-4231-BF07-0E471318141B")
MSMQManagement;
#endif
#endif /* __MSMQ_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
