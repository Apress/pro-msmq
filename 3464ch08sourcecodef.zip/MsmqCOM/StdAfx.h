/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#if !defined(AFX_STDAFX_H__8A401F90_1B4B_4D82_9E79_49CAAA9DFDE4__INCLUDED_)
#define AFX_STDAFX_H__8A401F90_1B4B_4D82_9E79_49CAAA9DFDE4__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef STRICT
#define STRICT
#endif

#if _WIN32_WCE == 201
#error ATL is not supported for Palm-Size PC
#endif


#define _WIN32_WINNT 0x0400
#define _ATL_FREE_THREADED
#if defined(_WIN32_WCE)    
#undef _WIN32_WINNT        
#endif



#include <atlbase.h>
//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module
extern CComModule _Module;
#include <atlcom.h>
#include <atlwin.h>


//  MSMQ C API
#include <mq.h>


// time_t to DATE conversion deltas
#define UTC_DATE_DELTA          25569.0             // Delta from 12/30/1899 to 1/1/1970
#define UTC_DAYSECS             (24.0*60.0*60.0)    // Number of seconds in a day


//  Helper function for QI for *this pointer to object given an interface ptr
inline
HRESULT WINAPI _This(void* pv, REFIID iid, void** ppvObject, DWORD)
{
    ATLASSERT(iid == IID_NULL);
    *ppvObject = pv;
    return S_OK;
}

#define COM_INTERFACE_ENTRY_THIS() COM_INTERFACE_ENTRY_FUNC(IID_NULL, 0, _This)



//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__8A401F90_1B4B_4D82_9E79_49CAAA9DFDE4__INCLUDED)
