/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

//
//  Includes
//
#include "stdafx.h"
#include "MsmqCOM.h"
#include "MsmqApplication.h"


//
//  Constants
//
#define MSMQAPP_NUMPROPS_GET        1


//-------------------------------------------------------------------------------
CMsmqApplication::CMsmqApplication()                
{
}

//-------------------------------------------------------------------------------
HRESULT CMsmqApplication::FinalConstruct()
{
    HRESULT hr = S_OK;

    return(hr);
}

//-------------------------------------------------------------------------------
void CMsmqApplication::FinalRelease()
{
}

//-------------------------------------------------------------------------------
STDMETHODIMP CMsmqApplication::MachineIdOfMachineName(BSTR MachineName, BSTR * pbstrGuid)
{
    HRESULT         hr;
	MQQMPROPS	    mp;
	PROPID			aPropID[MSMQAPP_NUMPROPS_GET];
	PROPVARIANT		aPropVar[MSMQAPP_NUMPROPS_GET];
	int				i = 0;
    CLSID           guidMachineID;


    //  Get the properties of the machine
	aPropID[i]          = PROPID_QM_MACHINE_ID;        // 0
    aPropVar[i].vt      = VT_CLSID;
    aPropVar[i].puuid   = &guidMachineID;
    i++;

    //  Initialize the MQQUEUEPROPS structure
	mp.cProp    = i;
	mp.aPropID  = aPropID;
	mp.aPropVar = aPropVar;
	mp.aStatus  = NULL;


    //  Get the machine properties
    hr = MQGetMachineProperties( NULL, NULL, &mp );
    if( FAILED(hr) )
    {
		ATLTRACE( _T("MQGetMachineProperties failed  %x\r\n"), hr ); 
		return hr;
	}
  

    //  Convert the GUID to a BSTR and return
    LPOLESTR    strGUID = NULL;

    *pbstrGuid = NULL;
    hr = ::StringFromIID(guidMachineID, &strGUID );
    if( SUCCEEDED(hr) )
    {
        //  Strip the leading and trailing brackets
        strGUID[37] = 0;            
        *pbstrGuid = ::SysAllocString(&strGUID[1]);
        ::CoTaskMemFree(strGUID);
    }

    //  Return status
    return S_OK;
}
