// Setup.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "ce_setup.h"


BOOL    RunMsmqAdm( WCHAR* strCommandLine );


//-------------------------------------------------------------------------------
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{    
    return TRUE;
}

//-------------------------------------------------------------------------------
codeINSTALL_INIT Install_Init(
  HWND    hwndParent,
  BOOL    fFirstCall,
  BOOL    fPreviouslyInstalled,
  LPCTSTR pszInstallDir)
{
    //  No pre-installation steps
    return codeINSTALL_INIT_CONTINUE;
}

//-------------------------------------------------------------------------------
codeINSTALL_EXIT Install_Exit(
  HWND    hwndParent,
  LPCTSTR pszInstallDir,
  WORD    cFailedDirs,
  WORD    cFailedFiles,
  WORD    cFailedRegKeys,
  WORD    cFailedRegVals,
  WORD    cFailedShortcuts)
{
    BOOL    bResult;

    //  Post installation -
    //
    //      Run msmqadm.exe to register and create a new GUID
    //      Inform user to reboot

    bResult = RunMsmqAdm( TEXT("-f \\temp\\msmqadm.txt register install netreg") );
    if( !bResult )
    {
        ::MessageBox( hwndParent, 
                        TEXT("Error installing MSMQ."),
                        TEXT("MSMQ Setup"),
                        MB_OK );
        return codeINSTALL_EXIT_UNINSTALL;
    }

    bResult = RunMsmqAdm( TEXT("-f \\temp\\msmqadm.txt register") );
    if( !bResult )
    {
        ::MessageBox( hwndParent, 
                        TEXT("Error installing MSMQ."),
                        TEXT("MSMQ Setup"),
                        MB_OK );
        return codeINSTALL_EXIT_UNINSTALL;
    }


    //  Reboot message
    ::MessageBox( hwndParent, 
                    TEXT("Please reset your PocketPC to complete the MSMQ install."),
                    TEXT("MSMQ Setup"),
                    MB_OK );

    return codeINSTALL_EXIT_DONE;
}

//-------------------------------------------------------------------------------
codeUNINSTALL_INIT Uninstall_Init(HWND hwndParent, LPCTSTR pszInstallDir)
{
    BOOL    bResult;
	TCHAR	tcFileName[MAX_PATH];

	//	Uninstall is in two steps
	//
	//	1) Stop and clean up MSMQ.  Then have user reset system to remove MSMQ and NETREGD
	//	   DLLs from device.exe that is running (preventing the removal of the files)
	//	2) Complete the removal by allowing CAB setup to finish deleting files


	//	Check for flag file
	_tcscpy( tcFileName, pszInstallDir );
	_tcscat( tcFileName, TEXT("msmq_uninstall") );

	if( ::GetFileAttributes(tcFileName) == 0xFFFFFFFF )
	{
		//  Step #1 - Run msmqadm.exe to stop and clean up MSMQ
		bResult = RunMsmqAdm( TEXT("-f \\temp\\msmqadm.txt stop") );
		if( !bResult )
		{
			::MessageBox( hwndParent, 
							TEXT("Error stopping MSMQ."),
							TEXT("MSMQ Uninstall"),
							MB_OK );
			return codeUNINSTALL_INIT_CANCEL;
		}

		bResult = RunMsmqAdm( TEXT("-f \\temp\\msmqadm.txt register cleanup") );
		if( !bResult )
		{
			::MessageBox( hwndParent, 
							TEXT("Error removing MSMQ."),
							TEXT("MSMQ Uninstall"),
							MB_OK );
			return codeUNINSTALL_INIT_CANCEL;
		}

		bResult = RunMsmqAdm( TEXT("-f \\temp\\msmqadm.txt register uninstall") );
		if( !bResult )
		{
			::MessageBox( hwndParent, 
							TEXT("Error removing MSMQ."),
							TEXT("MSMQ Uninstall"),
							MB_OK );
			return codeUNINSTALL_INIT_CANCEL;
		}

		//	Create flag file
		::CreateFile( tcFileName, GENERIC_READ|GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL );

		//  Reboot message
		::MessageBox( hwndParent, 
						TEXT("Please reset your PocketPC and rerun the uninstall to completely remove all files."),
						TEXT("MSMQ Setup"),
						MB_OK );

		return codeUNINSTALL_INIT_CANCEL;
	}
	else
	{
		//	Step #2 - Delete the flag file and complete uninstall
		::DeleteFile( tcFileName );
	}

    return codeUNINSTALL_INIT_CONTINUE;
}

//-------------------------------------------------------------------------------
codeUNINSTALL_EXIT Uninstall_Exit(HWND hwndParent)
{
    //  No other steps
    return codeUNINSTALL_EXIT_DONE;
}


//-------------------------------------------------------------------------------
BOOL    RunMsmqAdm( WCHAR* strCommandLine )
{
    BOOL                    bResult;
    DWORD                   dwResult;
    PROCESS_INFORMATION     processInfo;


    //  Execute the MSMQADM.EXE application
    bResult = ::CreateProcess(
                    TEXT("MSMQADM.EXE"),
                    strCommandLine,
                    NULL,
                    NULL,
                    FALSE,
                    0,
                    NULL,
                    NULL,
                    NULL,
                    &processInfo );

    if( bResult == FALSE )
        return FALSE;

    //  Wait on the process handle to get signalled (when that process exits)        
    dwResult = ::WaitForSingleObject( processInfo.hProcess, 5000 );
    bResult = (dwResult == WAIT_OBJECT_0) ? TRUE : FALSE;


    // Close process and thread handles. 
    ::CloseHandle( processInfo.hProcess );
    ::CloseHandle( processInfo.hThread );

    //  Return result
    return bResult;
}

