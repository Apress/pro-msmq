Programming MSMQ on the PocketPC

by: Ken Rabold

Version: 1.3

Readme file for MSMQ COM object, MSMQAdmin program and HelloWorld eVB example.



Installing MSMQ, MsmqAdmin and HelloWorld samples.
---------------------------------------

This zip file contains CAB files for each PocketPC processor.  The CAB files contain all
the binaries for MSMQ, MSMQ COM component, MSMQAdmin and the HelloWorld sample VB project.  
To install the CAB files, run the instcab.bat file located in the cab subdirectory.  You 
will need to change the path to the CEAppMgr.exe and MSMQ.ini files.  CEAppMgr.exe will 
install and register MSMQ on your PocketPC.  After installing, you will need to reset your 
device.



Compiling MSMQ COM component MsmqAdmin program - 
----------------------------------------------

1) Use the MSMQ_PocketPC.vcw workspace file to open up the eVC projects for the MSMQ COM object,
   MsmqAdmin and setup DLL projects.

2) Compile any of the projects for the PocketPC platform and the processor of your device.

3) You can have eVC automatically download the COM object and register it on your device.


Compiling the Hello MSMQ World eVB Program -
------------------------------------------

1) Open the HelloWorld.ebp project file.

2) Change the strRemoteComputer constant to the name of the remote MSMQ computer you want 
   to send messages to.

3) Compile the program using File -> Make HelloWorld.vb.

4) You can download the program to your PocketPC and run it under debug as well.


Compiling the Setup.dll and CAB files -
-------------------------------------

The purpose of the Setup.dll project is to support installing MSMQ on a PocketPC.  You
can modify the source of this dll as well as the MSMQ.inf and MSMQ.ini files in the cab
directory to incorporate your application as well.

1) Compile the MsmqCOM.dll, MsmqAdmin.exe and Setup.dll projects for each processor.

2) Copy the setup.dll, MsmqCOM.dll and MsmqAdmin.exe files for each processor to their respective 
   directories under the bin directory.

3) Run the buildcab.bat file found in the cab directory.  This batch file will produce the
   cab files for each PocketPC processor.

4) Run the instcab.bat file found in the cab directory.  This batch file will register the
   cab files with ActiveSync.

5) Use ActiveSync's Add/Remove Programs to install the MSMQ components on your PocketPC.



"Programming MSMQ on PocketPC"  Errata
--------------------------------------

1) To enable sending messages to transactional queues on remote computers, you need to append
   the string ";XACTONLY" to the end of the queue pathname.  For example, if the remote private 
   transaction queue "HelloWorldTrans" is on computer name "kenr", you will need to use the pathname

	"kenr\private$\HelloWorld;XACTONLY"

   The HelloWorld eVB sample SendOptions_Click() function has been updated to use this path qualifier.


2) Despite what the Microsoft documentation and my e-book says, transactional support of local
   CE queues is supported!  You can create local queues on your PocketPC that are transactional.
   These transactional queues only support MQ_SINGLE_MESSAGE transactions.  To create a local 
   transactional queue, use the optional Boolean flag on the MsmqQueueInfo.Create method set to True.
   Example:


	Private Sub SendTrans_Click()
    
	    Dim qinfo As MSMQQueueInfo
	    Dim q As MSMQQueue
	    Dim m As MSMQMessage


	    ' Create objects
	    Set qinfo = CreateObject("CE_MSMQ.MSMQQueueInfo")
	    Set m = CreateObject("CE_MSMQ.MSMQMessage")
    
	    ' Create and open local queue for sending
	    qinfo.PathName = ".\private$\HelloWorldTrans"
	    qinfo.Create True
	    Set q = qinfo.Open(MQ_SEND_ACCESS, MQ_DENY_NONE)
  
	    ' Send message
	    m.Label = Text1.Text
	    m.Body = Text1.Text
	    m.Send q, MQ_SINGLE_MESSAGE
  
	    ' Close queue
	    q.Close

	End Sub

   The CE MSMQ COM object has been updated to support local transaction queue.


3)	Added Purge() method to MsmqQueueInfo object.  This method allows you to purge all messages
	from a queue on the device.



Modification History
--------------------

Version 1.3 -

MsmqAdmin\*.*:              Added custom administration program for MSMQ.
cab\msmq.inf:               Updated to install MsmqAdmin program
MsmqCom\MsmqCom.idl:        Added Purge() method to MsmqQueueInfo interface
MsmqCom\msmqqueueinfo.*:    Added Purge() method to MsmqQueueInfo interface
MsmqCom\msmqmessage.cpp:    Fixed bug with getting null Response, Destination and
                            Administration queues
MsmqCom\MsmqCFInterop.cpp:  Added new file to support .NET Compact Framework interop
MsmqCom\MsmqCom.def:        Added new .NET CF interop DLL entry points
Setup\setup.cpp:            Added better uninstall logic to completely remove MSMQ binaries


Version 1.2 -

HelloWorld\form1.ebf:       Added sending Admin and Response queue in options message.
MsmqCom\msmqmessage.cpp:    Fixed bug with sending admin and response queue name in same message


Version 1.1 -

HelloWorld\form1.ebf:       Updated to support transaction queues.
MsmqCom\msmqapplication.cpp Stripped brackets surrounding MachineID GUID
MsmqCom\msmqevent.*:        Updated event hander to use window messages for thread affinity
MsmqCom\msmqmessage.*:      Added work-around for CE MSMQ not supporting buffer overflow
                            Added better support for IStream based objects
                            Fixed bug with response queue name sending
                            Fixed bug with incorrect lengths for label
MsmqCom\msmqqueueinfo.*:    Added support for creating local transactional queues
                            Added support for IsTransactional property

