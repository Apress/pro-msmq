/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using MsmqCE;

namespace Hello_World_CF
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Send;
    
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Send = new System.Windows.Forms.Button();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(16, 16);
            this.textBox1.Size = new System.Drawing.Size(200, 22);
            this.textBox1.Text = "Hello World CF";
            // 
            // Send
            // 
            this.Send.Location = new System.Drawing.Point(16, 56);
            this.Send.Size = new System.Drawing.Size(96, 32);
            this.Send.Text = "Send";
            this.Send.Click += new System.EventHandler(this.Send_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(226, 279);
            this.Controls.Add(this.Send);
            this.Controls.Add(this.textBox1);
            this.Text = "Form1";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void Send_Click(object sender, System.EventArgs e)
        {
            MessageQueue    theQueue;
            string          strLabel,
                            strBody;

            //  Create and open the local message queue for sending
            theQueue = MessageQueue.Create( ".\\private$\\HelloWorldCF", MessageQueue.MQ_SEND_ACCESS );
            
            strLabel = textBox1.Text;
            strBody  = "Body: " + textBox1.Text;
            
            //  Send a message with a string body
            theQueue.Send( strLabel, strBody );
        }
	}
}
