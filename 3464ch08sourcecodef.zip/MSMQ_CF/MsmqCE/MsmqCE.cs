/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

using System;
using System.Runtime.InteropServices;

namespace MsmqCE
{
    /// <summary>
    /// Windows CE Compact Framework MessageQueue class
    /// </summary>
    public class MessageQueue
    {
        //  Queue access flags
        public const int MQ_RECEIVE_ACCESS     = 1;
        public const int MQ_SEND_ACCESS        = 2;
        public const int MQ_PEEK_ACCESS        = 32;


        //
        //  Creates a new local queue on the device
        //  and opens it with receive access.  Returns
        //  message queue object. 
        //
        public static MessageQueue Create( string strPath )
        {
            //  Create and open with recv access
            return MessageQueue.Create( strPath, MQ_RECEIVE_ACCESS );
        }
        
        //
        //  Creates a new local queue on the device
        //  and opens it with given access.  Returns
        //  message queue object. 
        //
        public static MessageQueue Create( string strPath, int iAccess )
        {
            int iResult;
            
            //  Create queue
            iResult = MsmqCOM.MsmqCOM_CreateQueue( strPath );
            if( iResult == 0 )
            {
                //  Open the queue
                return new MessageQueue(strPath, iAccess);
            }
            else
            {
                //  Failed
                return null;
            }
        }
        
        //
        //  Delete the given local queue
        //
        public static void Delete( string strPath )
        {
            MsmqCOM.MsmqCOM_DeleteQueue( strPath );
        }
        
        //
        //  Purge the given local queue of all messages
        //
        public static void Purge( string strPath )
        {
            MsmqCOM.MsmqCOM_PurgeQueue( strPath );
        }
      
 
        //
        //  MessageQueue constructors
        //
        public MessageQueue( string strPath )
        {
            //  Set path
            m_strPath = strPath;
            
            //  Open the queue with recv access
            m_ptrMsmqObjRef = MsmqCOM.MsmqCOM_OpenQueue( strPath, MQ_RECEIVE_ACCESS );            
        }

        public MessageQueue( string strPath, int iAccess )
        {
            //  Set path
            m_strPath = strPath;
            
            //  Open the queue with given access
            m_ptrMsmqObjRef = MsmqCOM.MsmqCOM_OpenQueue( strPath, iAccess );            
        }

        
        //
        //  MessageQueue properties
        //
        public string Path
        {
            get
            {
                return m_strPath;
            }
        }


        //
        //  Send a string message
        //
        public void Send( string strLabel, string strBody )
        {
            MsmqCOM.MsmqCOM_Send( m_ptrMsmqObjRef, strLabel, strBody );           
        }
      
   
        //
        //  Close the open queue
        //
        public void Close()
        {
            if( m_ptrMsmqObjRef != IntPtr.Zero )
                MsmqCOM.MsmqCOM_CloseQueue( m_ptrMsmqObjRef );
                
            m_ptrMsmqObjRef = IntPtr.Zero;                             
        }
      
    
        //
        //  Private attributes
        //
        private string  m_strPath;
        private IntPtr  m_ptrMsmqObjRef;
    }


    //
    //  Internal class wrapper for calling unmanaged MSMQ
    //  functions.
    //  
    internal class MsmqCOM
    {
        [DllImport("MsmqCOM.dll")]
        public static extern int MsmqCOM_CreateQueue( string strPath );

        [DllImport("MsmqCOM.dll")]
        public static extern int MsmqCOM_PurgeQueue( string strPath );

        [DllImport("MsmqCOM.dll")]
        public static extern int MsmqCOM_DeleteQueue( string strPath );

        [DllImport("MsmqCOM.dll")]
        public static extern IntPtr MsmqCOM_OpenQueue( string strPath, int iAccess );

        [DllImport("MsmqCOM.dll")]
        public static extern int MsmqCOM_CloseQueue( IntPtr hQueueHandle );

        [DllImport("MsmqCOM.dll")]
        public static extern int MsmqCOM_Send( IntPtr hQueueHandle, string strLabel, string strBody );
    }
}
