/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#include "stdafx.h"
#include "MsmqAdmin.h"

#include "MsmqAdminDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


//-------------------------------------------------------------------------------
IMPLEMENT_DYNCREATE(CMsmqAdminDoc, CDocument)

BEGIN_MESSAGE_MAP(CMsmqAdminDoc, CDocument)
	//{{AFX_MSG_MAP(CMsmqAdminDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


//-------------------------------------------------------------------------------
CMsmqAdminDoc::CMsmqAdminDoc()
{
}

//-------------------------------------------------------------------------------
CMsmqAdminDoc::~CMsmqAdminDoc()
{
}

//-------------------------------------------------------------------------------
BOOL CMsmqAdminDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}

//-------------------------------------------------------------------------------
void CMsmqAdminDoc::Serialize(CArchive& ar)
{
}


/////////////////////////////////////////////////////////////////////////////
// CMsmqAdminDoc diagnostics

#ifdef _DEBUG
void CMsmqAdminDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMsmqAdminDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

