/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#if !defined(AFX_DIALOGS_H__73A684CD_4E09_4A15_B3A5_4C53E03A3539__INCLUDED_)
#define AFX_DIALOGS_H__73A684CD_4E09_4A15_B3A5_4C53E03A3539__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000



//-------------------------------------------------------------------------------
class CNewQueueDlg : public CDialog
{
// Construction
public:
	CNewQueueDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNewQueueDlg)
	enum { IDD = IDD_NEWQUEUE };
	CString	m_strQueueName;
	BOOL	m_bJournal;
	BOOL	m_bTransactional;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNewQueueDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNewQueueDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//-------------------------------------------------------------------------------
class CSendTestMsg : public CDialog
{
// Construction
public:
	CSendTestMsg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSendTestMsg)
	enum { IDD = IDD_TESTMESSAGE };
	CString	m_strQueueName;
	CString	m_strMsgLabel;
	CString	m_strMsgBody;
	BOOL	m_bTransactional;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSendTestMsg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSendTestMsg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//-------------------------------------------------------------------------------
class CQueuePropsDlg : public CDialog
{
// Construction
public:
	CQueuePropsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CQueuePropsDlg)
	enum { IDD = IDD_QUEUEPROPS };
	CListCtrl	m_ctlList;
	//}}AFX_DATA

    CComPtr<IMSMQQueueInfo> m_spQueueInfo;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQueuePropsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CQueuePropsDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//-------------------------------------------------------------------------------
class CMsgPropsGeneralPg : public CPropertyPage
{
	DECLARE_DYNCREATE(CMsgPropsGeneralPg)

// Construction
public:
	CMsgPropsGeneralPg();
	~CMsgPropsGeneralPg();

// Dialog Data
	//{{AFX_DATA(CMsgPropsGeneralPg)
	enum { IDD = IDD_MSGPROPS_GENERAL };
	CListCtrl	m_ctlList;
	//}}AFX_DATA

	CComPtr<IMSMQMessage>   m_spMessage;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMsgPropsGeneralPg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMsgPropsGeneralPg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//-------------------------------------------------------------------------------
class CMsgPropsBodyPg : public CPropertyPage
{
	DECLARE_DYNCREATE(CMsgPropsBodyPg)

// Construction
public:
	CMsgPropsBodyPg();
	~CMsgPropsBodyPg();

// Dialog Data
	//{{AFX_DATA(CMsgPropsBodyPg)
	enum { IDD = IDD_MSGPROPS_BODY };
	CString	m_strSize;
	CString	m_strBody;
	//}}AFX_DATA

	CComPtr<IMSMQMessage>   m_spMessage;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMsgPropsBodyPg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMsgPropsBodyPg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGS_H__73A684CD_4E09_4A15_B3A5_4C53E03A3539__INCLUDED_)
