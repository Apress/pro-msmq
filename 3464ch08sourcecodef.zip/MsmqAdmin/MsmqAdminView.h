/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/


#if !defined(AFX_MSMQADMINVIEW_H__66FA8B54_40A9_4331_A032_CAF5F91F4A25__INCLUDED_)
#define AFX_MSMQADMINVIEW_H__66FA8B54_40A9_4331_A032_CAF5F91F4A25__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


//
//  Tree item types
//
#define TREEITEM_MASK       0xF0000000
#define TREEITEM_ROOT       0x10000000
#define TREEITEM_QUEUE      0x20000000
#define TREEITEM_MESSAGE    0x30000000


//-------------------------------------------------------------------------------
class CMsmqAdminView : public CTreeView
{
protected: // create from serialization only
	CMsmqAdminView();
	DECLARE_DYNCREATE(CMsmqAdminView)

// Attributes
public:
	CMsmqAdminDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMsmqAdminView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMsmqAdminView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMsmqAdminView)
	afx_msg void OnToolsNewQueue();
	afx_msg void OnToolsProperties();
	afx_msg void OnToolsRefresh();
	afx_msg void OnToolsPurgeQueue();
	afx_msg void OnToolsDeleteQueue();
	afx_msg void OnToolsSendTestMessage();
	afx_msg void OnUpdateToolsProperties(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsRefresh(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsPurgeQueue(CCmdUI* pCmdUI);
	afx_msg void OnUpdateToolsDeleteQueue(CCmdUI* pCmdUI);
	afx_msg void OnContextMenu(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Methods
    HRESULT GetQueue( long lIndex, IMSMQQueueInfo** qInfo );
    HRESULT GetMessage( IMSMQQueueInfo* qInfo, long lIndex, IMSMQMessage** pMsg );

    void    RefreshQueues();
    void    AddQueue( long lIndex, IMSMQQueueInfo* qInfo );
    void    RefreshMessages( HTREEITEM hParent, IMSMQQueueInfo* qInfo );
    void    AddMessage( HTREEITEM hParent, long lIndex, IMSMQMessage* pMsg );
    void    RemoveChildren( HTREEITEM hParent );

    void    ShowQueueProperties( HTREEITEM hItem );
    void    ShowMessageProperties( HTREEITEM hItem );

// Attributes

    HTREEITEM       m_hPrivateQueues;

    CComPtr<IMSMQEvent> m_pEvent;
};

#ifndef _DEBUG  // debug version in MsmqAdminView.cpp
inline CMsmqAdminDoc* CMsmqAdminView::GetDocument()
   { return (CMsmqAdminDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSMQADMINVIEW_H__66FA8B54_40A9_4331_A032_CAF5F91F4A25__INCLUDED_)
