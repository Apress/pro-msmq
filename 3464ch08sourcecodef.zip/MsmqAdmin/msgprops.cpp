// MsgProps.cpp : implementation file
//
#include "stdafx.h"
#include "resource.h"
#include "MsmqAdmin.h"
#include "MsgProps.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMsgPropsGeneralPg property page

IMPLEMENT_DYNCREATE(CMsgPropsGeneralPg, CPropertyPage)

CMsgPropsGeneralPg::CMsgPropsGeneralPg() : CPropertyPage(CMsgPropsGeneralPg::IDD)
{
	//{{AFX_DATA_INIT(CMsgPropsGeneralPg)
	//}}AFX_DATA_INIT
}

CMsgPropsGeneralPg::~CMsgPropsGeneralPg()
{
}

void CMsgPropsGeneralPg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMsgPropsGeneralPg)
	DDX_Control(pDX, IDC_MSGPROPS_GENERAL_LIST, m_ctlList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMsgPropsGeneralPg, CPropertyPage)
	//{{AFX_MSG_MAP(CMsgPropsGeneralPg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CMsgPropsGeneralPg::OnInitDialog() 
{
	CComBSTR					bstrValue;
	CComVariant					varValue;
	LONG						lValue;
	CString						strBuffer;
	CComPtr<IMSMQQueueInfo>		spQueueInfo;


	//	Initialize the base class
	CPropertyPage::OnInitDialog();
		
	//	Create Item and Value columns
	m_ctlList.InsertColumn( 0, TEXT("Property"), LVCFMT_LEFT, 110, 0 );
	m_ctlList.InsertColumn( 1, TEXT("Value"),    LVCFMT_LEFT, 400, 1 );


	//	Load the message properties names into the list
	m_ctlList.InsertItem(  0, TEXT("Label") );
	m_ctlList.InsertItem(  1, TEXT("Sent Time") );
	m_ctlList.InsertItem(  2, TEXT("Arrived Time") );
	m_ctlList.InsertItem(  3, TEXT("Body Length") );

	m_ctlList.InsertItem(  4, TEXT("Source Machine GUID") );
	m_ctlList.InsertItem(  5, TEXT("App Specific") );
	m_ctlList.InsertItem(  6, TEXT("Max Time to Reach Queue") );
	m_ctlList.InsertItem(  7, TEXT("Max Time to Receive") );

	m_ctlList.InsertItem(  8, TEXT("Destination Queue") );
	m_ctlList.InsertItem(  9, TEXT("Response Queue") );
	m_ctlList.InsertItem( 10, TEXT("Administration Queue") );

	m_ctlList.InsertItem( 11, TEXT("Class") );
	m_ctlList.InsertItem( 12, TEXT("Ack") );
	m_ctlList.InsertItem( 13, TEXT("Delivery") );
	m_ctlList.InsertItem( 14, TEXT("Trace") );
	m_ctlList.InsertItem( 15, TEXT("Priority") );
	m_ctlList.InsertItem( 16, TEXT("Journal") );


	//	Load the message properties values into the list
	m_spMessage->get_Label( &bstrValue );
	m_ctlList.SetItemText(  0, 1, bstrValue.m_str );
	bstrValue.Empty();

	m_spMessage->get_SentTime( &varValue );
	varValue.ChangeType( VT_BSTR );
	m_ctlList.SetItemText(  1, 1, varValue.bstrVal );
	varValue.Clear();

	m_spMessage->get_ArrivedTime( &varValue );
	varValue.ChangeType( VT_BSTR );
	m_ctlList.SetItemText(  2, 1, varValue.bstrVal );
	varValue.Clear();

	m_spMessage->get_BodyLength( &lValue );
	strBuffer.Format( TEXT("%d"), lValue );
	m_ctlList.SetItemText(  3, 1, strBuffer );

	m_spMessage->get_SourceMachineGuid( &bstrValue );
	m_ctlList.SetItemText(  4, 1, bstrValue.m_str );
	bstrValue.Empty();

	m_spMessage->get_AppSpecific( &lValue );
	strBuffer.Format( TEXT("%d"), lValue );
	m_ctlList.SetItemText(  5, 1, strBuffer );

	m_spMessage->get_MaxTimeToReachQueue( &lValue );
	strBuffer.Format( TEXT("%d secs"), lValue );
	m_ctlList.SetItemText(  6, 1, strBuffer );

	m_spMessage->get_MaxTimeToReceive( &lValue );
	strBuffer.Format( TEXT("%d secs"), lValue );
	m_ctlList.SetItemText(  7, 1, strBuffer );

	
	m_spMessage->get_DestinationQueueInfo( &spQueueInfo );
	if( spQueueInfo )
	{
		CComBSTR	bstrTemp;

		spQueueInfo->get_FormatName( &bstrTemp );
		m_ctlList.SetItemText( 8, 1, bstrTemp.m_str );	
		spQueueInfo.Release();			
	}
	
	m_spMessage->get_ResponseQueueInfo( &spQueueInfo );
	if( spQueueInfo )
	{
		CComBSTR	bstrTemp;

		spQueueInfo->get_FormatName( &bstrTemp );
		m_ctlList.SetItemText( 9, 1, bstrTemp.m_str );	
		spQueueInfo.Release();			
	}
	
	m_spMessage->get_AdminQueueInfo( &spQueueInfo );
	if( spQueueInfo )
	{
		CComBSTR	bstrTemp;

		spQueueInfo->get_FormatName( &bstrTemp );
		m_ctlList.SetItemText( 10, 1, bstrTemp.m_str );	
		spQueueInfo.Release();			
	}
	

	m_spMessage->get_Class( &lValue );
	strBuffer.Format( TEXT("%d"), lValue );
	m_ctlList.SetItemText( 11, 1, strBuffer );

	m_spMessage->get_Ack( &lValue );
	strBuffer.Format( TEXT("%d"), lValue );
	m_ctlList.SetItemText( 12, 1, strBuffer );

	m_spMessage->get_Delivery( &lValue );
	strBuffer.Format( TEXT("%d"), lValue );
	m_ctlList.SetItemText( 13, 1, strBuffer );

	m_spMessage->get_Trace( &lValue );
	strBuffer.Format( TEXT("%d"), lValue );
	m_ctlList.SetItemText( 14, 1, strBuffer );

	m_spMessage->get_Priority( &lValue );
	strBuffer.Format( TEXT("%d"), lValue );
	m_ctlList.SetItemText( 15, 1, strBuffer );

	m_spMessage->get_Journal( &lValue );
	strBuffer.Format( TEXT("%d"), lValue );
	m_ctlList.SetItemText( 16, 1, strBuffer );


	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMsgPropsBodyPg property page

IMPLEMENT_DYNCREATE(CMsgPropsBodyPg, CPropertyPage)

CMsgPropsBodyPg::CMsgPropsBodyPg() : CPropertyPage(CMsgPropsBodyPg::IDD)
{
	//{{AFX_DATA_INIT(CMsgPropsBodyPg)
	m_strSize = _T("");
	m_strBody = _T("");
	//}}AFX_DATA_INIT
}

CMsgPropsBodyPg::~CMsgPropsBodyPg()
{
}

void CMsgPropsBodyPg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMsgPropsBodyPg)
	DDX_Text(pDX, IDC_MSGPROPS_BODY_SIZE, m_strSize);
	DDX_Text(pDX, IDC_MSGPROPS_BODY_TEXT, m_strBody);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMsgPropsBodyPg, CPropertyPage)
	//{{AFX_MSG_MAP(CMsgPropsBodyPg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMsgPropsBodyPg message handlers


BOOL CMsgPropsBodyPg::OnInitDialog() 
{
    HRESULT		hr;
	LONG		lBodyLength;
	CComVariant	varBody;
    UCHAR*		pucBodyBuffer = NULL;
    HGLOBAL		hStreamMem = NULL;
	int			iTabStop = 192;

	//	Initialize the base class
	CPropertyPage::OnInitDialog();
	
	//	Set the tab stop for the body text control
	GetDlgItem(IDC_MSGPROPS_BODY_TEXT)->SendMessage( EM_SETTABSTOPS, 1, (LPARAM)(LPINT) &iTabStop );


	//	Get length of body
	m_spMessage->get_BodyLength( &lBodyLength );
	m_strSize.Format( TEXT("%d"), lBodyLength );
	

	//	Get body
	hr = m_spMessage->get_Body( &varBody );
	if( SUCCEEDED(hr) )
	{
		//	Convert body variant to bytes for display
		switch( varBody.vt )
		{
			case VT_I1:
			case VT_I2:
			case VT_I4:
			case VT_UI1:
			case VT_UI2:
			case VT_UI4:
			case VT_R4:
			case VT_R8:
			case VT_CY:
			case VT_DATE:
			case VT_BSTR:
			case VT_BOOL:
			case VT_ARRAY|VT_UI1:
				//	Displayable types
				hr = varBody.ChangeType( VT_ARRAY|VT_UI1 );
				if( SUCCEEDED(hr) )
				{
					lBodyLength = varBody.parray->rgsabound[0].cElements;
					pucBodyBuffer = (UCHAR*) varBody.parray->pvData;
				}
				break;

			case VT_UNKNOWN:
			case VT_DISPATCH:
				//	Must stream object to memory
				break;

			default:
				//	Do nothing
				break;
		}
	}

	//	Display body contents (up to 256 bytes)
	if( lBodyLength && pucBodyBuffer )
	{
		LONG		i;
		CString		strTemp,
					strHex,
					strText;

		for( i = 0; i < lBodyLength && i < 256; i++ )
		{
			strTemp.Format( TEXT("%.2X "), pucBodyBuffer[i] );
			strHex += strTemp;

			strTemp.Format( TEXT("%c "), isalnum(pucBodyBuffer[i]) ? pucBodyBuffer[i] : TEXT('.') );
			strText += strTemp;

			if( (i+1) % 16 == 0 )
			{
				m_strBody += strHex + TEXT("\t") + strText + TEXT("\r\n");
				strHex.Empty();
				strText.Empty();
			}
		}

		if( i % 16 != 0 )
		{
			//	Last line
			m_strBody += strHex + TEXT("\t") + strText + TEXT("\r\n");
		}
	}
	

	//	Update the display
	UpdateData( FALSE );

	return TRUE;
}
