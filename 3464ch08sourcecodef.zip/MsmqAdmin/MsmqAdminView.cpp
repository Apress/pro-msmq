/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/

#include "stdafx.h"
#include "MsmqAdmin.h"

#include "MsmqAdminDoc.h"
#include "MsmqAdminView.h"
#include "Dialogs.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//-------------------------------------------------------------------------------
IMPLEMENT_DYNCREATE(CMsmqAdminView, CTreeView)

BEGIN_MESSAGE_MAP(CMsmqAdminView, CTreeView)
	//{{AFX_MSG_MAP(CMsmqAdminView)
	ON_COMMAND(ID_TOOLS_NEWQUEUE, OnToolsNewQueue)
	ON_COMMAND(ID_TOOLS_PROPERTIES, OnToolsProperties)
	ON_COMMAND(ID_TOOLS_REFRESH, OnToolsRefresh)
	ON_COMMAND(ID_TOOLS_PURGEQUEUE, OnToolsPurgeQueue)
	ON_COMMAND(ID_TOOLS_DELETEQUEUE, OnToolsDeleteQueue)
	ON_COMMAND(ID_TOOLS_SENDTESTMESSAGE, OnToolsSendTestMessage)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_PROPERTIES, OnUpdateToolsProperties)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_REFRESH, OnUpdateToolsRefresh)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_PURGEQUEUE, OnUpdateToolsPurgeQueue)
	ON_UPDATE_COMMAND_UI(ID_TOOLS_DELETEQUEUE, OnUpdateToolsDeleteQueue)
	ON_NOTIFY_REFLECT(GN_CONTEXTMENU, OnContextMenu)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



//-------------------------------------------------------------------------------
CMsmqAdminView::CMsmqAdminView()
{
}

//-------------------------------------------------------------------------------
CMsmqAdminView::~CMsmqAdminView()
{
}

//-------------------------------------------------------------------------------
BOOL CMsmqAdminView::PreCreateWindow(CREATESTRUCT& cs)
{
    //  Add tree control style
    cs.style |= TVS_HASLINES | TVS_HASBUTTONS | TVS_LINESATROOT;
    return CTreeView::PreCreateWindow(cs);
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnDraw(CDC* pDC)
{
	CMsmqAdminDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();

    //  Create root tree item
    m_hPrivateQueues = GetTreeCtrl().InsertItem( OLESTR("Private Queues") );
	if( m_hPrivateQueues )
	{ 
		GetTreeCtrl().SetItemData( m_hPrivateQueues, TREEITEM_ROOT );
	}

    //  Populate the private queue list
    RefreshQueues();
}


//-------------------------------------------------------------------------------
#ifdef _DEBUG
void CMsmqAdminView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CMsmqAdminView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CMsmqAdminDoc* CMsmqAdminView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMsmqAdminDoc)));
	return (CMsmqAdminDoc*)m_pDocument;
}
#endif //_DEBUG



//-------------------------------------------------------------------------------
void CMsmqAdminView::OnToolsNewQueue() 
{
	CNewQueueDlg    dlg;

    //  Show New Queue dialog
	if( dlg.DoModal() == IDOK )
    {
        HRESULT                 hr;
        CComPtr<IMSMQQueueInfo> spQueueInfo;
        CComBSTR                bstrQueueName(OLESTR(".\\private$\\"));


        //  Append the queue name to the private$
        bstrQueueName += CComBSTR(dlg.m_strQueueName);

        //  Create a queueInfo object
        hr = spQueueInfo.CoCreateInstance( CLSID_MSMQQueueInfo );
        if( FAILED(hr) )
            return;

        //  Initialize with path name and journal info
        hr = spQueueInfo->put_PathName( bstrQueueName );
        if( FAILED(hr) )
            return;

        hr = spQueueInfo->put_Journal( (dlg.m_bJournal) ? 1 : 0 );
        if( FAILED(hr) )
            return;


        //  Create the queue
		hr = spQueueInfo->Create( (dlg.m_bJournal) ? VARIANT_TRUE : VARIANT_FALSE, VARIANT_FALSE );        
		if( FAILED(hr) )
			return;


        //  Refresh the tree
        RefreshQueues();
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnToolsProperties() 
{
    HTREEITEM   hItem;

	//  Get the currently selected item
    hItem = GetTreeCtrl().GetSelectedItem();
    if( hItem )
    {
        DWORD dwItemType = GetTreeCtrl().GetItemData(hItem);

        //  Activate the menu item if it has properties
        switch( dwItemType & TREEITEM_MASK )
        {
            case TREEITEM_QUEUE:
                //  Get the properties of the queue
                ShowQueueProperties( hItem );
                break;

            case TREEITEM_MESSAGE:
                //  Get the properties of the message
                ShowMessageProperties( hItem );
                break;

            default:
                break;
        }
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnToolsRefresh() 
{
    HTREEITEM   hItem;

	//  Get the currently selected item
    hItem = GetTreeCtrl().GetSelectedItem();
    if( hItem )
    {
        DWORD dwItemType = GetTreeCtrl().GetItemData(hItem);

        //  Activate the menu item if it has properties
        switch( dwItemType & TREEITEM_MASK )
        {
            case TREEITEM_ROOT:
                //  Refresh whole queue list
                RefreshQueues();
                break;

            case TREEITEM_QUEUE:
                //  Refresh all messages in selected queue
                {
                    HRESULT                     hr;
                    long                        lIndex = dwItemType & ~TREEITEM_MASK;
                    CComPtr<IMSMQQueueInfo>     spQueueInfo;

                    //  Get the queue info object
                    hr = GetQueue( lIndex, &spQueueInfo );
                    if( FAILED(hr) )
                        return;

                    //  Refresh the messages
                    RefreshMessages( hItem, spQueueInfo );
                }
                break;

            default:
                break;
        }
    }
}


//-------------------------------------------------------------------------------
void CMsmqAdminView::OnToolsPurgeQueue() 
{
    //  Confirm delete queue operation
    if( AfxMessageBox(IDS_PURGECONFIRM, MB_YESNO|MB_ICONEXCLAMATION) == IDYES )
    {
        HTREEITEM   hItem;

	    //  Get the currently selected item
        hItem = GetTreeCtrl().GetSelectedItem();
        if( hItem )
        {
            HRESULT                     hr;
            DWORD                       dwItemType = GetTreeCtrl().GetItemData(hItem);
            long                        lIndex = dwItemType & ~TREEITEM_MASK;
            CComPtr<IMSMQQueueInfo>     spQueueInfo;


            //  Get the queue info object
            hr = GetQueue( lIndex, &spQueueInfo );
            if( FAILED(hr) )
                return;

            //  Purge the queue
            hr = spQueueInfo->Purge();
            if( FAILED(hr) )
                return;

			//	Refresh the tree
			RefreshQueues();
        }
    }	
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnToolsDeleteQueue() 
{
    //  Confirm delete queue operation
    if( AfxMessageBox(IDS_DELETECONFIRM, MB_YESNO|MB_ICONEXCLAMATION) == IDYES )
    {
        HTREEITEM   hItem;

	    //  Get the currently selected item
        hItem = GetTreeCtrl().GetSelectedItem();
        if( hItem )
        {
            HRESULT                     hr;
            DWORD                       dwItemType = GetTreeCtrl().GetItemData(hItem);
            long                        lIndex = dwItemType & ~TREEITEM_MASK;
            CComPtr<IMSMQQueueInfo>     spQueueInfo;

            //  Get the queue info object
            hr = GetQueue( lIndex, &spQueueInfo );
            if( FAILED(hr) )
                return;

            //  Delete the queue
            spQueueInfo->Delete();

            //  Refresh the queue list
            RefreshQueues();
        }
    }	
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnToolsSendTestMessage() 
{
    CSendTestMsg    dlg;	
	
    //  Show dialog
	if( dlg.DoModal() == IDOK )
    {
        HRESULT                 hr;
        CComBSTR                bstrPath(dlg.m_strQueueName),
                                bstrLabel(dlg.m_strMsgLabel),
                                bstrBody(dlg.m_strMsgBody);
        CComPtr<IMSMQQueueInfo> spQueueInfo;
        CComPtr<IMSMQQueue>     spQueue;
        CComPtr<IMSMQMessage>   spMessage;
        CComVariant             varXact(0);


        //  Create a queue info object
        hr = spQueueInfo.CoCreateInstance( CLSID_MSMQQueueInfo );
        if( FAILED(hr) )
            return;

		//	Check for transactional flag
		if( dlg.m_bTransactional )
		{
			//	Need to append ";XACTONLY" to path
			bstrPath += TEXT(";XACTONLY");

			//	Need to send message with CE_MQ_SINGLE_MESSAGE
			varXact = CE_MQ_SINGLE_MESSAGE;
		}
	
        //  Open the queue
        hr = spQueueInfo->put_PathName( bstrPath );
        if( FAILED(hr) )
            return;

        hr = spQueueInfo->Open( CE_MQ_SEND_ACCESS, CE_MQ_DENY_NONE, &spQueue );
        if( FAILED(hr) )
            return;

        //  Create a message object
        hr = spMessage.CoCreateInstance( CLSID_MSMQMessage );
        if( FAILED(hr) )
            return;

        spMessage->put_Label( bstrLabel );
        spMessage->put_Body( CComVariant(bstrBody) );

        //  Send the message
        hr = spMessage->Send( spQueue, &varXact );
        if( FAILED(hr) )
            return;
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnContextMenu(NMHDR* pNMHDR, LRESULT* pResult)
{
	NMRGINFO*	pnmhdr = reinterpret_cast <NMRGINFO*>(pNMHDR);
	POINT		point = pnmhdr->ptAction;
    HTREEITEM   hItem;
	CMenu		menu,
				*pPopupMenu = NULL;


	//  Get the currently selected item
    hItem = GetTreeCtrl().GetSelectedItem();
    if( hItem )
    {
        DWORD dwItemType = GetTreeCtrl().GetItemData(hItem);

		//	Load the pop-up menu resource
		menu.LoadMenu( IDR_POPUPMENUS );

        //  Get the correct pop-menu for the item selected
        switch( dwItemType & TREEITEM_MASK )
        {
            case TREEITEM_ROOT:
				//	Root pop-up menu
				pPopupMenu = menu.GetSubMenu(0);
				break;

            case TREEITEM_QUEUE:
				//	Queue pop-up menu
				pPopupMenu = menu.GetSubMenu(1);
                break;

            case TREEITEM_MESSAGE:
				//	Message pop-up menu
				pPopupMenu = menu.GetSubMenu(2);
                break;

            default:
                break;
        }

		//	Display the pop-up
		if( pPopupMenu )
			pPopupMenu->TrackPopupMenu( TPM_RIGHTALIGN|TPM_TOPALIGN|TPM_NONOTIFY, point.x, point.y, this );
    }
}


//-------------------------------------------------------------------------------
void CMsmqAdminView::OnUpdateToolsProperties(CCmdUI* pCmdUI) 
{
    HTREEITEM   hItem;

	//  Get the currently selected item
    hItem = GetTreeCtrl().GetSelectedItem();
    if( hItem )
    {
        DWORD   dwItemType = GetTreeCtrl().GetItemData(hItem);

        //  Activate the menu item if it has properties
        switch( dwItemType & TREEITEM_MASK )
        {
            case TREEITEM_QUEUE:
            case TREEITEM_MESSAGE:
                //  Activate the menu item
                pCmdUI->Enable(TRUE);
                break;

            default:
                //  Deactivate the menu item
                pCmdUI->Enable(FALSE);
                break;
        }
    }	
    else
    {
        //  Deactivate the menu item
        pCmdUI->Enable(FALSE);
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnUpdateToolsRefresh(CCmdUI* pCmdUI) 
{
    HTREEITEM   hItem;

	//  Get the currently selected item
    hItem = GetTreeCtrl().GetSelectedItem();
    if( hItem )
    {
        DWORD   dwItemType = GetTreeCtrl().GetItemData(hItem);

        //  Activate the menu item if it has properties
        switch( dwItemType & TREEITEM_MASK )
        {
            case TREEITEM_ROOT:
            case TREEITEM_QUEUE:
                //  Activate the menu item
                pCmdUI->Enable(TRUE);
                break;

            default:
                //  Deactivate the menu item
                pCmdUI->Enable(FALSE);
                break;
        }
    }	
    else
    {
        //  Deactivate the menu item
        pCmdUI->Enable(FALSE);
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnUpdateToolsPurgeQueue(CCmdUI* pCmdUI) 
{
    HTREEITEM   hItem;

	//  Get the currently selected item
    hItem = GetTreeCtrl().GetSelectedItem();
    if( hItem )
    {
        DWORD   dwItemType = GetTreeCtrl().GetItemData(hItem);

        //  Activate the menu item if it has properties
        switch( dwItemType & TREEITEM_MASK )
        {
            case TREEITEM_QUEUE:
                //  Activate the menu item
                pCmdUI->Enable(TRUE);
                break;

            default:
                //  Deactivate the menu item
                pCmdUI->Enable(FALSE);
                break;
        }
    }	
    else
    {
        //  Deactivate the menu item
        pCmdUI->Enable(FALSE);
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::OnUpdateToolsDeleteQueue(CCmdUI* pCmdUI) 
{
    HTREEITEM   hItem;

	//  Get the currently selected item
    hItem = GetTreeCtrl().GetSelectedItem();
    if( hItem )
    {
        DWORD   dwItemType = GetTreeCtrl().GetItemData(hItem);

        //  Activate the menu item if it has properties
        switch( dwItemType & TREEITEM_MASK )
        {
            case TREEITEM_QUEUE:
                //  Activate the menu item
                pCmdUI->Enable(TRUE);
                break;

            default:
                //  Deactivate the menu item
                pCmdUI->Enable(FALSE);
                break;
        }
    }	
    else
    {
        //  Deactivate the menu item
        pCmdUI->Enable(FALSE);
    }
}


//-------------------------------------------------------------------------------
HRESULT CMsmqAdminView::GetQueue( long lIndex, IMSMQQueueInfo** qInfo )
{
    HRESULT     hr;

    //  Get the queue info object
    hr = theApp.GetQueueMgmt()->get_PrivateQueue( lIndex, qInfo );
    if( FAILED(hr) )
        return hr;

    //  Refresh the object's properties
    hr = (*qInfo)->Refresh();
    if( FAILED(hr) )
        return hr;

    //  Return status
    return hr;
}

//-------------------------------------------------------------------------------
HRESULT CMsmqAdminView::GetMessage( IMSMQQueueInfo* qInfo, long lIndex, IMSMQMessage** pMsg )
{
    HRESULT                 hr;
    CComPtr<IMSMQQueue>     spQueue;
    CComPtr<IMSMQMessage>   spMessage;
    CComVariant             varTimeout(long(0)),
                            varWantDest(true),
                            varWantBody(true);


    //  Open the queue for recv access
    hr = qInfo->Open( CE_MQ_RECEIVE_ACCESS, CE_MQ_DENY_NONE, &spQueue );
    if( FAILED(hr) )
        return hr;

    //  Peek for the first message
    hr = spQueue->PeekCurrent( &varWantDest, &varWantBody, &varTimeout, pMsg );
    if( FAILED(hr) )
        return hr;

    //  Peek at each message
    while( SUCCEEDED(hr) && lIndex-- )
    {
        //  Release the message
        (*pMsg)->Release();

        //  Peek at the next message
        hr = spQueue->PeekNext( &varWantDest, &varWantBody, &varTimeout, pMsg );
    }


    //  Return status
    return hr;
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::RefreshQueues()
{
    HRESULT hr;
    long    i, lCount;


    //  Clear the tree
    RemoveChildren( m_hPrivateQueues );

    //  Refresh the list of queues
    hr = theApp.GetQueueMgmt()->Refresh();
    if( FAILED(hr) )
        return;

    //  Get the number of private queues
    hr = theApp.GetQueueMgmt()->get_PrivateQueueCount( &lCount );
    if( FAILED(hr) )
        return;

    //  Populate the tree
    for( i = 0; i < lCount; i++ )
    {
        CComPtr<IMSMQQueueInfo>     spQueueInfo;

        //  Get the queue info object
        hr = GetQueue( i, &spQueueInfo );
        if( SUCCEEDED(hr) )
        {
            //  Add the queue to the tree
            AddQueue( i, spQueueInfo );
        }
    }     
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::AddQueue( long lIndex, IMSMQQueueInfo* qInfo )
{
    HTREEITEM   hItem;
    CComBSTR    bstrName;


    //  Get the name of the queue
    qInfo->get_FormatName( &bstrName );

    //  Add queue to tree and refresh it's message list
    hItem = GetTreeCtrl().InsertItem( bstrName, m_hPrivateQueues );
    if( hItem )
    {
        //  Set the item type
        GetTreeCtrl().SetItemData( hItem, TREEITEM_QUEUE | lIndex );

        //  Refresh the message items
        RefreshMessages( hItem, qInfo );
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::RefreshMessages( HTREEITEM hParent, IMSMQQueueInfo* qInfo )
{
    HRESULT                 hr;
    CComPtr<IMSMQQueue>     spQueue;
    CComPtr<IMSMQMessage>   spMessage;
    CComVariant             varTimeout(long(0)),
                            varWantDest(false),
                            varWantBody(false);
    long                    lCount = 0;


    //  Clear the tree
    RemoveChildren( hParent );

    //  Open the queue for recv access
    hr = qInfo->Open( CE_MQ_RECEIVE_ACCESS, CE_MQ_DENY_NONE, &spQueue );
    if( FAILED(hr) )
        return;

    //  Peek for the first message
    hr = spQueue->PeekCurrent( &varWantDest, &varWantBody, &varTimeout, &spMessage );
    if( FAILED(hr) )
        return;

    //  Peek at each message
    while( SUCCEEDED(hr) )
    {
        //  Add the message to the tree
        AddMessage( hParent, lCount, spMessage );
        lCount++;

        //  Release the message
        spMessage.Release();

        //  Peek at the next message
        hr = spQueue->PeekNext( &varWantDest, &varWantBody, &varTimeout, &spMessage );
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::AddMessage( HTREEITEM hParent, long lIndex, IMSMQMessage* pMsg )
{
    HTREEITEM       hItem;
    CComBSTR        bstrLabel;
    CComVariant     varID;


    //  Get the label and ID of the message
    pMsg->get_Label( &bstrLabel );
    pMsg->get_Id( &varID );


    //  Create a new message item
    hItem = GetTreeCtrl().InsertItem( bstrLabel, hParent );

    //  Create Queue and Journal messages tree items
    if( hItem )
    {
        //  Set the item type
        GetTreeCtrl().SetItemData( hItem, TREEITEM_MESSAGE | lIndex );
    }
}

//-------------------------------------------------------------------------------
void CMsmqAdminView::RemoveChildren( HTREEITEM hParent )
{
    //  Delete all of the children of hmyItem.
    if( GetTreeCtrl().ItemHasChildren(hParent) )
    {
        HTREEITEM hNextItem;
        HTREEITEM hChildItem = GetTreeCtrl().GetChildItem(hParent);

        while (hChildItem != NULL)
        {
            hNextItem = GetTreeCtrl().GetNextItem(hChildItem, TVGN_NEXT);
            GetTreeCtrl().DeleteItem(hChildItem);
            hChildItem = hNextItem;
        }
    }
}


//-------------------------------------------------------------------------------
void CMsmqAdminView::ShowQueueProperties( HTREEITEM hItem )
{
    HRESULT                 hr;
	CQueuePropsDlg          dlg;
    long                    lQueueIndex = GetTreeCtrl().GetItemData(hItem) & ~TREEITEM_MASK;
    CComPtr<IMSMQQueueInfo> spQueueInfo;


    //  Get the queue info object
    hr = GetQueue( lQueueIndex, &spQueueInfo );
    if( FAILED(hr) )
        return;

    //  Initialize dlg items
	dlg.m_spQueueInfo = spQueueInfo;

    //  Show properties
    dlg.DoModal();
}


//-------------------------------------------------------------------------------
void CMsmqAdminView::ShowMessageProperties( HTREEITEM hItem )
{
    HRESULT                 hr;
    HTREEITEM               hQueueItem = GetTreeCtrl().GetParentItem(hItem);
    long                    lQueueIndex = GetTreeCtrl().GetItemData(hQueueItem) & ~TREEITEM_MASK,
                            lMessageIndex = GetTreeCtrl().GetItemData(hItem) & ~TREEITEM_MASK;
    CComPtr<IMSMQQueueInfo> spQueueInfo;
    CComPtr<IMSMQMessage>   spMessage;
	CPropertySheet          sheet(IDS_MSGPROPS_TITLE);
    CMsgPropsGeneralPg      pageGeneral;
    CMsgPropsBodyPg         pageBody;


    //  Get the queue info object
    hr = GetQueue( lQueueIndex, &spQueueInfo );
    if( FAILED(hr) )
        return;

    //  Get the message object
    hr = GetMessage( spQueueInfo, lMessageIndex, &spMessage );
    if( FAILED(hr) )
        return;


	//	Populate the message properties
	pageGeneral.m_spMessage = spMessage;
	pageBody.m_spMessage = spMessage;

    //  Add the pages to the property sheet
    sheet.AddPage( &pageGeneral );
    sheet.AddPage( &pageBody );

    //  Show properties
    sheet.DoModal();
}


