/*++

THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.

--*/


#include "stdafx.h"
#include "MsmqAdmin.h"

#include "MainFrm.h"
#include "MsmqAdminDoc.h"
#include "MsmqAdminView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CMsmqAdminApp theApp;


//-------------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CMsmqAdminApp, CWinApp)
	//{{AFX_MSG_MAP(CMsmqAdminApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

//-------------------------------------------------------------------------------
CMsmqAdminApp::CMsmqAdminApp()
	: CWinApp()
{
}

//-------------------------------------------------------------------------------
BOOL CMsmqAdminApp::InitInstance()
{
	AfxEnableControlContainer();


    // Create MSMQ Managment object
    HRESULT     hr;

    hr = m_spMsmqManagment.CoCreateInstance( CLSID_MSMQManagement );
    if( FAILED(hr) )
        return FALSE;


	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMsmqAdminDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CMsmqAdminView));
	AddDocTemplate(pDocTemplate);
	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;


	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}

//-------------------------------------------------------------------------------
void CMsmqAdminApp::OnAppAbout()
{
	CAboutDlg   aboutDlg;
    CComBSTR    bstrType;

    m_spMsmqManagment->get_Type( &bstrType );
    aboutDlg.m_strMsmqType = bstrType;
	aboutDlg.m_strMsmqType.Replace(TEXT(" - "), TEXT("\r\n"));
	aboutDlg.DoModal();
}




//-------------------------------------------------------------------------------
BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


//-------------------------------------------------------------------------------
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_strMsmqType = _T("");
	//}}AFX_DATA_INIT
}

//-------------------------------------------------------------------------------
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Text(pDX, IDC_ABOUT_MSMQTYPE, m_strMsmqType);
	//}}AFX_DATA_MAP
}

//-------------------------------------------------------------------------------
BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CenterWindow();
	
	return TRUE;
}
