//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MsmqAdmin.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_EDIT                        102
#define IDS_TOOL                        103
#define IDM_MENU                        104
#define IDR_MAIN_EDIT                   105
#define IDR_MAIN_TOOL                   106
#define IDR_MAINFRAME                   128
#define IDD_NEWQUEUE                    130
#define IDD_TESTMESSAGE                 131
#define IDD_QUEUEPROPS                  132
#define IDD_MSGPROPS_GENERAL            133
#define IDD_MSGPROPS_QUEUES             134
#define IDD_MSGPROPS_SENDER             135
#define IDD_MSGPROPS_BODY               136
#define IDR_POPUPMENUS                  138
#define IDC_NEWQUEUE_NAME               1001
#define IDC_TESTMSG_QUEUE               1002
#define IDC_TESTMSG_LABEL               1003
#define IDC_TESTMSG_BODY                1004
#define IDC_NEWQUEUE_JOURNAL            1005
#define IDC_QUEUEPROPS_NAME             1006
#define IDC_QUEUEPROPS_CREATED          1007
#define IDC_QUEUEPROPS_PATH             1008
#define IDC_QUEUEPROPS_QUOTA            1009
#define IDC_QUEUEPROPS_JOURNAL          1010
#define IDC_MSGPROPS_GENERAL_LABEL      1011
#define IDC_MSGPROPS_GENERAL_ID         1012
#define IDC_MSGPROPS_GENERAL_PRIORITY   1013
#define IDC_MSGPROPS_GENERAL_SENT       1014
#define IDC_MSGPROPS_GENERAL_ARRIVED    1015
#define IDC_MSQPROPS_QUEUES_DEST        1017
#define IDC_MSQPROPS_QUEUES_RESP        1018
#define IDC_MSQPROPS_QUEUES_            1019
#define IDC_MSGPROPS_SENDER_SRCGUID     1020
#define IDC_MSGPROPS_SENDER_APPSPEC     1021
#define IDC_MSGPROPS_SENDER_MAXTIMEREACH 1022
#define IDC_MSGPROPS_SENDER_MAXTIMERECV 1023
#define IDC_MSGPROPS_BODY_SIZE          1024
#define IDC_MSGPROPS_BODY_TEXT          1025
#define IDC_MSGPROPS_GENERAL_TRACKED    1026
#define IDC_QUEUEPROPS_JOURNALQUOTA     1027
#define IDC_ABOUT_MSMQTYPE              1028
#define IDC_NEWQUEUE_TRANSACTIONAL      1031
#define IDC_MSGPROPS_GENERAL_LIST       1035
#define IDC_MSQPROPS_LIST               1036
#define IDC_TESTMSG_TRANSACTIONAL       1037
#define ID_TOOLS_NEWQUEUE               32771
#define ID_TOOLS_DELETEQUEUE            32772
#define ID_TOOLS_PROPERTIES             32773
#define ID_TOOLS_PURGEQUEUE             32774
#define ID_TOOLS_SENDTESTMESSAGE        32775
#define ID_TOOLS_REFRESH                32776
#define ID_ROOT                         32777
#define IDS_CAP_ROOT                    32779
#define ID_QUEUE                        32780
#define IDS_CAP_QUEUE                   32782
#define ID_MESSAGE                      32783
#define IDS_CAP_MESSAGE                 32785
#define IDS_NEW                         65000
#define IDS_FILE                        65001
#define IDS_MHELP                       65002
#define IDS_SAVE                        65003
#define IDS_CUT                         65004
#define IDS_COPY                        65005
#define IDS_PASTE                       65006
#define IDS_ABOUT                       65007
#define IDS_MSGPROPS_TITLE              65008
#define IDS_PURGECONFIRM                65009
#define IDS_DELETECONFIRM               65010
#define IDS_QUEUEPROPS_QUOTA            65011
#define IDS_QUEUEPROPS_JOURNAL          65013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
