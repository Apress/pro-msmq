#if !defined(AFX_MSGPROPS_H__5FE358AD_0623_4344_BC3C_F6012B867062__INCLUDED_)
#define AFX_MSGPROPS_H__5FE358AD_0623_4344_BC3C_F6012B867062__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MsgProps.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMsgPropsGeneralPg dialog

class CMsgPropsGeneralPg : public CPropertyPage
{
	DECLARE_DYNCREATE(CMsgPropsGeneralPg)

// Construction
public:
	CMsgPropsGeneralPg();
	~CMsgPropsGeneralPg();

// Dialog Data
	//{{AFX_DATA(CMsgPropsGeneralPg)
	enum { IDD = IDD_MSGPROPS_GENERAL };
	CListCtrl	m_ctlList;
	//}}AFX_DATA

	CComPtr<IMSMQMessage>   m_spMessage;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMsgPropsGeneralPg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMsgPropsGeneralPg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////
// CMsgPropsBodyPg dialog

class CMsgPropsBodyPg : public CPropertyPage
{
	DECLARE_DYNCREATE(CMsgPropsBodyPg)

// Construction
public:
	CMsgPropsBodyPg();
	~CMsgPropsBodyPg();

// Dialog Data
	//{{AFX_DATA(CMsgPropsBodyPg)
	enum { IDD = IDD_MSGPROPS_BODY };
	CString	m_strSize;
	CString	m_strBody;
	//}}AFX_DATA

	CComPtr<IMSMQMessage>   m_spMessage;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMsgPropsBodyPg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMsgPropsBodyPg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSGPROPS_H__5FE358AD_0623_4344_BC3C_F6012B867062__INCLUDED_)
