SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE Customers_GetByCountry
@Country varchar(20)
AS
SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Country, Phone, Fax
FROM Customers
WHERE Country = @Country
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

