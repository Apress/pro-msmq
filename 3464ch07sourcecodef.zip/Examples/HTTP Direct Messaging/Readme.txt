*************************************************************
	A scalable message-based Application over Internet 

		by Carlos A Walzer

*************************************************************

How to install the example.

You have to:
�	Create the following Stored Procedure into your Northwind example in SQL Server.

CREATE PROCEDURE Customers_GetByCountry
@Country varchar(20)
AS
SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Country, Phone, Fax
FROM Customers
WHERE Country = @Country

or use the Northwind.slq file

�	Create two private queues called RequestQueue and ResponseQueue.
�	Set the Northwind.udl provided to connect to the Northwind database stored in SQL Server.
