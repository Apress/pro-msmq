using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using MSMQ; // COM Interop MSMQ assembly

namespace MSMQ_Handbook___.NET
{

	/// <summary>
	/// This form tests functions used in Chapter 6 of the MSMQ Handbook.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button COMBtn;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.COMBtn = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// COMBtn
			// 
			this.COMBtn.Location = new System.Drawing.Point(8, 8);
			this.COMBtn.Name = "COMBtn";
			this.COMBtn.TabIndex = 0;
			this.COMBtn.Text = "COM";
			this.COMBtn.Click += new System.EventHandler(this.COMClick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(184, 46);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.COMBtn});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void COMEnumMSMQQueueByID(string QueueName, string TargetLabel)
		{
			IMSMQQueueInfo3 myQueueInfo = new MSMQ.MSMQQueueInfoClass();
			IMSMQQueue3 myQueue;
			IMSMQMessage3 myMessage;
			string myLabel = "";

			// MSMQ COM Variant parameters and constants which need conversion
			int mqAccess = (int) MQACCESS.MQ_RECEIVE_ACCESS;
			int mqShare = (int) MQSHARE.MQ_DENY_NONE;
			Object mqFalse = false;
			Object mqNoTransaction = MQTRANSACTION.MQ_NO_TRANSACTION;
			Object mqTrue = true;
			Object mqTimeout = 1000;
			
			// Use the path name to open the queue
			myQueueInfo.PathName = QueueName;
			myQueue = myQueueInfo.Open(mqAccess, mqShare);

			// Peek the first message
			myMessage = myQueue.PeekFirstByLookupId(ref mqFalse, ref mqFalse, 
				ref mqFalse);
			if (myMessage != null)
				myLabel = myMessage.Label;

			// Loop until we find a matching message, or reach the end of the queue
			while ((myLabel != TargetLabel) && (myMessage != null))
			{
				myMessage = myQueue.PeekNextByLookupId(myMessage.LookupId,
					ref mqFalse, ref mqFalse, ref mqFalse);
				myLabel = myMessage.Label;
			};
			
			// Pull the matching message
			myMessage = myQueue.ReceiveByLookupId(myMessage.LookupId, 
				ref mqNoTransaction, ref mqFalse, ref mqTrue, ref mqTimeout);
		}
        
		private void COMClick(object sender, System.EventArgs e)
		{
			COMEnumMSMQQueueByID(".\\Private$\\handbook", "Label");
		}


	}
}
