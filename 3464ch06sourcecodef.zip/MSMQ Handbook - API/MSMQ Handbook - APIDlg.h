// MSMQ Handbook - APIDlg.h : header file
//

#pragma once


// CMSMQHandbookAPIDlg dialog
class CMSMQHandbookAPIDlg : public CDialog
{
// Construction
public:
	CMSMQHandbookAPIDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MSMQHANDBOOKAPI_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedSend();
	afx_msg void OnBnClickedDelete();
	afx_msg void OnBnClickedCreate();
	afx_msg void OnBnClickedReceive();
	afx_msg void OnBnClickedEnumerate();
	afx_msg void OnBnClickedAsyncRecv();
	afx_msg void OnBnClickedEnumlookup();

	void CreateQueue(LPWSTR PathName);
	void DeleteQueue(LPWSTR PathName);
	void SendMSMQMessage(LPWSTR QueueName, LPWSTR Label, LPWSTR Body);
	void ReceiveMSMQMessage(LPWSTR QueueFormatName);
	void ReceiveSingleMessage(QUEUEHANDLE hSrcQueue);
	void EnumerateMSMQQueue(LPWSTR QueueName, LPWSTR Label);
	void EnumMSMQQueueByID(LPWSTR QueueName, LPWSTR Label);

};
