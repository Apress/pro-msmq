// MSMQ Handbook - APIDlg.cpp : implementation file
//

#include "stdafx.h"
#include <mq.h>  // API files
#include "MSMQ Handbook - API.h"
#include "MSMQ Handbook - APIDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMSMQHandbookAPIDlg dialog



CMSMQHandbookAPIDlg::CMSMQHandbookAPIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMSMQHandbookAPIDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMSMQHandbookAPIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CMSMQHandbookAPIDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_Send, OnBnClickedSend)
	ON_BN_CLICKED(IDC_Delete, OnBnClickedDelete)
	ON_BN_CLICKED(IDC_Create, OnBnClickedCreate)
	ON_BN_CLICKED(IDC_Receive, OnBnClickedReceive)
	ON_BN_CLICKED(IDC_ENUMERATE, OnBnClickedEnumerate)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedAsyncRecv)
	ON_BN_CLICKED(IDC_ENUMLOOKUP, OnBnClickedEnumlookup)
END_MESSAGE_MAP()


// CMSMQHandbookAPIDlg message handlers

BOOL CMSMQHandbookAPIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMSMQHandbookAPIDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMSMQHandbookAPIDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMSMQHandbookAPIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CMSMQHandbookAPIDlg::SendMSMQMessage(LPWSTR QueueFormatName, LPWSTR Label, LPWSTR Body)
{
	MQMSGPROPS		Message;
	MSGPROPID		PropID[3];
	MQPROPVARIANT	PropVars[3];
	HRESULT			hrStatus[3];

	// Begin Message initialization
	PropID[0] = PROPID_M_LABEL;
	PropVariantInit(&PropVars[0]);
	PropVars[0].vt = VT_LPWSTR;
	PropVars[0].pwszVal = Label;

	PropID[1] = PROPID_M_BODY;  
	PropVars[1].vt = VT_VECTOR | VT_UI1;
	/* Variant type for body is always a string of bytes to MSMQ
	regardless of what BODY_TYPE says it *actually* is*/
	PropVars[1].caub.pElems = (LPBYTE) Body;
	PropVars[1].caub.cElems = (ULONG) sizeof(WCHAR)*wcslen(Body);  // length of Body string

	PropID[2] = PROPID_M_BODY_TYPE;  // COM assumes a string of bytes
	PropVars[2].vt = VT_UI4;
	PropVars[2].ulVal = VT_LPWSTR;

	/* The ACTUAL body type is in PROPID_M_BODY_TYPE.ulVal
		PROPID_M_BODY_TYPE is described between applications as a 
			PropVariant type descriptor
		The type descriptor for PROPID_M_BODY_TYPE's contents is always VT_UI4
		The type descriptor for PROPID_M_BODY's contents is always VT_VECTOR|VT_UI4

		So, PROPID_M_BODY.caub and PROPID_M_BODY_TYPE.ulVal is between 
		application developers, PROPID_M_BODY.vt and PROPID_M_BODY_TYPE.vt are just for
		MSMQ's processing. The setting of the property descriptors (.vt) is not for
		developers; the fact that you're using variants to communicate with MSMQ does
		not mean you're using variants to communicate with each other
	*/

	Message.cProp = 3;
	Message.aPropID = PropID;
	Message.aPropVar = PropVars;
	Message.aStatus = hrStatus;
	// End of Message initialization

	QUEUEHANDLE		DestQueue;
	HRESULT hr = MQOpenQueue(QueueFormatName, MQ_SEND_ACCESS, MQ_DENY_NONE,
		&DestQueue);

	if (FAILED(hr))
		return;

	hr = MQSendMessage(DestQueue,&Message,MQ_NO_TRANSACTION);

	MQCloseQueue(DestQueue);
}
void CMSMQHandbookAPIDlg::OnBnClickedSend()
{
	SendMSMQMessage(L"DIRECT=OS:.\\PRIVATE$\\HandbookAPI", L"Test Message", 
		L"Body of Test Message");
}

void CMSMQHandbookAPIDlg::DeleteQueue(LPWSTR FormatName)
{
	HRESULT hr = MQDeleteQueue(FormatName);
};
void CMSMQHandbookAPIDlg::OnBnClickedDelete()
{
	DeleteQueue(L"DIRECT=OS:.\\PRIVATE$\\HandbookAPI");
}

void CMSMQHandbookAPIDlg::CreateQueue(LPWSTR PathName)
{
	MQQUEUEPROPS	QueueProps;
	// QUEUEPROPID and MQPROPVARIANT need to be initialized
	QUEUEPROPID		PropID[1];  
	MQPROPVARIANT	PropVars[1];  
	// Does not need to be initialized
	HRESULT			hrStatus[1];  
	DWORD			FormatNameLen = 0;

	PropID[0] = PROPID_Q_PATHNAME;
	PropVars[0].vt = VT_LPWSTR;
	PropVars[0].pwszVal = PathName;

	QueueProps.cProp = 1;
	QueueProps.aPropID = PropID;
	QueueProps.aPropVar = PropVars;
	QueueProps.aStatus = hrStatus;

	HRESULT hr = MQCreateQueue(NULL /*Security descriptor*/, 
		&QueueProps, NULL, &FormatNameLen);
};

void CMSMQHandbookAPIDlg::OnBnClickedCreate()
{
	CreateQueue(L".\\PRIVATE$\\HandbookAPI");
}

void CMSMQHandbookAPIDlg::ReceiveSingleMessage(QUEUEHANDLE hSrcQueue)
{
	MQMSGPROPS		Message;
	int				numprops = 4;
	MSGPROPID		PropID[4];
	MQPROPVARIANT	PropVars[4];
	HRESULT			hrStatus[4];
	DWORD			BodySize = 0;

	// Begin initialization of message structure
	for (int i = 0; i<numprops; i++)
        PropVariantInit(&PropVars[i]);

	WCHAR LabelBuffer[MQ_MAX_MSG_LABEL_LEN];
	PropID[0] = PROPID_M_LABEL;
	PropVars[0].vt = VT_LPWSTR;
	PropVars[0].pwszVal = LabelBuffer;

	PropID[1] = PROPID_M_LABEL_LEN;
	PropVars[1].vt = VT_UI4;
	PropVars[1].ulVal = MQ_MAX_MSG_LABEL_LEN;

	LPWSTR BodyBuffer = (LPWSTR) malloc(BodySize);
	PropID[2] = PROPID_M_BODY;
	PropVars[2].vt = VT_VECTOR | VT_UI1;
	PropVars[2].caub.pElems = (UCHAR*)BodyBuffer;
	PropVars[2].caub.cElems = BodySize;

	PropID[3] = PROPID_M_BODY_SIZE;
	PropVars[3].vt = VT_UI4;
	PropVars[3].ulVal = BodySize;

	Message.cProp = numprops;
	Message.aPropID = PropID;
	Message.aPropVar = PropVars;
	Message.aStatus = hrStatus;
	// End initialization of message structure

	// Try to receive the message
	HRESULT hr = MQReceiveMessage(hSrcQueue, 1000, MQ_ACTION_RECEIVE, &Message, 
		NULL, NULL, NULL, MQ_NO_TRANSACTION);

	// If the message is too large, this is the error
	while (MQ_ERROR_BUFFER_OVERFLOW == hr)
	{
		// Free the body and resize to fit the message
		free(BodyBuffer);
		BodySize = Message.aPropVar[3].ulVal;
		BodyBuffer = (LPWSTR) malloc(BodySize);
		PropVars[2].caub.pElems = (UCHAR*)BodyBuffer;
		PropVars[2].caub.cElems = BodySize;
		PropVars[3].ulVal = BodySize;

		// Try to receive again
		hr = MQReceiveMessage(hSrcQueue, 1000, MQ_ACTION_RECEIVE, &Message, 
			NULL, NULL, NULL, MQ_NO_TRANSACTION);
	}

	/* Message processing goes here */
	free(BodyBuffer);
}
void CMSMQHandbookAPIDlg::ReceiveMSMQMessage(LPWSTR QueueFormatName)
{
	QUEUEHANDLE		SrcQueue;
	HRESULT hr = MQOpenQueue(QueueFormatName, MQ_RECEIVE_ACCESS, 
					MQ_DENY_RECEIVE_SHARE, &SrcQueue);
	if (FAILED(hr))
		return;

	// You should receive multiple messages before closing queue 
	// to enhance performance. This sample receives only one.
	ReceiveSingleMessage(SrcQueue);

	MQCloseQueue(SrcQueue);
};

void CMSMQHandbookAPIDlg::OnBnClickedReceive()
{
	ReceiveMSMQMessage(L"DIRECT=OS:.\\PRIVATE$\\HandbookAPI");
}

void CMSMQHandbookAPIDlg::EnumerateMSMQQueue(LPWSTR QueueName, LPWSTR Label)
{
	QUEUEHANDLE		SrcQueue;
	HRESULT hr = MQOpenQueue(QueueName, MQ_RECEIVE_ACCESS, MQ_DENY_RECEIVE_SHARE,
		&SrcQueue);
	if (FAILED(hr))
		return;

	// This Cursor keeps track of our position
	HANDLE Cursor;
	hr = MQCreateCursor(SrcQueue, &Cursor);
	if (FAILED(hr))
		return;

	MQMSGPROPS		peekMessage;
	int				numprops = 4;
	MSGPROPID		peekPropID[4];
	MQPROPVARIANT	peekPropVars[4];
	HRESULT			peekStatus[4];

	// Begin initialization of peekMessage
	for (int i = 0; i<numprops; i++)
        PropVariantInit(&peekPropVars[i]);

	peekPropID[1] = PROPID_M_BODY_TYPE;
	peekPropVars[1].vt = VT_UI4;

	peekPropID[0] = PROPID_M_BODY_SIZE;
	peekPropVars[0].vt = VT_UI4;

	WCHAR LabelBuffer[MQ_MAX_MSG_LABEL_LEN];
	peekPropID[2] = PROPID_M_LABEL;
	peekPropVars[2].vt = VT_LPWSTR;
	peekPropVars[2].pwszVal = LabelBuffer;

	peekPropID[3] = PROPID_M_LABEL_LEN;
	peekPropVars[3].vt = VT_UI4;
	peekPropVars[3].ulVal = MQ_MAX_MSG_LABEL_LEN;

	peekMessage.cProp = numprops;
	peekMessage.aPropID = peekPropID;
	peekMessage.aPropVar = peekPropVars;
	peekMessage.aStatus = peekStatus;
	// End initialization of peekMessage
	
	// Peek at the message at the cursor position
	hr = MQReceiveMessage(SrcQueue, 1000, MQ_ACTION_PEEK_CURRENT, &peekMessage, 
			NULL, NULL, Cursor, MQ_NO_TRANSACTION);

	// Repeat until we find the label we want
	while ((0 != wcscmp(peekMessage.aPropVar[2].pwszVal, Label)) &&
		(SUCCEEDED(hr)))
	{  
		peekPropVars[3].ulVal = MQ_MAX_MSG_LABEL_LEN;

		hr = MQReceiveMessage(SrcQueue, 1000, MQ_ACTION_PEEK_NEXT, &peekMessage, 
			NULL, NULL, Cursor, MQ_NO_TRANSACTION);
	}

	
	ULONG BodySize, BodyType = 0;

	// 0xC00E001B indicates no more messages
	// If we found a message, get the body type and size
	if SUCCEEDED(hr)
	{
		BodyType = peekMessage.aPropVar[1].ulVal;
		BodySize = peekMessage.aPropVar[0].ulVal;
	}
	else
	{
		// otherwise there is no matching message
		MQCloseCursor(Cursor);
		MQCloseQueue(SrcQueue);
		return;
	};

	if (BodyType != VT_LPWSTR)
	{
		// or we have the right label, wrong body type
		MQCloseCursor(Cursor);
		MQCloseQueue(SrcQueue);
		return;
	};

	MQMSGPROPS		Message;
	numprops = 3;
	MSGPROPID		PropID[3];
	MQPROPVARIANT	PropVars[3];
	HRESULT			hrStatus[3];

	// Begin initialization of Message
	for (int i = 0; i<numprops; i++)
		PropVariantInit(&PropVars[i]);

	PropID[0] = PROPID_M_LABEL;
	PropVars[0].vt = VT_LPWSTR;
	PropVars[0].pwszVal = LabelBuffer;

	PropID[1] = PROPID_M_LABEL_LEN;
	PropVars[1].vt = VT_UI4;
	PropVars[1].ulVal = MQ_MAX_MSG_LABEL_LEN;

	LPWSTR BodyBuffer = (LPWSTR) malloc(BodySize);
	PropID[2] = PROPID_M_BODY;
	PropVars[2].vt = VT_VECTOR | VT_UI1;
	PropVars[2].caub.pElems = (UCHAR*)BodyBuffer;
	PropVars[2].caub.cElems = BodySize;

	Message.cProp = numprops;
	Message.aPropID = PropID;
	Message.aPropVar = PropVars;
	Message.aStatus = hrStatus;
	// End initialization of Message

	// Get the message from the queue
	hr = MQReceiveMessage(SrcQueue, 1000, MQ_ACTION_RECEIVE, &Message, 
		NULL, NULL, Cursor, MQ_NO_TRANSACTION);

	// Clean up
	MQCloseCursor(Cursor);
	MQCloseQueue(SrcQueue);

	/* Message processing goes here */
	free(BodyBuffer);
};

void CMSMQHandbookAPIDlg::OnBnClickedEnumerate()
{
	EnumerateMSMQQueue(L"DIRECT=OS:.\\PRIVATE$\\HandbookAPI", L"Test Message");
}

#define INDEX_LABELSIZE 0
#define INDEX_LABEL 1
#define INDEX_BODYSIZE 2
#define INDEX_BODYTYPE 3
#define INDEX_BODY 4
#define PROPTOTAL 5

void CALLBACK MessageCallback(HRESULT hr, QUEUEHANDLE hSource, DWORD dwTimeout, 
					 DWORD dwAction, MQMSGPROPS* pMessageProps, 
					 LPOVERLAPPED lpOverlapped, HANDLE hCursor);

void CallMSMQAsync(QUEUEHANDLE hSrcQueue)
{


	MQMSGPROPS*		pPeekMessage = (MQMSGPROPS*) malloc(sizeof(MQMSGPROPS));
	int				numprops = 4;
	MSGPROPID*		pPeekPropID = new MSGPROPID[4];
	MQPROPVARIANT*	pPeekPropVars = new MQPROPVARIANT[4];
	HRESULT*		pPeekStatus = new HRESULT[4];

	for (int i = 0; i<numprops; i++)
		PropVariantInit(&pPeekPropVars[i]);

	pPeekPropID[1] = PROPID_M_BODY_TYPE;
	pPeekPropVars[1].vt = VT_UI4;

	pPeekPropID[0] = PROPID_M_BODY_SIZE;
	pPeekPropVars[0].vt = VT_UI4;

	WCHAR LabelBuffer[MQ_MAX_MSG_LABEL_LEN];
	pPeekPropID[2] = PROPID_M_LABEL;
	pPeekPropVars[2].vt = VT_LPWSTR;
	pPeekPropVars[2].pwszVal = LabelBuffer;

	pPeekPropID[3] = PROPID_M_LABEL_LEN;
	pPeekPropVars[3].vt = VT_UI4;
	pPeekPropVars[3].ulVal = MQ_MAX_MSG_LABEL_LEN;

	pPeekMessage->cProp = numprops;
	pPeekMessage->aPropID = pPeekPropID;
	pPeekMessage->aPropVar = pPeekPropVars;
	pPeekMessage->aStatus = pPeekStatus;

	HRESULT hr = MQReceiveMessage(hSrcQueue, 3000, MQ_ACTION_PEEK_CURRENT, pPeekMessage, 
		NULL, &MessageCallback, NULL, MQ_NO_TRANSACTION);

/*
	// There are no messages to be received
	if (MQ_INFORMATION_OPERATION_PENDING == hr)
	{

	};
*/
	if (FAILED(hr))
	{
		delete [] pPeekPropID;
		delete [] pPeekPropVars;
		delete [] pPeekStatus;
		free(pPeekMessage);

		// No further use for this queue
		MQCloseQueue(hSrcQueue);
	};
};

void CALLBACK MessageCallback(HRESULT hr, QUEUEHANDLE hSource, DWORD dwTimeout, 
					 DWORD dwAction, MQMSGPROPS* pMessageProps, 
					 LPOVERLAPPED lpOverlapped, HANDLE hCursor)
{


	ULONG BodySize, BodyType = 0;

	BodyType = pMessageProps->aPropVar[1].ulVal;
	BodySize = pMessageProps->aPropVar[0].ulVal;
	
	delete [] pMessageProps->aPropID;
	delete [] pMessageProps->aPropVar;
	delete [] pMessageProps->aStatus;
	free(pMessageProps);

	if (FAILED(hr) || (BodyType != VT_LPWSTR)) 
	{
		MQCloseQueue(hSource);
		return;  // error handling would go here
	};	
	
	MQMSGPROPS		Message;
	int numprops = 3;
	MSGPROPID		PropID[3];
	MQPROPVARIANT	PropVars[3];
	HRESULT			hrStatus[3];

	for (int i = 0; i<numprops; i++)
		PropVariantInit(&PropVars[i]);

	WCHAR LabelBuffer[MQ_MAX_MSG_LABEL_LEN];
	PropID[0] = PROPID_M_LABEL;
	PropVars[0].vt = VT_LPWSTR;
	PropVars[0].pwszVal = LabelBuffer;

	PropID[1] = PROPID_M_LABEL_LEN;
	PropVars[1].vt = VT_UI4;
	PropVars[1].ulVal = MQ_MAX_MSG_LABEL_LEN;

	LPWSTR BodyBuffer = (LPWSTR) malloc(BodySize);
	PropID[2] = PROPID_M_BODY;
	PropVars[2].vt = VT_VECTOR | VT_UI1;
	PropVars[2].caub.pElems = (UCHAR*)BodyBuffer;
	PropVars[2].caub.cElems = BodySize;

	Message.cProp = numprops;
	Message.aPropID = PropID;
	Message.aPropVar = PropVars;
	Message.aStatus = hrStatus;

	hr = MQReceiveMessage(hSource, 1000, MQ_ACTION_RECEIVE, &Message, 
		NULL, NULL, NULL, MQ_NO_TRANSACTION);

	/* Message processing goes here */
	free(BodyBuffer);

	/* Reset Async */
	CallMSMQAsync(hSource);

};
/*
typedef
VOID
(APIENTRY *PMQRECEIVECALLBACK)(
    HRESULT hrStatus,
    QUEUEHANDLE hSource,
    DWORD dwTimeout,
    DWORD dwAction,
    MQMSGPROPS* pMessageProps,
    LPOVERLAPPED lpOverlapped,
    HANDLE hCursor
    );
*/


void CMSMQHandbookAPIDlg::OnBnClickedAsyncRecv()
{	
	QUEUEHANDLE		SrcQueue;
	HRESULT hr = MQOpenQueue(L"DIRECT=OS:.\\PRIVATE$\\HandbookAPI", MQ_RECEIVE_ACCESS, MQ_DENY_NONE,
		&SrcQueue);
	if (SUCCEEDED(hr))
	{
		//CallMSMQAsync will close the queue when there are no
		//more messages to be retrieved.
        CallMSMQAsync(SrcQueue);		
	};
}

void CMSMQHandbookAPIDlg::EnumMSMQQueueByID(LPWSTR QueueName, LPWSTR Label)
{
	QUEUEHANDLE		SrcQueue;
	HRESULT hr = MQOpenQueue(QueueName, MQ_RECEIVE_ACCESS, MQ_DENY_RECEIVE_SHARE,
		&SrcQueue);

	MQMSGPROPS		peekMessage;
	int				numprops = 5;
	MSGPROPID		peekPropID[5];
	MQPROPVARIANT	peekPropVars[5];
	HRESULT			peekStatus[5];

	// Begin initialization of peekMessage
	for (int i = 0; i<numprops; i++)
        PropVariantInit(&peekPropVars[i]);

	peekPropID[1] = PROPID_M_BODY_TYPE;
	peekPropVars[1].vt = VT_UI4;

	peekPropID[0] = PROPID_M_BODY_SIZE;
	peekPropVars[0].vt = VT_UI4;

	WCHAR LabelBuffer[MQ_MAX_MSG_LABEL_LEN];
	peekPropID[2] = PROPID_M_LABEL;
	peekPropVars[2].vt = VT_LPWSTR;
	peekPropVars[2].pwszVal = LabelBuffer;

	peekPropID[3] = PROPID_M_LABEL_LEN;
	peekPropVars[3].vt = VT_UI4;
	peekPropVars[3].ulVal = MQ_MAX_MSG_LABEL_LEN;

	peekPropID[4] = PROPID_M_LOOKUPID;
	peekPropVars[4].vt = VT_UI8;

	peekMessage.cProp = numprops;
	peekMessage.aPropID = peekPropID;
	peekMessage.aPropVar = peekPropVars;
	peekMessage.aStatus = peekStatus;
	// End initialization of peekMessage

	// Peek at the end of the queue
	hr = MQReceiveMessageByLookupId(SrcQueue, 0, MQ_LOOKUP_PEEK_LAST, 
			&peekMessage, NULL, NULL, MQ_NO_TRANSACTION);

	// repeat until we find a message with the right label, or
	// until an error.
	while ((0 != wcscmp(peekMessage.aPropVar[2].pwszVal, Label)) &&
		(SUCCEEDED(hr)))
	{      
		peekPropVars[3].ulVal = MQ_MAX_MSG_LABEL_LEN;

		// Peek using the current lookupID
		hr = MQReceiveMessageByLookupId(SrcQueue, 
			peekMessage.aPropVar[4].uhVal.QuadPart, MQ_LOOKUP_PEEK_PREV, 
			&peekMessage, NULL, NULL, MQ_NO_TRANSACTION);
	};

	ULONG BodySize, BodyType = 0;
	ULONGLONG LookupID = 0;

	// Initializae the new body if we got a message
	if SUCCEEDED(hr)
	{
		BodyType = peekMessage.aPropVar[1].ulVal;
		BodySize = peekMessage.aPropVar[0].ulVal;
		LookupID = peekMessage.aPropVar[4].uhVal.QuadPart;
	}
	else
	{
		// otherwise, clean up and return
		MQCloseQueue(SrcQueue);
		return;
	};

	if (BodyType != VT_LPWSTR)
	{
		// We didn't get the body type we expect
		// so clean up and return
		MQCloseQueue(SrcQueue);
		return;
	};

	MQMSGPROPS		Message;
	numprops = 3;
	MSGPROPID		PropID[3];
	MQPROPVARIANT	PropVars[3];
	HRESULT			hrStatus[3];

	// Begin initialization of Message
	for (int i = 0; i<numprops; i++)
		PropVariantInit(&PropVars[i]);

	PropID[0] = PROPID_M_LABEL;
	PropVars[0].vt = VT_LPWSTR;
	PropVars[0].pwszVal = LabelBuffer;

	PropID[1] = PROPID_M_LABEL_LEN;
	PropVars[1].vt = VT_UI4;
	PropVars[1].ulVal = MQ_MAX_MSG_LABEL_LEN;

	LPWSTR BodyBuffer = (LPWSTR) malloc(BodySize);
	PropID[2] = PROPID_M_BODY;
	PropVars[2].vt = VT_VECTOR | VT_UI1;
	PropVars[2].caub.pElems = (UCHAR*)BodyBuffer;
	PropVars[2].caub.cElems = BodySize;

	Message.cProp = numprops;
	Message.aPropID = PropID;
	Message.aPropVar = PropVars;
	Message.aStatus = hrStatus;
	// End initialization of Message

	// Receive the message using the LookupID
	hr = MQReceiveMessageByLookupId(SrcQueue, 
			peekMessage.aPropVar[4].uhVal.QuadPart, MQ_LOOKUP_RECEIVE_CURRENT, 
			&Message, NULL, NULL, MQ_NO_TRANSACTION);

	MQCloseQueue(SrcQueue);
	
	/* Message processing goes here */
	free(BodyBuffer);
};

void CMSMQHandbookAPIDlg::OnBnClickedEnumlookup()
{
	EnumMSMQQueueByID(L"DIRECT=OS:.\\PRIVATE$\\HandbookAPI", L"Test Message");
}
