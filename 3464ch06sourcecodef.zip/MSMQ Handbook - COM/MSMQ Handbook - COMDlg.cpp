// MSMQ Handbook - COMDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MSMQ Handbook - COM.h"
#include "MSMQ Handbook - COMDlg.h"




#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMSMQHandbookCOMDlg dialog


// added for events
BEGIN_DISPATCH_MAP(CMSMQHandbookCOMDlg, CCmdTarget)
	DISP_FUNCTION_ID(CMSMQHandbookCOMDlg, "Arrived", 0, Arrived, VT_EMPTY, VTS_DISPATCH VTS_I4)
	DISP_FUNCTION_ID(CMSMQHandbookCOMDlg, "ArrivedError", 1, ArrivedError, VT_EMPTY, VTS_DISPATCH VTS_I4 VTS_I4)
END_DISPATCH_MAP()
// end of added


CMSMQHandbookCOMDlg::CMSMQHandbookCOMDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMSMQHandbookCOMDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	//added for events
	EnableAutomation();
	//end of added
}

void CMSMQHandbookCOMDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LABEL, dlgLabel);
	DDX_Control(pDX, IDC_BODY, dlgBody);
	DDX_Control(pDX, IDC_QUEUENAME, dlgQueueName);
}

BEGIN_MESSAGE_MAP(CMSMQHandbookCOMDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedGo)
	ON_BN_CLICKED(IDC_RECV, OnBnClickedRecv)
	ON_BN_CLICKED(IDC_Enumerate, OnBnClickedEnumerate)
	ON_BN_CLICKED(IDC_ENUMLOOKUP, OnBnClickedEnumlookup)
	ON_BN_CLICKED(IDC_ASYNC, OnBnClickedAsync)
	ON_BN_CLICKED(IDC_CREATE, OnBnClickedCreate)
	ON_BN_CLICKED(IDC_DELETE, OnBnClickedDelete)
END_MESSAGE_MAP()


// CMSMQHandbookCOMDlg message handlers

BOOL CMSMQHandbookCOMDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	CoInitialize(NULL);

	dlgLabel.SetWindowText("Label");
	dlgBody.SetWindowText("Body");
	dlgQueueName.SetWindowText("DIRECT=OS:.\\private$\\Handbook");
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMSMQHandbookCOMDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMSMQHandbookCOMDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMSMQHandbookCOMDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CMSMQHandbookCOMDlg::CreateMSMQQueue(_bstr_t QueuePathName)
{
	MSMQ::IMSMQQueueInfoPtr myQueueInfo("MSMQ.MSMQQueueInfo");

	try {/* Creating a queue requires setting the Path Name value first*/
		myQueueInfo->PutPathName(QueuePathName);
		myQueueInfo->Create(&(_variant_t)false, &(_variant_t)true);
	} catch (_com_error Result) {ErrorDlg(Result.Error());};
}

void CMSMQHandbookCOMDlg::DeleteMSMQQueue(_bstr_t QueueFormatName)
{
	MSMQ::IMSMQQueueInfoPtr myQueueInfo("MSMQ.MSMQQueueInfo");

	try {/* Deleting a queue requires setting the Format Name value first*/
		myQueueInfo->PutFormatName(QueueFormatName);
		myQueueInfo->Delete();
	} catch (_com_error Result) {ErrorDlg(Result.Error());};
};

void CMSMQHandbookCOMDlg::SendMSMQMessage(_bstr_t QueueFormatName, 
										  _bstr_t Label, _bstr_t Body)
{
	MSMQ::IMSMQQueueInfoPtr myQueueInfo("MSMQ.MSMQQueueInfo");
	try {
		/* Creating a queue requires setting the PathName or FormatName value first*/
		myQueueInfo->PutFormatName(QueueFormatName);
		/* Open must select send, receive or peek mode*/
		MSMQ::IMSMQQueuePtr myQueue = 
			myQueueInfo->Open(MSMQ::MQ_SEND_ACCESS, MSMQ::MQ_DENY_NONE);
		/* The following function sends a message */
		SendSingleMessage(myQueue, Label, Body);
		/* Close the queue */
		myQueue->Close();
	} catch (_com_error Result) {ErrorDlg(Result.Error());};
}

void CMSMQHandbookCOMDlg::SendSingleMessage(MSMQ::IMSMQQueuePtr OpenedQueue,
										  _bstr_t Label, _bstr_t Body)
{	/* Exceptions from this function flow up to the caller*/
	MSMQ::IMSMQMessagePtr myMessage("MSMQ.MSMQMessage");

	myMessage->PutLabel(Label);
	myMessage->PutBody(Body);
	/* Send defaults to MQ_NO_TRANSACTION as the second parameter */
	myMessage->Send(OpenedQueue);
};



void CMSMQHandbookCOMDlg::RecvMSMQMessage(_bstr_t QueueFormatName)
{
    MSMQ::IMSMQQueueInfoPtr myQueueInfo("MSMQ.MSMQQueueInfo");

	try {
		myQueueInfo->PutFormatName(QueueFormatName);
		MSMQ::IMSMQQueuePtr myQueue = 
			myQueueInfo->Open(MSMQ::MQ_RECEIVE_ACCESS, MSMQ::MQ_DENY_NONE);
		MSMQ::IMSMQMessagePtr myMessage =
			myQueue->Receive(&(_variant_t) MSMQ::MQ_NO_TRANSACTION,
				&(_variant_t) false, &(_variant_t) true, &(_variant_t) 1000);
		myQueue->Close();
	} catch (_com_error Result) {ErrorDlg(Result.Error());};
};


void CMSMQHandbookCOMDlg::EnumMSMQQueue(_bstr_t QueueFormatName, _bstr_t TargetLabel)
{
    MSMQ::IMSMQQueueInfoPtr myQueueInfo("MSMQ.MSMQQueueInfo");
	MSMQ::IMSMQQueuePtr myQueue;
	MSMQ::IMSMQMessagePtr myMessage;
	_bstr_t myLabel;

	try {
		myQueueInfo->PutFormatName(QueueFormatName);
		myQueue = 
			myQueueInfo->Open(MSMQ::MQ_PEEK_ACCESS, MSMQ::MQ_DENY_NONE);
		myMessage = myQueue->PeekCurrent(&(_variant_t)false,
			&(_variant_t)false, &(_variant_t)1000);
		if (myMessage != NULL)
			myLabel = myMessage->GetLabel();
		/* loop until we find a target label, or run out of messages */
		while ((myLabel != TargetLabel) && (myMessage != NULL))
		{
			myMessage = myQueue->PeekNext(&(_variant_t)false, 
				&(_variant_t)true, &(_variant_t)1000);
			myLabel = myMessage->GetLabel();
		};
		/* Process/Display peeked message (not shown)*/
		myQueue->Close();	
	} catch (_com_error Result) {ErrorDlg(Result.Error());};
};


void CMSMQHandbookCOMDlg::EnumMSMQQueueByID(_bstr_t QueueFormatName, _bstr_t TargetLabel)
{
	MSMQ::IMSMQQueueInfoPtr myQueueInfo("MSMQ.MSMQQueueInfo");
	MSMQ::IMSMQQueue3Ptr myQueue;
	MSMQ::IMSMQMessage3Ptr myMessage;
	_bstr_t myLabel;
	_variant_t myLookupID;

	try {
		myQueueInfo->PutFormatName(QueueFormatName);
		myQueue = 
			myQueueInfo->Open(MSMQ::MQ_PEEK_ACCESS, MSMQ::MQ_DENY_NONE);
		myMessage = myQueue->PeekLastByLookupId(&(_variant_t) false, 
			&(_variant_t) false, &(_variant_t) false);
		if (myMessage != NULL)
			myLabel = myMessage->GetLabel();
		else
			return;

		while ((myLabel != TargetLabel) && (myMessage != NULL))
		{
			myMessage = myQueue->PeekPreviousByLookupId(myMessage->GetLookupId(), 
				&(_variant_t) false, &(_variant_t) false, &(_variant_t) false);
			myLabel = myMessage->GetLabel();
		};
	} catch (_com_error Result) {ErrorDlg(Result.Error());};
};

void CMSMQHandbookCOMDlg::RecvMSMQMessageAsync(_bstr_t QueueFormatName)
{
	MSMQ::IMSMQQueueInfoPtr myQueueInfo("MSMQ.MSMQQueueInfo");

	try {
		myQueueInfo->PutFormatName(QueueFormatName);
		m_pQueuePtr =
			myQueueInfo->Open(MSMQ::MQ_RECEIVE_ACCESS, MSMQ::MQ_DENY_NONE);
		// enable notification
		_variant_t vtMsgFirst = MSMQ::MQMSG_FIRST;
		_variant_t vtInfinite = INFINITE;

		// create an MSMQEvent object and connect to it
		m_pEventPtr.CreateInstance("MSMQ.MSMQEvent");
		IConnectionPointContainerPtr myCPC = m_pEventPtr;
		IConnectionPoint* myCP;
		myCPC->FindConnectionPoint(__uuidof(MSMQ::_DMSMQEventEvents), &myCP);
		DWORD cookie;
		HRESULT hr = myCP->Advise(GetIDispatch(true), &cookie);

		m_pQueuePtr->EnableNotification(m_pEventPtr);

	} catch (_com_error Result) {ErrorDlg(Result.Error());};
};


void CMSMQHandbookCOMDlg::OnBnClickedGo()
{
	CString Label, QueueFormatName, Body;
	dlgLabel.GetWindowText(Label);
	dlgQueueName.GetWindowText(QueueFormatName);
	dlgBody.GetWindowText(Body);

	try { SendMSMQMessage((_bstr_t)QueueFormatName, (_bstr_t)Label, (_bstr_t)Body);
	} catch (_com_error Result) {ErrorDlg(Result.Error());};

}

void CMSMQHandbookCOMDlg::OnBnClickedRecv()
{
	CString QueueFormatName;
	dlgQueueName.GetWindowText(QueueFormatName);

	RecvMSMQMessage((_bstr_t)QueueFormatName);
}

void CMSMQHandbookCOMDlg::OnBnClickedEnumerate()
{
	CString Label, QueueFormatName;
	dlgLabel.GetWindowText(Label);
	dlgQueueName.GetWindowText(QueueFormatName);

	EnumMSMQQueue((_bstr_t)QueueFormatName, (_bstr_t)Label);
};

void CMSMQHandbookCOMDlg::OnBnClickedEnumlookup()
{
	CString Label, QueueFormatName;
	dlgLabel.GetWindowText(Label);
	dlgQueueName.GetWindowText(QueueFormatName);

	EnumMSMQQueueByID((_bstr_t)QueueFormatName, (_bstr_t)Label);
};

void CMSMQHandbookCOMDlg::ErrorDlg(HRESULT hr)
{
	char* szErr = new char[16];
	itoa(hr, szErr, 16);
	CString tempString = "Method returned HRESULT: ";
	tempString += szErr;
	MessageBox(tempString, NULL, MB_ICONSTOP | MB_OK);
	delete szErr;
};

// Added for events
void CMSMQHandbookCOMDlg::Arrived(IDispatch* pdispQueue, long lCursor)
{

	try {
		MSMQ::IMSMQQueuePtr myQueue = pdispQueue;
		MSMQ::IMSMQMessagePtr myMessage =
			myQueue->Receive(&(_variant_t) MSMQ::MQ_NO_TRANSACTION,
				&(_variant_t) false, &(_variant_t) true, &(_variant_t) 1000);
		
		_variant_t vtCursor = lCursor;
		_variant_t vtInfinite = INFINITE;
		MSMQ::IMSMQEvent* myEventPtr = NULL;
		(GetIDispatch(true))->QueryInterface(__uuidof(MSMQ::IMSMQEvent), (void**)&myEventPtr);

		myQueue->EnableNotification(myEventPtr, &vtCursor, &vtInfinite);

		myQueue->Close();
	} catch (_com_error Result) {ErrorDlg(Result.Error());};

};
void CMSMQHandbookCOMDlg::ArrivedError(IDispatch* pdispQueue, 
	long lErrorCode, long lCursor)
{
	ErrorDlg(lErrorCode);
};
// end of added

void CMSMQHandbookCOMDlg::OnBnClickedAsync()
{
	CString QueueFormatName;
	dlgQueueName.GetWindowText(QueueFormatName);

	RecvMSMQMessageAsync((_bstr_t)QueueFormatName);
}

void CMSMQHandbookCOMDlg::OnBnClickedCreate()
{
	CString QueueFormatName;
	dlgQueueName.GetWindowText(QueueFormatName);

	/* Trim the Format Name to a Path Name when calling Create by trimming past the first colon*/
	int pathsize = QueueFormatName.GetLength() - QueueFormatName.Find(":") -1;
	CString QueuePathName = QueueFormatName.Right(pathsize);

	try { CreateMSMQQueue((_bstr_t)QueuePathName);
	} catch (_com_error Result) {ErrorDlg(Result.Error());};
}

void CMSMQHandbookCOMDlg::OnBnClickedDelete()
{
	CString QueueFormatName;
	dlgQueueName.GetWindowText(QueueFormatName);

	try { DeleteMSMQQueue((_bstr_t)QueueFormatName);
	} catch (_com_error Result) {ErrorDlg(Result.Error());};
}
