// MSMQ Handbook - COMDlg.h : header file
//

#pragma once
#include "comutil.h"
#include "afxwin.h"
#import <mqoa.dll>


// CMSMQHandbookCOMDlg dialog
class CMSMQHandbookCOMDlg : public CDialog
{
// Construction
public:
	CMSMQHandbookCOMDlg(CWnd* pParent = NULL);	// standard constructor

	/*
//added for events
	BEGIN_COM_MAP(CMSMQHandbookCOMDlg)
		COM_INTERFACE_ENTRY_IID(__uuidof(MSMQ::_DMSMQEventEvents), MSMQ::_DMSMQEventEvents)
	END_COM_MAP()
//end of added
*/


// Dialog Data
	enum { IDD = IDD_MSMQHANDBOOKCOM_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	void ErrorDlg(HRESULT hr);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedGo();
	afx_msg void OnBnClickedRecv();
	afx_msg void OnBnClickedEnumerate();
	afx_msg void OnBnClickedEnumlookup();
	afx_msg void OnBnClickedCreate();
	afx_msg void OnBnClickedDelete();

	// methods for using MSMQ
	void CreateMSMQQueue(_bstr_t QueuePathName);
	void DeleteMSMQQueue(_bstr_t QueueFormatName);
	void SendSingleMessage(MSMQ::IMSMQQueuePtr OpenedQueue, _bstr_t Label, _bstr_t Body);
	void SendMSMQMessage(_bstr_t QueueFormatName, _bstr_t Label, _bstr_t Body);
	void RecvMSMQMessage(_bstr_t QueueFormatName);
	void EnumMSMQQueue(_bstr_t QueueFormatName, _bstr_t TargetLabel);
	void EnumMSMQQueueByID(_bstr_t QueueFormatName, _bstr_t TargetLabel);
	void RecvMSMQMessageAsync(_bstr_t QueueFormatName);

	// added for events

	virtual void Arrived(IDispatch* pdispQueue, long lCursor);
	virtual void ArrivedError(IDispatch* pdispQueue, long lErrorCode, long lCursor);
	DECLARE_DISPATCH_MAP()

	MSMQ::IMSMQEventPtr m_pEventPtr;
	MSMQ::IMSMQQueuePtr m_pQueuePtr;
	// end of added
	afx_msg void OnBnClickedAsync();
	CEdit dlgLabel;
	CEdit dlgBody;
	CEdit dlgQueueName;
};
