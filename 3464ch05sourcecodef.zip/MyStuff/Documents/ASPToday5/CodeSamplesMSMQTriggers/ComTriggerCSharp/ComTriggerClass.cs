using System;
using System.IO;
using System.Messaging;
using System.Runtime.InteropServices;

namespace TRIG
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class ComTriggerClass
	{
		public void COMTriggerMethod(string message, string dateRec,long priority,byte[] messageID,string filePath)
		{
			string outputFile = filePath + "COMTriggerDemo.txt";
			TextWriter output;
			
			// Create output file
			if (!File.Exists(outputFile))
				output = File.CreateText(outputFile);
			else
				output = File.AppendText(outputFile);

			string messageIdout = ConvID(messageID);
			
			// Write to output file
			output.WriteLine(String.Format("Message: {0} Received: {1} Priority {2} ID: {3}", message, dateRec, priority, messageIdout));
			output.Close();
		}

		// Method to Convert the Message ID a string
		// Example Format: 88c5a70b6f4e4ea49db07e2d9299cc8e\32835
		private string ConvID(byte[] msg)
		{
			//byte[] outguid = new byte[15];
			byte[] outguid = new byte[16];
			Array.Copy(msg, outguid, 16);

			Guid oguid = new Guid(outguid);

			// Start at position 16 to get the unique message id
			ulong intdword = BitConverter.ToUInt32(msg, 16);

			// Return the Message Queue ID
			return oguid.ToString() + "\\" + intdword.ToString();
		}

		// Method to Remove Message from queue
		public void COMTriggerRemove(string queuename,byte[] messageID)
		{
			string msgId = ConvID(messageID);
			try
			{
				// Define our Queue
				MessageQueue q = new MessageQueue(queuename);
				MessageEnumerator mEnum = q.GetMessageEnumerator();

				// Loop through messages until we find ours, then remove it.
				while (mEnum.MoveNext())
				{
					Message message = mEnum.Current;

					if (message.Id == msgId)
					{
						// Message found - remove it.
						mEnum.RemoveCurrent();
						break;
					}
				}
			}
			catch {}
		}
	}
}