Imports System.IO
Imports System.Messaging
Public Class TestHarnessVBNet
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MessageQueue1 As System.Messaging.MessageQueue
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtQueue As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtLabel As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnSend As System.Windows.Forms.Button
    Friend WithEvents txtBody As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CmbPriority As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MessageQueue1 = New System.Messaging.MessageQueue
        Me.btnSend = New System.Windows.Forms.Button
        Me.txtBody = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtQueue = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtLabel = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.CmbPriority = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'MessageQueue1
        '
        Me.MessageQueue1.SynchronizingObject = Me
        '
        'btnSend
        '
        Me.btnSend.Location = New System.Drawing.Point(200, 232)
        Me.btnSend.Name = "btnSend"
        Me.btnSend.Size = New System.Drawing.Size(80, 24)
        Me.btnSend.TabIndex = 0
        Me.btnSend.Text = "Send"
        '
        'txtBody
        '
        Me.txtBody.Location = New System.Drawing.Point(8, 144)
        Me.txtBody.Multiline = True
        Me.txtBody.Name = "txtBody"
        Me.txtBody.Size = New System.Drawing.Size(272, 80)
        Me.txtBody.TabIndex = 1
        Me.txtBody.Text = ".NET triggers can you hear me?"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 128)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Message Body"
        '
        'txtQueue
        '
        Me.txtQueue.Location = New System.Drawing.Point(8, 24)
        Me.txtQueue.Name = "txtQueue"
        Me.txtQueue.Size = New System.Drawing.Size(272, 20)
        Me.txtQueue.TabIndex = 3
        Me.txtQueue.Text = ".\private$\exeDemoqueue"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Queue Name"
        '
        'txtLabel
        '
        Me.txtLabel.Location = New System.Drawing.Point(10, 104)
        Me.txtLabel.Name = "txtLabel"
        Me.txtLabel.Size = New System.Drawing.Size(272, 20)
        Me.txtLabel.TabIndex = 5
        Me.txtLabel.Text = "calc"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "message label"
        '
        'CmbPriority
        '
        Me.CmbPriority.Location = New System.Drawing.Point(120, 56)
        Me.CmbPriority.Name = "CmbPriority"
        Me.CmbPriority.Size = New System.Drawing.Size(160, 21)
        Me.CmbPriority.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 56)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 16)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "message Priority"
        '
        'TestHarnessVBNet
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(290, 264)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.CmbPriority)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtLabel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtQueue)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtBody)
        Me.Controls.Add(Me.btnSend)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "TestHarnessVBNet"
        Me.Text = "Trigger Test"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
        Dim MyMessage As New System.Messaging.Message

        'Set the body from the textboxes
        MyMessage.Body = txtBody.Text
        'Set the priority from a combobox
        MyMessage.Priority = CmbPriority.SelectedIndex
        'Send message format
        MyMessage.Formatter = New ActiveXMessageFormatter
        'Create the queue
        Dim Q As New Messaging.MessageQueue(txtQueue.Text)
        'Send the message
        Q.Send(MyMessage, txtLabel.Text)
    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CmbPriority.Items.Add("Lowest")
        CmbPriority.Items.Add("Very Low")
        CmbPriority.Items.Add("Low")
        CmbPriority.Items.Add("Normal")
        CmbPriority.Items.Add("Above Normal")
        CmbPriority.Items.Add("High")
        CmbPriority.Items.Add("Very High")
        CmbPriority.Items.Add("Highest")

        CmbPriority.Text = "Normal"
    End Sub
End Class