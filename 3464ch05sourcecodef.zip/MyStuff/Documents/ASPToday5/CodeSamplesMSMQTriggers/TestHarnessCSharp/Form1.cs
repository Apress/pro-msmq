using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Messaging;


namespace TestHarnessCSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnSend;
		internal System.Windows.Forms.TextBox txtBody;
		internal System.Windows.Forms.Label Label4;
		internal System.Windows.Forms.ComboBox CmbPriority;
		internal System.Windows.Forms.Label Label3;
		internal System.Windows.Forms.TextBox txtLabel;
		internal System.Windows.Forms.Label Label2;
		internal System.Windows.Forms.TextBox txtQueue;
		internal System.Windows.Forms.Label Label1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnSend = new System.Windows.Forms.Button();
			this.txtBody = new System.Windows.Forms.TextBox();
			this.Label4 = new System.Windows.Forms.Label();
			this.CmbPriority = new System.Windows.Forms.ComboBox();
			this.Label3 = new System.Windows.Forms.Label();
			this.txtLabel = new System.Windows.Forms.TextBox();
			this.Label2 = new System.Windows.Forms.Label();
			this.txtQueue = new System.Windows.Forms.TextBox();
			this.Label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnSend
			// 
			this.btnSend.Location = new System.Drawing.Point(208, 240);
			this.btnSend.Name = "btnSend";
			this.btnSend.TabIndex = 0;
			this.btnSend.Text = "Send";
			this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
			// 
			// txtBody
			// 
			this.txtBody.Location = new System.Drawing.Point(8, 152);
			this.txtBody.Multiline = true;
			this.txtBody.Name = "txtBody";
			this.txtBody.Size = new System.Drawing.Size(272, 80);
			this.txtBody.TabIndex = 2;
			this.txtBody.Text = ".NET triggers can you hear me?";
			// 
			// Label4
			// 
			this.Label4.Location = new System.Drawing.Point(8, 56);
			this.Label4.Name = "Label4";
			this.Label4.Size = new System.Drawing.Size(96, 16);
			this.Label4.TabIndex = 15;
			this.Label4.Text = "message Priority";
			// 
			// CmbPriority
			// 
			this.CmbPriority.Location = new System.Drawing.Point(120, 56);
			this.CmbPriority.Name = "CmbPriority";
			this.CmbPriority.Size = new System.Drawing.Size(160, 21);
			this.CmbPriority.TabIndex = 14;
			// 
			// Label3
			// 
			this.Label3.Location = new System.Drawing.Point(8, 80);
			this.Label3.Name = "Label3";
			this.Label3.Size = new System.Drawing.Size(96, 16);
			this.Label3.TabIndex = 13;
			this.Label3.Text = "message label";
			// 
			// txtLabel
			// 
			this.txtLabel.Location = new System.Drawing.Point(16, 104);
			this.txtLabel.Name = "txtLabel";
			this.txtLabel.Size = new System.Drawing.Size(272, 20);
			this.txtLabel.TabIndex = 12;
			this.txtLabel.Text = "calc";
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(8, 8);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(96, 16);
			this.Label2.TabIndex = 11;
			this.Label2.Text = "Queue Name";
			// 
			// txtQueue
			// 
			this.txtQueue.Location = new System.Drawing.Point(8, 24);
			this.txtQueue.Name = "txtQueue";
			this.txtQueue.Size = new System.Drawing.Size(272, 20);
			this.txtQueue.TabIndex = 10;
			this.txtQueue.Text = ".\\private$\\exeDemoqueue";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(8, 128);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(96, 16);
			this.Label1.TabIndex = 9;
			this.Label1.Text = "Message Body";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 272);
			this.Controls.Add(this.Label4);
			this.Controls.Add(this.CmbPriority);
			this.Controls.Add(this.Label3);
			this.Controls.Add(this.txtLabel);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.txtQueue);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.txtBody);
			this.Controls.Add(this.btnSend);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "Form1";
			this.Text = "Trigger Test";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
        CmbPriority.Items.Add("Lowest");
        CmbPriority.Items.Add("Very Low");
        CmbPriority.Items.Add("Low");
        CmbPriority.Items.Add("Normal");
        CmbPriority.Items.Add("Above Normal");
        CmbPriority.Items.Add("High");
        CmbPriority.Items.Add("Very High");
        CmbPriority.Items.Add("Highest");

        CmbPriority.Text = "Normal";
		}

		private void btnSend_Click(object sender, System.EventArgs e)
		{
		 System.Messaging.Message MyMessage = new System.Messaging.Message();

        //Set the body from the textboxes
        MyMessage.Body = txtBody.Text;
        //Set the priority from a combobox
        MyMessage.Priority = (MessagePriority)CmbPriority.SelectedIndex;
        //Send message format
        MyMessage.Formatter = new ActiveXMessageFormatter();
       //Create the queue
        MessageQueue q = new MessageQueue(txtQueue.Text);
        //Send the message
        q.Send(MyMessage, txtLabel.Text);
		}
	}
}
