Imports System.IO
Imports System.Messaging
Public Class ComTriggerClass
    'COM Activated method
    Public Sub COMTriggerMethod(ByVal Message As String, _
                             ByVal DateRec As String, _
                             ByVal priority As String, _
                             ByVal MessageID As Byte(), _
                             ByVal FilePath As String)

        Dim OutputFile As String = FilePath & "COMTriggerDemo.txt"
        Dim output As TextWriter

        Dim messageIdout As String = convID(MessageID)
        'Create output file
        If (Not File.Exists(OutputFile)) Then
            output = File.CreateText(OutputFile)
        Else
            output = File.AppendText(OutputFile)
        End If
        'Write to output file
        output.WriteLine(String.Format("Message: {0} Received: {1} Priority {2} ID: {3}", Message, DateRec, priority, messageIdout))
        output.Close()
    End Sub

    'Method to Convert the Message ID a string
    'Example Format: 88c5a70b6f4e4ea49db07e2d9299cc8e\32835
    Private Function convID(ByVal msg As Byte()) As String
        Dim Outguid(15) As Byte
        Array.Copy(msg, Outguid, 16)
        Dim oguid As New Guid(Outguid)
        'start at position 16 to get the unique message id
        Dim intdword As UInt32 = BitConverter.ToUInt32(msg, 16)
        'Return the Message Queue ID
        Return (oguid.ToString & "\" & intdword.ToString)
    End Function

    'Method to Remove Message from queue
    Public Sub COMTriggerRemove(ByVal queuename As String, ByVal MessageID As Byte())
        Dim MsgId As String = convID(MessageID)
        Try
            'Define our Queue
            Dim Q As New Messaging.MessageQueue(queuename)
            Dim MEnum As MessageEnumerator = Q.GetMessageEnumerator
            'Loop through messages until we find ours, then remove it.
            While MEnum.MoveNext
                Dim message As Message = MEnum.Current
                'Message found - remove it.
                If (message.Id = MsgId) Then
                    MEnum.RemoveCurrent()
                    Exit While
                End If
            End While
        Catch
        End Try
    End Sub

End Class
