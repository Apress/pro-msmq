using System;
using System.Messaging;

namespace ResponseQueueReceiver
{
	
	class Receiver
	{
   public static String RESPONSE_QUEUE = 
     @".\private$\wroxresponse";

   public static String REQUEST_QUEUE = 
     @".\private$\wroxrequest";
   public static void Main(string[] args)
   {
     
       String corrId = null;
       MessageQueue responseQ = null;
       String RESPONSE = "FAILURE";
       
       try
       {
         if(!MessageQueue.Exists(REQUEST_QUEUE))
           MessageQueue.Create(REQUEST_QUEUE);

         if(!MessageQueue.Exists(RESPONSE_QUEUE))
           MessageQueue.Create(RESPONSE_QUEUE);
         //Create an instance of the MessageQueue
         MessageQueue q = new MessageQueue
           (RESPONSE_QUEUE);
         q.Formatter = new XmlMessageFormatter
           (new Type[]{typeof(System.String)});
         //Receive the file with a timeout of 3 seconds
         while(true)
         {
           System.Messaging.Message m = 
             q.Receive();
           String message = (String)m.Body;
           Console.WriteLine(message);
           RESPONSE = "SUCCESS";
           corrId = m.Id;
           Console.WriteLine("MessageId = " 
             + m.Id);
           //Write Response to the ResponseQueue
           responseQ = m.ResponseQueue;
           if(responseQ != null)
           {
             //Create a new Response Message
             System.Messaging.Message resp = 
               new System.Messaging.Message
               (RESPONSE);
             //Set the Id of m to CorrelationId resp
             resp.CorrelationId = corrId;
             //Send the message
             responseQ.Send(resp);
             Console.WriteLine("CorrelationId = " 
               + resp.CorrelationId);
           }

         }
        
        
       }
       catch(Exception ex)
       {
         Console.WriteLine(ex.Message);
         RESPONSE = "FAILURE";
       }
      
   }
	}
}
