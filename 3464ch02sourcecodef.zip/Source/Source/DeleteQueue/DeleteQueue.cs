using System;
using System.Messaging;

class MessageQueueOperations
{
 public static void Main(string[] args)
 {
  if(args.Length == 1)
  {
				try
				{
						MessageQueue.Delete(args[0]);
				}
				catch(MessageQueueException ex)
				{
						Console.WriteLine
								("Exception " 
								+ ex.Message);

						Console.WriteLine
								("Error Code " 
								+ ex.MessageQueueErrorCode.ToString());
				}
			
  }
  else
  {
   Console.WriteLine
    ("Usage:DeleteQueue " 
    + "[Path of the queue]");
  }
 }
}
