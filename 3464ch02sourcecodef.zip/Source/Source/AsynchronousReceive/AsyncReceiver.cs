using System;
using System.Messaging;
using System.Threading;

class AsyncReceiver
{
  private System.Messaging.MessageQueue messageQ;
  private static bool STOPPED = true;
  public AsyncReceiver(String path_of_the_queue)
  {
      this.messageQ = new MessageQueue(path_of_the_queue);
    //Create the Event Handler
    this.messageQ.ReceiveCompleted += 
      new System.Messaging.ReceiveCompletedEventHandler
      (this.messageQ_ReceiveCompleted);
    //Add a Formatter
    messageQ.Formatter = 
      new XmlMessageFormatter
      (new String[]{"System.String"});
    //Start receiving the message
    messageQ.BeginReceive(new TimeSpan(0,0,3));
            
  }

  public void messageQ_ReceiveCompleted(object source, 
    System.Messaging.ReceiveCompletedEventArgs 
    asyncResult)
  {
    MessageQueue tempMessageQ = null;
    try
    {
      // Connect to the queue.
      tempMessageQ = (MessageQueue)source;
      // End the asynchronous receive operation.
      System.Messaging.Message m = 
        tempMessageQ.EndReceive
        (asyncResult.AsyncResult);
      // Process the message here.
      Console.WriteLine();
      Console.WriteLine
        ("********************");
      Console.WriteLine
        (m.Body.ToString());
      Console.WriteLine
        ("********************");
      Console.WriteLine();

    }
    catch(MessageQueueException)
    {

    }

    catch(Exception ex)
    {
      Console.WriteLine(ex.Message);
    }
    finally
    {
      //Call this to continue processing
      this.messageQ.BeginReceive(
        new TimeSpan(0,0,3));

    }

  }

  static void WaitThread()
  {
    try
    {
      while(!STOPPED)
      {   //Sleep for 5 seconds
        Thread.Sleep(5 * 1000);

      }

      STOPPED = true;
    }
    catch(Exception)
    {}
  }

  [STAThread]
  static void Main(string[] args)
  {
    if(args.Length == 1)
    {
      if(!MessageQueue.Exists(args[0]))
      {
        MessageQueue.Create(args[0]);
        Console.WriteLine("Queue was not registered,"
          + "so new queue created for you");
      }
      AsyncReceiver ml = 
        new AsyncReceiver(args[0]);
      Thread t = 
        new Thread(
        new ThreadStart(AsyncReceiver.WaitThread));
      STOPPED = false;
      t.Start();
      Console.WriteLine
        ("Started Async Receiver Application");
          t.Join();
     

    }
    else
      Console.WriteLine
        ("Usage: AsynchronousReceive.exe [Path of the MSMQ]");

  }
}

