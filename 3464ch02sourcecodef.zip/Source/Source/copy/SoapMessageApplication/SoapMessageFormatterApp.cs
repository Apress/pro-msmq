using System;
using System.Messaging;
using MyFormatters;

namespace SoapMessageApplication
{
  [Serializable]
  public class Order
  {
    public String OrderId;
    public String CustomerName;
    public String CustomerLastName;
    public String OrderDate;
    public Order()
    {
      this.OrderDate = DateTime.Now.ToString();
    }

  }
	public class SoapMessageFormatterApp
	{
   public static void Main(string[] args)
   {
     if(args.Length == 1)
     {
       try
       {
         if(!MessageQueue.Exists(args[0]))
         {
           MessageQueue.Create(args[0]);
           Console.WriteLine("Queue was not registered,"
             + "so new queue created for you");
          }
         
         //Create an instance of the MessageQueue
         MessageQueue q = new MessageQueue
           (args[0]);
         //Create a new SoapMessageFormatter
         IMessageFormatter formatter = 
           new SoapMessageFormatter();
       
         //Create a new Order object
         Order o = new Order();
         o.OrderId = System.Guid.NewGuid().ToString();
         o.CustomerName = "Aaryan";
         o.CustomerLastName = "Redkar";
         //Create an instance of the Message
         System.Messaging.Message msg1
           = new System.Messaging.Message
           (o, formatter);
          //Send the message
         q.Send(msg1);
         Console.WriteLine("Message sent succesfully");
        
         Console.WriteLine("Waiting for Response.....");
         //Receive the message
         Message orderMsg = q.Receive
           (new TimeSpan(0, 0, 10));
         orderMsg.Formatter = formatter;
         Order oReceive = (Order)orderMsg.Body;
         Console.WriteLine("Received Order Message");
         Console.WriteLine("OrderId = " 
           + oReceive.OrderId);
         Console.WriteLine("OrderDate = " 
           + oReceive.OrderDate);
         Console.WriteLine("First Name = " 
           + oReceive.CustomerName);
         Console.WriteLine("Last Name = " 
           + oReceive.CustomerLastName);
       
       }
       catch(Exception ex)
       {
         Console.WriteLine
           (ex.Message);
       }
     }
     else
     {
       Console.WriteLine
         ("Usage:SoapMessageApplication " 
         + "[Path of the queue]");
     }
   }

   
	}
}
