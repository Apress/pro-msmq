using System;
using System.IO;
using System.Messaging;

public class ReceiveFile
{
  public static void Main(string[] args)
  {
    if(args.Length == 1)
    {
      try
      {
        //Create an instance of the MessageQueue
        MessageQueue q = new MessageQueue
          (args[0]);
        //Receive the file with a timeout of 3 seconds
        System.Messaging.Message m = 
          q.Receive(new TimeSpan(0, 0, 3));
        m.Formatter = new BinaryMessageFormatter();
        MemoryStream mem = (MemoryStream)m.Body;
        FileStream fStream = 
          new FileStream(m.Label, 
          FileMode.Create, FileAccess.ReadWrite);
        mem.WriteTo(fStream);
        Console.WriteLine
          ("File Received and copied to " + Environment.CurrentDirectory);
        mem.Close();
        fStream.Close();
      }
      catch(Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }
    else
    {
      Console.WriteLine
        ("Usage:ReceiveFile [Path of the queue]");
    }
  }
}
