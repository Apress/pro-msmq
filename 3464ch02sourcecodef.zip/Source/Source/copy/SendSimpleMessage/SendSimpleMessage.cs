using System;
using System.Messaging;

class SendSimpleMessage
{
  public static void Main(string[] args)
  {
    if(args.Length >= 2)
    {
      try
      {
								//Check whether the queue exists are not
        if(!MessageQueue.Exists(args[0]))
        {
          MessageQueue.Create(args[0]);
          Console.WriteLine("Queue was not registered,"+ 
            "so new queue created for you");

        }
        MessageQueue q = new MessageQueue
          (args[0]);
        String message = args[1];

        if(args.Length == 3)
          q.Send(message, args[2]);
        else
          q.Send(message);
     
        Console.WriteLine("Message sent succesfully");
     
      }
      catch(Exception ex)
      {
        Console.WriteLine
          ("Exception " + ex.Message);
      }
			
    }
    else
    {
      Console.WriteLine
        ("Usage:SendSimpleMessage [Path of the queue]"
        + "[Message Body] <Label (Optional)>");
    }
  }
}

