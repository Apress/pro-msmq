using System;
using System.IO;
using System.Messaging;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

public class SendFile
{
  public static void Main(string[] args)
  {
    if(args.Length == 1)
    {
      try
      {
        if(!MessageQueue.Exists(args[0]))
        {
          MessageQueue.Create(args[0]);
          Console.WriteLine("Queue was not registered,"+ 
            "so new queue created for you");
        }
        FileInfo fInfo = new FileInfo("Thermostat.xml");
        FileStream fStream = fInfo.OpenRead();
        byte[] b = new byte[fStream.Length];
        fStream.Read(b, 0, b.Length);
        MemoryStream mem = 
          new MemoryStream(b, 0, b.Length, false);
        //Create an instance of the MessageQueue
        MessageQueue q = new MessageQueue
          (args[0]);
        //Create a new BinaryMessageFormatter
        IMessageFormatter formatter = 
          new BinaryMessageFormatter();
        //Create an instance of the Message
        System.Messaging.Message msg1
          = new System.Messaging.Message(mem, formatter);
        //Set the Label of the 
        //Message to the file name
        msg1.Label = fInfo.Name;
        //Send the message
        q.Send(msg1);
        Console.WriteLine("File " + fInfo.Name
          + " sent succesfully");
        mem.Close();
        fStream.Close();
      }
      catch(Exception ex)
      {
        Console.WriteLine
          (ex.Message);
      }
    }
    else
    {
      Console.WriteLine
        ("Usage:FileSender [Path of the queue]");
    }
  }
}

