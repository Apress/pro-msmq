using System;
using System.Messaging;
using System.Xml;
using System.Data;
using System.Xml.Serialization;
using System.Text;
using System.IO;

class DeserializeDataSet
{
  public static void Main(string[] args)
  {
    if(args.Length == 1)
    {
      try
      {
        //Create an instance of the MessageQueue
        MessageQueue q = new MessageQueue
          (args[0]);
        //Receive DataSet with a timeout of 3 seconds
        System.Messaging.Message m = 
          q.Receive(new TimeSpan(0, 0, 3));
        //Create an XmlSerializer
        XmlSerializer ser = new XmlSerializer
          ( typeof(DataSet) );
        //Deserialize the DataSet
        DataSet ds = (DataSet)ser.Deserialize
          (m.BodyStream);
        Console.WriteLine(ds.GetXml());
      }
      catch(Exception ex)
      {
        Console.WriteLine
          ("Exception " + ex.Message);
      }
    }
    else
    {
      Console.WriteLine
        ("Usage:DeserializeDataSet [Path of the queue]");
    }
  }
}
