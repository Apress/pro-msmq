using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Messaging;

namespace MSMQUI
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Messaging.MessageQueue messageQueue1;
		private System.Windows.Forms.Label label4;
   private System.Windows.Forms.TextBox MessageLabel;
   private System.Windows.Forms.TextBox MessageBody;
   private System.Windows.Forms.TextBox SendPath;
   private System.Windows.Forms.Button SendMessage;
   private System.Windows.Forms.Button Clear;
   private System.Windows.Forms.Button ReceiveMessage;
   private System.Windows.Forms.TextBox ReceivePath;
   private System.Windows.Forms.TextBox Output;
   private System.Windows.Forms.Button PeekMessage;
   private System.Windows.Forms.Button GetAllMessages;
   private System.Windows.Forms.Button Purge;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
    this.groupBox2 = new System.Windows.Forms.GroupBox();
    this.GetAllMessages = new System.Windows.Forms.Button();
    this.PeekMessage = new System.Windows.Forms.Button();
    this.Clear = new System.Windows.Forms.Button();
    this.ReceiveMessage = new System.Windows.Forms.Button();
    this.label3 = new System.Windows.Forms.Label();
    this.ReceivePath = new System.Windows.Forms.TextBox();
    this.Output = new System.Windows.Forms.TextBox();
    this.statusBar1 = new System.Windows.Forms.StatusBar();
    this.groupBox3 = new System.Windows.Forms.GroupBox();
    this.Purge = new System.Windows.Forms.Button();
    this.label4 = new System.Windows.Forms.Label();
    this.MessageLabel = new System.Windows.Forms.TextBox();
    this.label2 = new System.Windows.Forms.Label();
    this.SendMessage = new System.Windows.Forms.Button();
    this.MessageBody = new System.Windows.Forms.TextBox();
    this.SendPath = new System.Windows.Forms.TextBox();
    this.messageQueue1 = new System.Messaging.MessageQueue();
    this.groupBox2.SuspendLayout();
    this.groupBox3.SuspendLayout();
    this.SuspendLayout();
    // 
    // groupBox2
    // 
    this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.GetAllMessages,
                                                                          this.PeekMessage,
                                                                          this.Clear,
                                                                          this.ReceiveMessage,
                                                                          this.label3,
                                                                          this.ReceivePath,
                                                                          this.Output});
    this.groupBox2.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.groupBox2.ForeColor = System.Drawing.Color.Blue;
    this.groupBox2.Location = new System.Drawing.Point(471, 0);
    this.groupBox2.Name = "groupBox2";
    this.groupBox2.Size = new System.Drawing.Size(502, 434);
    this.groupBox2.TabIndex = 1;
    this.groupBox2.TabStop = false;
    this.groupBox2.Text = "Receive/Peek Message Synchronously";
    // 
    // GetAllMessages
    // 
    this.GetAllMessages.ForeColor = System.Drawing.Color.Blue;
    this.GetAllMessages.Location = new System.Drawing.Point(174, 365);
    this.GetAllMessages.Name = "GetAllMessages";
    this.GetAllMessages.Size = new System.Drawing.Size(164, 40);
    this.GetAllMessages.TabIndex = 8;
    this.GetAllMessages.Text = "GetAllMessages";
    this.GetAllMessages.Click += new System.EventHandler(this.GetAllMessages_Click);
    // 
    // PeekMessage
    // 
    this.PeekMessage.ForeColor = System.Drawing.Color.Blue;
    this.PeekMessage.Location = new System.Drawing.Point(358, 365);
    this.PeekMessage.Name = "PeekMessage";
    this.PeekMessage.Size = new System.Drawing.Size(134, 40);
    this.PeekMessage.TabIndex = 7;
    this.PeekMessage.Text = "Peek ";
    this.PeekMessage.Click += new System.EventHandler(this.PeekMessage_Click);
    // 
    // Clear
    // 
    this.Clear.ForeColor = System.Drawing.Color.Blue;
    this.Clear.Location = new System.Drawing.Point(389, 286);
    this.Clear.Name = "Clear";
    this.Clear.Size = new System.Drawing.Size(103, 40);
    this.Clear.TabIndex = 6;
    this.Clear.Text = "Clear";
    this.Clear.Click += new System.EventHandler(this.Clear_Click);
    // 
    // ReceiveMessage
    // 
    this.ReceiveMessage.ForeColor = System.Drawing.Color.Blue;
    this.ReceiveMessage.Location = new System.Drawing.Point(10, 365);
    this.ReceiveMessage.Name = "ReceiveMessage";
    this.ReceiveMessage.Size = new System.Drawing.Size(144, 40);
    this.ReceiveMessage.TabIndex = 5;
    this.ReceiveMessage.Text = "Receive";
    this.ReceiveMessage.Click += new System.EventHandler(this.ReceiveMessage_Click);
    // 
    // label3
    // 
    this.label3.Location = new System.Drawing.Point(236, 286);
    this.label3.Name = "label3";
    this.label3.Size = new System.Drawing.Size(133, 29);
    this.label3.TabIndex = 4;
    this.label3.Text = "Queue Path";
    // 
    // ReceivePath
    // 
    this.ReceivePath.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.ReceivePath.ForeColor = System.Drawing.SystemColors.WindowText;
    this.ReceivePath.Location = new System.Drawing.Point(20, 286);
    this.ReceivePath.Name = "ReceivePath";
    this.ReceivePath.Size = new System.Drawing.Size(205, 34);
    this.ReceivePath.TabIndex = 3;
    this.ReceivePath.Text = ".\\private$\\myfirstq";
    // 
    // Output
    // 
    this.Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.Output.Location = new System.Drawing.Point(20, 30);
    this.Output.Multiline = true;
    this.Output.Name = "Output";
    this.Output.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
    this.Output.Size = new System.Drawing.Size(472, 246);
    this.Output.TabIndex = 2;
    this.Output.Text = "";
    // 
    // statusBar1
    // 
    this.statusBar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.statusBar1.Location = new System.Drawing.Point(0, 433);
    this.statusBar1.Name = "statusBar1";
    this.statusBar1.Size = new System.Drawing.Size(983, 27);
    this.statusBar1.TabIndex = 2;
    // 
    // groupBox3
    // 
    this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.Purge,
                                                                          this.label4,
                                                                          this.MessageLabel,
                                                                          this.label2,
                                                                          this.SendMessage,
                                                                          this.MessageBody,
                                                                          this.SendPath});
    this.groupBox3.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.groupBox3.ForeColor = System.Drawing.Color.DarkGreen;
    this.groupBox3.Location = new System.Drawing.Point(20, 0);
    this.groupBox3.Name = "groupBox3";
    this.groupBox3.Size = new System.Drawing.Size(441, 434);
    this.groupBox3.TabIndex = 3;
    this.groupBox3.TabStop = false;
    this.groupBox3.Text = "Send Message";
    // 
    // Purge
    // 
    this.Purge.ForeColor = System.Drawing.Color.Green;
    this.Purge.Location = new System.Drawing.Point(102, 237);
    this.Purge.Name = "Purge";
    this.Purge.Size = new System.Drawing.Size(154, 39);
    this.Purge.TabIndex = 6;
    this.Purge.Text = "Purge";
    this.Purge.Click += new System.EventHandler(this.Purge_Click);
    // 
    // label4
    // 
    this.label4.Location = new System.Drawing.Point(287, 79);
    this.label4.Name = "label4";
    this.label4.Size = new System.Drawing.Size(128, 39);
    this.label4.TabIndex = 5;
    this.label4.Text = "Label";
    // 
    // MessageLabel
    // 
    this.MessageLabel.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.MessageLabel.Location = new System.Drawing.Point(20, 79);
    this.MessageLabel.Name = "MessageLabel";
    this.MessageLabel.Size = new System.Drawing.Size(256, 31);
    this.MessageLabel.TabIndex = 4;
    this.MessageLabel.Text = "Message Label";
    // 
    // label2
    // 
    this.label2.Location = new System.Drawing.Point(287, 39);
    this.label2.Name = "label2";
    this.label2.Size = new System.Drawing.Size(128, 29);
    this.label2.TabIndex = 3;
    this.label2.Text = "Queue Path";
    // 
    // SendMessage
    // 
    this.SendMessage.ForeColor = System.Drawing.Color.Green;
    this.SendMessage.Location = new System.Drawing.Point(266, 237);
    this.SendMessage.Name = "SendMessage";
    this.SendMessage.Size = new System.Drawing.Size(154, 39);
    this.SendMessage.TabIndex = 2;
    this.SendMessage.Text = "Send Message";
    this.SendMessage.Click += new System.EventHandler(this.SendMessage_Click);
    // 
    // MessageBody
    // 
    this.MessageBody.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.MessageBody.Location = new System.Drawing.Point(20, 128);
    this.MessageBody.Multiline = true;
    this.MessageBody.Name = "MessageBody";
    this.MessageBody.ScrollBars = System.Windows.Forms.ScrollBars.Both;
    this.MessageBody.Size = new System.Drawing.Size(400, 99);
    this.MessageBody.TabIndex = 1;
    this.MessageBody.Text = "My Message";
    // 
    // SendPath
    // 
    this.SendPath.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.SendPath.Location = new System.Drawing.Point(20, 39);
    this.SendPath.Name = "SendPath";
    this.SendPath.Size = new System.Drawing.Size(256, 34);
    this.SendPath.TabIndex = 0;
    this.SendPath.Text = ".\\private$\\myfirstq";
    // 
    // messageQueue1
    // 
    this.messageQueue1.SynchronizingObject = this;
    // 
    // Form1
    // 
    this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
    this.ClientSize = new System.Drawing.Size(983, 460);
    this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                this.groupBox3,
                                                                this.statusBar1,
                                                                this.groupBox2});
    this.Name = "Form1";
    this.Text = "MSMQUI";
    this.groupBox2.ResumeLayout(false);
    this.groupBox3.ResumeLayout(false);
    this.ResumeLayout(false);

  }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void SendMessage_Click(object sender, System.EventArgs e)
		{
			try 
			{
				statusBar1.Text = "";

				//Set the Path property of the messageQueue1 object
				messageQueue1.Path = SendPath.Text.Trim ();

				/*

				Specify the MessageFormatter.Default MessageFormatter is XmlMessageFormatter
				If you want to use ActiveX or primitive types like string, int, etc., use the ActiveXMessageFormatter
				I recommend you to add a Formatter to the queue in the InitiailzeComponent() method, so you don�t have to add it for every  call to SendMessage()

				*/

     messageQueue1.Formatter = new XmlMessageFormatter(new Type[]{typeof(System.String)});

				//Send the message to the queue
				//Note that the Send() method is not a static method and has to be called on an object
		

				messageQueue1.Send ((string)MessageBody.Text.Trim(), this.MessageLabel.Text.Trim() );

				statusBar1.Text = "FormatName = " + messageQueue1.FormatName;	

			}
			catch(MessageQueueException ex)
			{
				statusBar1.Text = "";
				statusBar1.Text = ex.Message;

			}
			catch(Exception ex1)
			{

				statusBar1.Text = "";
				statusBar1.Text = ex1.Message;

			}
			



		}

		private void ReceiveMessage_Click(object sender, System.EventArgs e)
		{
			statusBar1.Text = "";
 
			try 
			{

				messageQueue1.Path = ReceivePath.Text.Trim();
				System.Messaging.Message msq = messageQueue1.Receive (new TimeSpan(0, 0, 2));
    msq.Formatter = new XmlMessageFormatter(new Type[]{typeof(System.String)});
     Output.AppendText("--------------------\r\n");
     Output.AppendText("Receive Operation\r\n");
     Output.AppendText("Body = " + (string)msq.Body);
     Output.AppendText("\r\n");
     Output.AppendText("Id = " + msq.Id);
     Output.AppendText("\r\n--------------------\r\n");
				statusBar1.Text = "FormatName = " + messageQueue1.FormatName;	

			}
			catch(MessageQueueException ex)
			{

				statusBar1.Text = "";
				statusBar1.Text = ex.Message;

			}
			catch(Exception ex1)
			{

				statusBar1.Text = "";
				statusBar1.Text = ex1.Message;

			}
            
		}

		private void Clear_Click(object sender, System.EventArgs e)
		{
			Output.Clear();
		}

   private void PeekMessage_Click(object sender, System.EventArgs e)
   {
     statusBar1.Text = "";
 
     try 
     {

       messageQueue1.Path = ReceivePath.Text.Trim();
       System.Messaging.Message msq = 
         messageQueue1.Peek(new TimeSpan(0, 0, 2));
       msq.Formatter = new XmlMessageFormatter
         (new Type[]{typeof(System.String)});
       Output.AppendText("--------------------\r\n");
       Output.AppendText("Peek Operation\r\n");
       Output.AppendText("Body = " + (string)msq.Body);
       Output.AppendText("\r\n");
       Output.AppendText("Id = " + msq.Id);
       Output.AppendText("\r\n--------------------\r\n");
       statusBar1.Text = "FormatName = " 
         + messageQueue1.FormatName;	

     }
     catch(MessageQueueException ex)
     {
       statusBar1.Text = "";

        if(ex.MessageQueueErrorCode
          .Equals(MessageQueueErrorCode.IOTimeout))
          statusBar1.Text = "Queue is Empty";
        else
          statusBar1.Text = ex.Message;

     }
     catch(Exception ex1)
     {

       statusBar1.Text = "";
       statusBar1.Text = ex1.Message;

     }
   }

   private void GetAllMessages_Click(object sender, System.EventArgs e)
   {
     statusBar1.Text = "";
 
     try 
     {

       messageQueue1.Path = ReceivePath.Text.Trim();
       messageQueue1.Formatter = new XmlMessageFormatter
         (new Type[]{typeof(System.String)});
       System.Messaging.Message[] msqs = 
         messageQueue1.GetAllMessages();
       Output.AppendText("GetAllMessages Operation\r\n");
       foreach(System.Messaging.Message msq in msqs)
       {
         Output.AppendText("--------------------\r\n");
         Output.AppendText("Body = " + (string)msq.Body);
         Output.AppendText("\r\n");
         Output.AppendText("Id = " + msq.Id);
         Output.AppendText("\r\n--------------------\r\n");
       }
       
     }
     catch(MessageQueueException ex)
     {
       statusBar1.Text = "";

       if(ex.MessageQueueErrorCode
         .Equals(MessageQueueErrorCode.IOTimeout))
         statusBar1.Text = "Queue is Empty";
       else
         statusBar1.Text = ex.Message;

     }
     catch(Exception ex1)
     {

       statusBar1.Text = "";
       statusBar1.Text = ex1.Message;

     }
   }

   private void Purge_Click(object sender, System.EventArgs e)
   {
     try 
     {
       statusBar1.Text = "";

       //Set the Path property of the messageQueue1 object
       messageQueue1.Path = SendPath.Text.Trim ();

     	 messageQueue1.Purge();

     }
     catch(MessageQueueException ex)
     {
       statusBar1.Text = "";
       statusBar1.Text = ex.Message;

     }
     catch(Exception ex1)
     {

       statusBar1.Text = "";
       statusBar1.Text = ex1.Message;

     }
   }

		
	}
}
