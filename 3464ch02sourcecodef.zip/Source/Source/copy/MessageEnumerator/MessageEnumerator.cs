using System;
using System.Messaging;
using System.Collections;
using System.Collections.Specialized;

namespace MessageEnumerator
{
	
	class MessageEnumerator
	{
			
		static void Main(string[] args)
		{
    if(args.Length == 1)
    {
      try
      {   
        if(!MessageQueue.Exists(args[0]))
          MessageQueue.Create(args[0]);
        //Create an instance of the MessageQueue
        MessageQueue q = new MessageQueue
          (args[0]);
        q.Formatter = new ActiveXMessageFormatter();
        String message = "Test Message";
        //Send 10 Messages
        for(int i = 0 ; i < 10 ; i++)
        {
          //Create an instance of the Message
          System.Messaging.Message msg1
            = new System.Messaging.Message
            (message);
          msg1.Formatter = new ActiveXMessageFormatter();
          msg1.Label = message + i;
      
          //Send the message
          q.Send(msg1);
        }  
       System.Messaging. MessageEnumerator en = 
          q.GetMessageEnumerator();

        q.MessageReadPropertyFilter
          .Label = true;
        q.MessageReadPropertyFilter
          .Body = true;
        q.MessageReadPropertyFilter
          .Priority = true;

        //String source_queue_path = null;
        while(en.MoveNext())
        {
     
          Console.WriteLine("Message Label " 
            + en.Current.Label);
           Console.WriteLine("Message Body " 
            + en.Current.Body.ToString());
          Console.WriteLine("Message Priority " 
            + en.Current.Priority.ToString());

        }

      }
      
      catch(Exception ex)
      {Console.WriteLine(ex.Message);}

    }
    else
    {
      Console.WriteLine("The Queue was not specified");
    }
			
		}
	}
}
