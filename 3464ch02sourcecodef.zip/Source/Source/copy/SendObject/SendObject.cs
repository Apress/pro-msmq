using System;
using System.Messaging;

public class Thermostat
{
  private double _currentTemperature;
  private double _setPointValue;
  private String _id;
  public Thermostat()
  {
    this._id = System.Guid.NewGuid().ToString();
  }


  public double CurrentTemperature
  {
    get
    {
      return this._currentTemperature;

    }

    set
    {
      this._currentTemperature = value;

    }

  }

  public double SetPointValue
  {
    get
    {
      return this._setPointValue;

    }

    set
    {
      this._setPointValue = value;

    }


  }   

  
  public String ID
  {
    get
    {
      return this._id;

    }
    set
    {
      this._id = value;

    }

  }

}
class SendObject
{

 public static void Main(string[] args)
 {
  if(args.Length == 1)
  {
   try
   {
    if(!MessageQueue.Exists(args[0]))
    {
     MessageQueue.Create(args[0]);
     Console.WriteLine("Queue was not registered,"+ 
      "so new queue created for you");

    }
    MessageQueue q = new MessageQueue
     (args[0]);
   
    Thermostat message = new Thermostat();
     message.CurrentTemperature = 78.6;
     message.SetPointValue = 86.7;
     q.Send(message, message.ID);
    
    Console.WriteLine("Message sent succesfully");
     
   }
   catch(Exception ex)
   {
    Console.WriteLine
     ("Exception " + ex.Message);
   }
			
  }
  else
  {
   Console.WriteLine
    ("Usage:SendObject [Path of the queue]");
  }
 }
}
