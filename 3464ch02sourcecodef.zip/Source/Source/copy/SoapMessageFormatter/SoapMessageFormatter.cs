using System;
using System.Messaging;
using System.Runtime.Serialization.Formatters.Soap;

namespace MyFormatters
{
	[Serializable]
	public class SoapMessageFormatter : IMessageFormatter
	{
		public SoapMessageFormatter()
		{
			
		}
   public object Clone ()
   {
     return this.MemberwiseClone();
   }

   public bool CanRead (Message message)
   {
     bool isValid = false;
     try
     {
       SoapFormatter soap = new SoapFormatter();
       object obj = soap.Deserialize(message.BodyStream);
       if(obj != null)
         return true;
     }
     catch(Exception)
     {
       isValid = true;
     }
       
     return isValid;
   }

   public object Read (Message message)
   { 
     try
     {
       SoapFormatter soap = new SoapFormatter();
       return soap.Deserialize(message.BodyStream);
     }
     catch(Exception ex)
     {
       throw ex;
     }
   }

   public void Write (Message message,
     object obj)
   {
     try
     {
       SoapFormatter soap = new SoapFormatter();
       message.BodyStream = new System.IO.MemoryStream();
       soap.Serialize(message.BodyStream,
         obj);

     }
     catch(Exception ex)
     {
       throw ex;
     }
     
   }
	}
}
