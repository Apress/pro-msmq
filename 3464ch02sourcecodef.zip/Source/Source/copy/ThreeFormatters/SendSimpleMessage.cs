using System;
using System.Messaging;

class SendSimpleMessage
{
		public static void Main(string[] args)
		{
				if(args.Length == 2)
				{
						try
						{
								//Check whether the queue exists are not
								if(!MessageQueue.Exists(args[0]))
								{
										MessageQueue.Create(args[0]);
										Console.WriteLine("Queue was not registered,"+ 
												"so new queue created for you");

								}
								MessageQueue mq1 = new MessageQueue(args[0]);
								//Create a new XmlMessageFormatter
								IMessageFormatter formatter = 
										new XmlMessageFormatter(new Type[]{typeof(System.String)});
								//Assign the formatter to the queue
								mq1.Formatter = formatter;
								String message = args[1];
								//Create a new Message object with body 
								Message m1 = new Message(message);
        m1.Label = "XmlMessageFormatter";
								//Send the Message
								mq1.Send(m1);
								Console.WriteLine("Message sent succesfully using " 
										+ "XmlMessageFormatter");
								//Create a new ActiveXMessageFormatter
								formatter = new ActiveXMessageFormatter();
								//Create a new Message with body and formatter
								Message m2 = new Message(message, formatter);
        m2.Label = "ActiveXMessageFormatter";
								//Send the message
								mq1.Send(m2);
								Console.WriteLine("Message sent succesfully using " 
										+ "ActiveXMessageFormatter");
								//Create a new BinaryMessageFormatter
								formatter = new BinaryMessageFormatter();
								//Create a new Message with body and formatter
								Message m3 = new Message(message, formatter);
        m3.Label = "BinaryMessageFormatter";
								//Send the message
								mq1.Send(m3);
								Console.WriteLine("Message sent succesfully using " 
										+ "BinaryMessageFormatter");
						}
						
						catch(MessageQueueException ex)
						{
								Console.WriteLine
										("Exception " 
										+ ex.Message);

								Console.WriteLine
										("Error Code " 
										+ ex.MessageQueueErrorCode.ToString());
						}

				}
				else
				{
						Console.WriteLine
								("Usage:ThreeFormatters [Path of the queue]"
								+ "[Message Body]");
				}
		}
}
