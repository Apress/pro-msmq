using System;
using System.Messaging;

class PurgeQueue
{
public static void Main(string[] args)
{
		if(args.Length >= 1)
		{
				try
				{
						if(!MessageQueue.Exists(args[0]))
						{
								Console.WriteLine(
										"Queue does not exist, please try again");
						}
						MessageQueue q = new MessageQueue(args[0]);
						q.Purge();
				
						Console.WriteLine("Messages deleted successfully");
				
				}
				catch(MessageQueueException ex)
				{
						Console.WriteLine
								("Exception " 
								+ ex.Message);

						Console.WriteLine
								("Error Code " 
								+ ex.MessageQueueErrorCode.ToString());
				}

		}
		else
		{
				Console.WriteLine
						("Usage:PurgeQueue " 
						+ "[Path of the queue]");
		}
}
}
