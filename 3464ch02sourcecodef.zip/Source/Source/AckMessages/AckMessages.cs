using System;
using System.Messaging;

class AckMessages
{
  public static void Main(string[] args)
  {
    if(args.Length >= 1)
    {
      try
      {
        if(!MessageQueue.Exists(args[0]))
        {
          MessageQueue.Create(args[0]);
          Console.WriteLine("Queue does not exist,"
            + "so new queue created for you");
        }
        
        if(!MessageQueue.Exists(@".\Private$\AdminQueue"))
        {
          MessageQueue.Create(@".\Private$\AdminQueue");
          Console.WriteLine("Queue does not exist,"
            + "so new queue created for you");
        }
        MessageQueue msgQ= new MessageQueue(args[0]); 
        msgQ.DefaultPropertiesToSend.AdministrationQueue=
          new MessageQueue(@".\Private$\AdminQueue");
        msgQ.DefaultPropertiesToSend.AcknowledgeType=
          AcknowledgeTypes.FullReachQueue|AcknowledgeTypes.FullReceive;
        msgQ.Send("Sample");
        Console.WriteLine("Message sent successfully");
        //Receive Message
        Message msg;
        msg= msgQ.Receive(new TimeSpan(0));
        Console.WriteLine("Message Received {0}", msg.Id);
      }
      catch(Exception ex)
      {
        Console.WriteLine("Exception " + ex.Message);
      }
    }
    else
    {
      Console.WriteLine
        ("Usage:AckMessages " 
        + "[Path of the queue]");
    }
  }
}
