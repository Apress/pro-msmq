using System;
using System.Messaging;

namespace ResponseQueue
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class ResponseQueue
	{
		public static String RESPONSE_QUEUE = 
    @".\private$\apressresponse";

 
		static void Main(string[] args)
		{
     
        try
        {   
          if(!MessageQueue.Exists(args[0]))
            MessageQueue.Create(args[0]);
          //Create an instance of the MessageQueue
          MessageQueue q = new MessageQueue
            (args[0]);
          String message = "Test Message";
          //Create an instance of the Message
          System.Messaging.Message msg1
            = new System.Messaging.Message
            (message);
          if(!MessageQueue.Exists(RESPONSE_QUEUE))
            MessageQueue.Create(RESPONSE_QUEUE);
          //Create an instance of the ResponseQueue
          MessageQueue response = new MessageQueue
            (RESPONSE_QUEUE);
          //Assign the ResponseQueue property
          msg1.ResponseQueue = response;
          //Send the message
          q.Send(msg1);
          //Get the Id of the sent message.
          String corrId = msg1.Id;
          Console.WriteLine(corrId);
          Console.WriteLine("Message sent successfully");
          //Receive the message and send the response to the
          // response queue
          q.Formatter = new XmlMessageFormatter
            (new String[]{"System.String"});
          Message receiveMsg = q.Receive(new TimeSpan(0, 0, 2));
          //Get the response queue from the receiveMsg
          response = receiveMsg.ResponseQueue;
          //Set the correlationId of the message to the 
          //Id of the original message
          receiveMsg.CorrelationId = corrId;
          //Send the response message to the response queue
          response.Send(receiveMsg);
        
          Console.WriteLine("Waiting for Response.....");
          //Receive the Response message by mapping
          //the CorrrelationId to the Id of the
          //Original message
          Message responseMessage = 
            response.ReceiveByCorrelationId(corrId, 
            new TimeSpan(0, 0, 30));
          responseMessage.Formatter = 
            (new XmlMessageFormatter
            (new Type[]{typeof(System.String)}));
          Console.WriteLine(responseMessage.Label);
          Console.WriteLine
            ("Received Response from Response Queue");
          Console.WriteLine
            (responseMessage.Body.ToString());

        }
        catch(Exception ex)
        {Console.WriteLine(ex.Message);}

		}
	}
}
