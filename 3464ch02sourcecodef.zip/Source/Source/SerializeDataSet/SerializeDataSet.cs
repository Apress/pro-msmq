using System;
using System.Messaging;
using System.Xml;
using System.Data;
using System.Xml.Serialization;
using System.Text;

class SerializeDataSet
{
  public static void Main(string[] args)
  {
    if(args.Length == 1)
    {
      try
      {
        if(!MessageQueue.Exists(args[0]))
        {
          MessageQueue.Create(args[0]);
          Console.WriteLine("Queue was not registered,"+ 
            "so new queue created for you");
        }
        DataSet ds = new DataSet("ThermostatDataSet");
        ds.ReadXml("Thermostat.xml");
        //Create an instance of the MessageQueue
        MessageQueue q = new MessageQueue
          (args[0]);
        //Create an instance of the Message
        System.Messaging.Message msg1
          = new System.Messaging.Message();
        //Set the Label of the Message 
        //to the formatter name
        msg1.Label = "XmlSerializer DataSet Message";
        //Create an XmlSerializer
        XmlSerializer ser = new XmlSerializer
          ( typeof(DataSet) );
        //Create an XmlTextWriter with BodyStream
        // as its storage stream and UTF-8 encoding.
        XmlTextWriter writer = new XmlTextWriter
          ( msg1.BodyStream, Encoding.UTF8);
        //Serialize the DataSet to the XmlTextWriter
        // and hence to the BodyStream.
        ser.Serialize( writer, ds );
        //Send the message
        q.Send(msg1);
        Console.WriteLine("XmlSerialized DataSet " 
          + "Message sent successfully");
      }
      catch(Exception ex)
      {
        Console.WriteLine
          ("Exception " + ex.StackTrace);
      }
    }
    else
    {
      Console.WriteLine
        ("Usage:SerializeDataSet [Path of the queue]");
    }
  }
}
