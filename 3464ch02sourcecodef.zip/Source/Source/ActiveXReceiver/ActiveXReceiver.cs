using System;
using System.Messaging;
using System.Runtime.InteropServices;
using VBThermostat;

public class ActiveXReceiver
{
  private static void PrintThermostat
    (VBThermostat.ThermostatClass thermostat)
  {
    Console.WriteLine();
    Console.WriteLine("***********************");
    Console.WriteLine("ThermostatID = " 
      + thermostat.ID);
    Console.WriteLine
      ("Current Temperature = " 
      + thermostat.CurrentTemperature);
    Console.WriteLine
      ("Set-Point Temperature = " 
      + thermostat.SetPoint);
    Console.WriteLine("***********************");
    Console.WriteLine();
  }
  public static void Main(string[] args)
  {
    if(args.Length == 1)
    {
      try
      {
        //Create an instance of the MessageQueue
        MessageQueue q = new MessageQueue
          (args[0]);
        //Receive the file with a timeout of 3 seconds
        System.Messaging.Message m1 = 
          q.Receive(new TimeSpan(0, 0, 3));
        //Set the Formatter to ActiveXFormatter
        m1.Formatter = new ActiveXMessageFormatter();
        //Cast the Body to the ThermostatClass
        VBThermostat.ThermostatClass thermostat = 
          (VBThermostat.ThermostatClass)m1.Body;
        Console.WriteLine("Received Thermostat");
        PrintThermostat(thermostat);
        //Now change the thermostat and send it back
        thermostat.ID = System.Guid.NewGuid().ToString();
        thermostat.CurrentTemperature = 80.5;
        thermostat.SetPoint = 70.5;
        System.Messaging.Message m2 = 
          new System.Messaging.Message(thermostat);
        m2.Formatter = new ActiveXMessageFormatter();
        q.Send(m2);
        Console.WriteLine("New Thermostat sent " 
          + " successfully with the following values.");
        PrintThermostat(thermostat);
      }
      catch(Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }
    else
    {
      Console.WriteLine
        ("Usage:ActiveXReceiver [Path of the queue]");
    }
  }
}

