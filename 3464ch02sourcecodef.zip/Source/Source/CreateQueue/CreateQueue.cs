using System;
using System.Messaging;

class MessageQueueOperations
{
 public static void Main(string[] args)
 {
  if(args.Length == 2)
  {
   try
   {
    if(!MessageQueue.Exists(args[0]))
    {
     MessageQueue q = MessageQueue.Create
      (args[0], Convert.ToBoolean(args[1]));
    }
    else
    {
     Console.WriteLine
      ("MessageQueue " + args[0] 
      + " already exists in MSMQ.");
    }
   }
   catch(Exception ex)
   {
    Console.WriteLine
     ("Exception " 
     + ex.Message);
   }
			
  }
  else
  {
   Console.WriteLine
    ("Usage:CreateQueue [Path of the queue]"
    + "[True/Fale for transactional/non-transactional]");
  }
 }
}
