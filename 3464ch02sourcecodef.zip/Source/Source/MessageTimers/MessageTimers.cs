using System;
using System.Messaging;

class MessageTimers
{
  public static void Main(string[] args)
  {
    if(args.Length == 1)
    {
      try
      {
        if(!MessageQueue.Exists(args[0]))
        {
          MessageQueue.Create(args[0]);
          Console.WriteLine("Queue was not registered,"+ 
            "so new queue created for you");
        }
        //Create an instance of the Message Queue.
        MessageQueue q = new MessageQueue
          (args[0]);
        //Create an instance of the Message
        System.Messaging.Message msg1
          = new System.Messaging.Message("TestMessage");
        //Set the TimeToReachQueue to 20 seconds
        msg1.TimeToReachQueue = new TimeSpan(0, 0, 20);
        //Set the TimeToBeReceived to one minute
        msg1.TimeToBeReceived = new TimeSpan(0, 1, 0);
        //Set the UsesDeadLetterQueue property to true
        // to send the expired message to the dead-letter
        msg1.UseDeadLetterQueue = true;
        //Send the message
        q.Send(msg1);
        Console.WriteLine("Message sent successfully");
      }
      catch(Exception ex)
      {
        Console.WriteLine
          ("Exception " + ex.Message);
      }
    }
    else
    {
      Console.WriteLine
        ("Usage:MessageTimers [Path of the queue]");
    }
  }
}
