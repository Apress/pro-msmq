using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Messaging;

namespace Listing3._4
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MessageQueueOperations : System.Windows.Forms.Form
	{
  private System.Windows.Forms.GroupBox groupBox1;
  private System.Windows.Forms.TextBox path;
  private System.Windows.Forms.Label path_label;
  private System.Windows.Forms.Button Create;
  private System.Windows.Forms.Button Exists;
  private System.Windows.Forms.Button Delete;
  private System.Windows.Forms.GroupBox output_groupBox;
  private System.Windows.Forms.StatusBar statusBar;
  private System.Windows.Forms.GroupBox mqfilter;
  private System.Windows.Forms.CheckBox Category_Check;
  private System.Windows.Forms.TextBox Category_Value;
  private System.Windows.Forms.CheckBox Label_Check;
  private System.Windows.Forms.TextBox Label_Value;
  private System.Windows.Forms.CheckBox MachineName_Check;
  private System.Windows.Forms.TextBox MachineName_Value;
  private System.Windows.Forms.TextBox output;
  private System.Windows.Forms.CheckBox CreatedBefore_Check;
  private System.Windows.Forms.DateTimePicker CreatedBefore_Value;
  private System.Windows.Forms.CheckBox CreatedAfter_Check;
  private System.Windows.Forms.DateTimePicker CreatedAfter_Value;
  private System.Windows.Forms.CheckBox ModifiedBefore_Check;
  private System.Windows.Forms.DateTimePicker ModifiedBefore_Value;
  private System.Windows.Forms.DateTimePicker ModifiedAfter_Value;
  private System.Windows.Forms.RadioButton UseMQCriteria;
  private System.Windows.Forms.GroupBox groupBox2;
  private System.Windows.Forms.Button GetMachineId;
  private System.Windows.Forms.Button GetMessageQueueEnumerator;
  private System.Windows.Forms.Button GetPrivateQueuesByMachine;
  private System.Windows.Forms.Button GetPublicQueues;
  private System.Windows.Forms.Button GetPublicQueuesByCategory;
  private System.Windows.Forms.Button GetPublicQueuesByLabel;
  private System.Windows.Forms.Button GetPublicQueuesByMachine;
  private System.Windows.Forms.TextBox Input;
  private System.Windows.Forms.Label label1;
  private System.Windows.Forms.RadioButton transactional;
  private System.Windows.Forms.Button ClearAll;
  private System.Windows.Forms.CheckBox ModifiedAfter_Check;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MessageQueueOperations()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
   this.groupBox1 = new System.Windows.Forms.GroupBox();
   this.transactional = new System.Windows.Forms.RadioButton();
   this.Delete = new System.Windows.Forms.Button();
   this.Exists = new System.Windows.Forms.Button();
   this.Create = new System.Windows.Forms.Button();
   this.path_label = new System.Windows.Forms.Label();
   this.path = new System.Windows.Forms.TextBox();
   this.statusBar = new System.Windows.Forms.StatusBar();
   this.output_groupBox = new System.Windows.Forms.GroupBox();
   this.ClearAll = new System.Windows.Forms.Button();
   this.output = new System.Windows.Forms.TextBox();
   this.mqfilter = new System.Windows.Forms.GroupBox();
   this.UseMQCriteria = new System.Windows.Forms.RadioButton();
   this.ModifiedAfter_Value = new System.Windows.Forms.DateTimePicker();
   this.ModifiedAfter_Check = new System.Windows.Forms.CheckBox();
   this.ModifiedBefore_Value = new System.Windows.Forms.DateTimePicker();
   this.ModifiedBefore_Check = new System.Windows.Forms.CheckBox();
   this.CreatedAfter_Value = new System.Windows.Forms.DateTimePicker();
   this.CreatedAfter_Check = new System.Windows.Forms.CheckBox();
   this.CreatedBefore_Value = new System.Windows.Forms.DateTimePicker();
   this.CreatedBefore_Check = new System.Windows.Forms.CheckBox();
   this.MachineName_Value = new System.Windows.Forms.TextBox();
   this.MachineName_Check = new System.Windows.Forms.CheckBox();
   this.Label_Value = new System.Windows.Forms.TextBox();
   this.Label_Check = new System.Windows.Forms.CheckBox();
   this.Category_Value = new System.Windows.Forms.TextBox();
   this.Category_Check = new System.Windows.Forms.CheckBox();
   this.groupBox2 = new System.Windows.Forms.GroupBox();
   this.GetPublicQueuesByMachine = new System.Windows.Forms.Button();
   this.GetPublicQueuesByLabel = new System.Windows.Forms.Button();
   this.GetPublicQueuesByCategory = new System.Windows.Forms.Button();
   this.GetPublicQueues = new System.Windows.Forms.Button();
   this.GetPrivateQueuesByMachine = new System.Windows.Forms.Button();
   this.GetMessageQueueEnumerator = new System.Windows.Forms.Button();
   this.GetMachineId = new System.Windows.Forms.Button();
   this.label1 = new System.Windows.Forms.Label();
   this.Input = new System.Windows.Forms.TextBox();
   this.groupBox1.SuspendLayout();
   this.output_groupBox.SuspendLayout();
   this.mqfilter.SuspendLayout();
   this.groupBox2.SuspendLayout();
   this.SuspendLayout();
   // 
   // groupBox1
   // 
   this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                        this.transactional,
                                                                        this.Delete,
                                                                        this.Exists,
                                                                        this.Create,
                                                                        this.path_label,
                                                                        this.path});
   this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
   this.groupBox1.ForeColor = System.Drawing.Color.Green;
   this.groupBox1.Name = "groupBox1";
   this.groupBox1.Size = new System.Drawing.Size(752, 64);
   this.groupBox1.TabIndex = 0;
   this.groupBox1.TabStop = false;
   this.groupBox1.Text = "Queue Properties";
   // 
   // transactional
   // 
   this.transactional.ForeColor = System.Drawing.Color.Red;
   this.transactional.Location = new System.Drawing.Point(288, 24);
   this.transactional.Name = "transactional";
   this.transactional.TabIndex = 15;
   this.transactional.Text = "transactional";
   // 
   // Delete
   // 
   this.Delete.Location = new System.Drawing.Point(632, 24);
   this.Delete.Name = "Delete";
   this.Delete.Size = new System.Drawing.Size(104, 23);
   this.Delete.TabIndex = 4;
   this.Delete.Text = "Delete";
   this.Delete.Click += new System.EventHandler(this.Delete_Click);
   // 
   // Exists
   // 
   this.Exists.Location = new System.Drawing.Point(520, 24);
   this.Exists.Name = "Exists";
   this.Exists.Size = new System.Drawing.Size(96, 23);
   this.Exists.TabIndex = 3;
   this.Exists.Text = "Exists";
   this.Exists.Click += new System.EventHandler(this.Exists_Click);
   // 
   // Create
   // 
   this.Create.Location = new System.Drawing.Point(400, 24);
   this.Create.Name = "Create";
   this.Create.Size = new System.Drawing.Size(104, 23);
   this.Create.TabIndex = 2;
   this.Create.Text = "Create";
   this.Create.Click += new System.EventHandler(this.Create_Click);
   // 
   // path_label
   // 
   this.path_label.Location = new System.Drawing.Point(8, 24);
   this.path_label.Name = "path_label";
   this.path_label.Size = new System.Drawing.Size(48, 23);
   this.path_label.TabIndex = 1;
   this.path_label.Text = "Path";
   // 
   // path
   // 
   this.path.Location = new System.Drawing.Point(72, 24);
   this.path.Name = "path";
   this.path.Size = new System.Drawing.Size(208, 20);
   this.path.TabIndex = 0;
   this.path.Text = ".\\private$\\myfirstprivateq";
   // 
   // statusBar
   // 
   this.statusBar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
   this.statusBar.Location = new System.Drawing.Point(0, 447);
   this.statusBar.Name = "statusBar";
   this.statusBar.Size = new System.Drawing.Size(752, 22);
   this.statusBar.TabIndex = 1;
   // 
   // output_groupBox
   // 
   this.output_groupBox.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                              this.ClearAll,
                                                                              this.output});
   this.output_groupBox.Dock = System.Windows.Forms.DockStyle.Right;
   this.output_groupBox.Location = new System.Drawing.Point(592, 64);
   this.output_groupBox.Name = "output_groupBox";
   this.output_groupBox.Size = new System.Drawing.Size(160, 383);
   this.output_groupBox.TabIndex = 2;
   this.output_groupBox.TabStop = false;
   this.output_groupBox.Text = "Output";
   // 
   // ClearAll
   // 
   this.ClearAll.ForeColor = System.Drawing.SystemColors.Desktop;
   this.ClearAll.Location = new System.Drawing.Point(32, 336);
   this.ClearAll.Name = "ClearAll";
   this.ClearAll.Size = new System.Drawing.Size(104, 23);
   this.ClearAll.TabIndex = 3;
   this.ClearAll.Text = "Clear";
   this.ClearAll.Click += new System.EventHandler(this.ClearAll_Click);
   // 
   // output
   // 
   this.output.ForeColor = System.Drawing.Color.Red;
   this.output.Location = new System.Drawing.Point(3, 16);
   this.output.Multiline = true;
   this.output.Name = "output";
   this.output.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
   this.output.Size = new System.Drawing.Size(154, 304);
   this.output.TabIndex = 0;
   this.output.Text = "";
   // 
   // mqfilter
   // 
   this.mqfilter.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                       this.UseMQCriteria,
                                                                       this.ModifiedAfter_Value,
                                                                       this.ModifiedAfter_Check,
                                                                       this.ModifiedBefore_Value,
                                                                       this.ModifiedBefore_Check,
                                                                       this.CreatedAfter_Value,
                                                                       this.CreatedAfter_Check,
                                                                       this.CreatedBefore_Value,
                                                                       this.CreatedBefore_Check,
                                                                       this.MachineName_Value,
                                                                       this.MachineName_Check,
                                                                       this.Label_Value,
                                                                       this.Label_Check,
                                                                       this.Category_Value,
                                                                       this.Category_Check});
   this.mqfilter.ForeColor = System.Drawing.SystemColors.ActiveCaption;
   this.mqfilter.Location = new System.Drawing.Point(224, 64);
   this.mqfilter.Name = "mqfilter";
   this.mqfilter.Size = new System.Drawing.Size(360, 384);
   this.mqfilter.TabIndex = 3;
   this.mqfilter.TabStop = false;
   this.mqfilter.Text = "MessageQueueCriteria";
   // 
   // UseMQCriteria
   // 
   this.UseMQCriteria.ForeColor = System.Drawing.Color.Red;
   this.UseMQCriteria.Location = new System.Drawing.Point(96, 336);
   this.UseMQCriteria.Name = "UseMQCriteria";
   this.UseMQCriteria.Size = new System.Drawing.Size(176, 24);
   this.UseMQCriteria.TabIndex = 14;
   this.UseMQCriteria.Text = "Use MessageQueueCriteria";
   // 
   // ModifiedAfter_Value
   // 
   this.ModifiedAfter_Value.Location = new System.Drawing.Point(152, 296);
   this.ModifiedAfter_Value.Name = "ModifiedAfter_Value";
   this.ModifiedAfter_Value.TabIndex = 13;
   // 
   // ModifiedAfter_Check
   // 
   this.ModifiedAfter_Check.Location = new System.Drawing.Point(152, 264);
   this.ModifiedAfter_Check.Name = "ModifiedAfter_Check";
   this.ModifiedAfter_Check.Size = new System.Drawing.Size(120, 24);
   this.ModifiedAfter_Check.TabIndex = 12;
   this.ModifiedAfter_Check.Text = "ModifiedAfter";
   // 
   // ModifiedBefore_Value
   // 
   this.ModifiedBefore_Value.Location = new System.Drawing.Point(152, 216);
   this.ModifiedBefore_Value.Name = "ModifiedBefore_Value";
   this.ModifiedBefore_Value.TabIndex = 11;
   // 
   // ModifiedBefore_Check
   // 
   this.ModifiedBefore_Check.Location = new System.Drawing.Point(152, 184);
   this.ModifiedBefore_Check.Name = "ModifiedBefore_Check";
   this.ModifiedBefore_Check.Size = new System.Drawing.Size(120, 24);
   this.ModifiedBefore_Check.TabIndex = 10;
   this.ModifiedBefore_Check.Text = "ModifiedBefore";
   // 
   // CreatedAfter_Value
   // 
   this.CreatedAfter_Value.Location = new System.Drawing.Point(152, 136);
   this.CreatedAfter_Value.Name = "CreatedAfter_Value";
   this.CreatedAfter_Value.TabIndex = 9;
   // 
   // CreatedAfter_Check
   // 
   this.CreatedAfter_Check.Location = new System.Drawing.Point(152, 104);
   this.CreatedAfter_Check.Name = "CreatedAfter_Check";
   this.CreatedAfter_Check.Size = new System.Drawing.Size(120, 24);
   this.CreatedAfter_Check.TabIndex = 8;
   this.CreatedAfter_Check.Text = "CreatedAfter";
   // 
   // CreatedBefore_Value
   // 
   this.CreatedBefore_Value.Location = new System.Drawing.Point(152, 56);
   this.CreatedBefore_Value.Name = "CreatedBefore_Value";
   this.CreatedBefore_Value.TabIndex = 7;
   // 
   // CreatedBefore_Check
   // 
   this.CreatedBefore_Check.Location = new System.Drawing.Point(152, 24);
   this.CreatedBefore_Check.Name = "CreatedBefore_Check";
   this.CreatedBefore_Check.Size = new System.Drawing.Size(120, 24);
   this.CreatedBefore_Check.TabIndex = 6;
   this.CreatedBefore_Check.Text = "CreatedBefore";
   // 
   // MachineName_Value
   // 
   this.MachineName_Value.Location = new System.Drawing.Point(8, 216);
   this.MachineName_Value.Name = "MachineName_Value";
   this.MachineName_Value.Size = new System.Drawing.Size(128, 20);
   this.MachineName_Value.TabIndex = 5;
   this.MachineName_Value.Text = "localhost";
   // 
   // MachineName_Check
   // 
   this.MachineName_Check.Location = new System.Drawing.Point(8, 184);
   this.MachineName_Check.Name = "MachineName_Check";
   this.MachineName_Check.Size = new System.Drawing.Size(120, 24);
   this.MachineName_Check.TabIndex = 4;
   this.MachineName_Check.Text = "MachineName";
   // 
   // Label_Value
   // 
   this.Label_Value.Location = new System.Drawing.Point(8, 136);
   this.Label_Value.Name = "Label_Value";
   this.Label_Value.Size = new System.Drawing.Size(128, 20);
   this.Label_Value.TabIndex = 3;
   this.Label_Value.Text = "";
   // 
   // Label_Check
   // 
   this.Label_Check.Location = new System.Drawing.Point(8, 112);
   this.Label_Check.Name = "Label_Check";
   this.Label_Check.Size = new System.Drawing.Size(120, 16);
   this.Label_Check.TabIndex = 2;
   this.Label_Check.Text = "Label";
   // 
   // Category_Value
   // 
   this.Category_Value.Location = new System.Drawing.Point(8, 56);
   this.Category_Value.Name = "Category_Value";
   this.Category_Value.Size = new System.Drawing.Size(128, 20);
   this.Category_Value.TabIndex = 1;
   this.Category_Value.Text = "";
   // 
   // Category_Check
   // 
   this.Category_Check.Location = new System.Drawing.Point(8, 24);
   this.Category_Check.Name = "Category_Check";
   this.Category_Check.Size = new System.Drawing.Size(120, 24);
   this.Category_Check.TabIndex = 0;
   this.Category_Check.Text = "Category";
   // 
   // groupBox2
   // 
   this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                        this.GetPublicQueuesByMachine,
                                                                        this.GetPublicQueuesByLabel,
                                                                        this.GetPublicQueuesByCategory,
                                                                        this.GetPublicQueues,
                                                                        this.GetPrivateQueuesByMachine,
                                                                        this.GetMessageQueueEnumerator,
                                                                        this.GetMachineId,
                                                                        this.Input,
                                                                        this.label1});
   this.groupBox2.ForeColor = System.Drawing.Color.Maroon;
   this.groupBox2.Location = new System.Drawing.Point(8, 64);
   this.groupBox2.Name = "groupBox2";
   this.groupBox2.Size = new System.Drawing.Size(208, 384);
   this.groupBox2.TabIndex = 4;
   this.groupBox2.TabStop = false;
   this.groupBox2.Text = "Static Methods";
   // 
   // GetPublicQueuesByMachine
   // 
   this.GetPublicQueuesByMachine.Location = new System.Drawing.Point(8, 344);
   this.GetPublicQueuesByMachine.Name = "GetPublicQueuesByMachine";
   this.GetPublicQueuesByMachine.Size = new System.Drawing.Size(192, 23);
   this.GetPublicQueuesByMachine.TabIndex = 12;
   this.GetPublicQueuesByMachine.Text = "GetPublicQueuesByMachine";
   this.GetPublicQueuesByMachine.Click += new System.EventHandler(this.GetPublicQueuesByMachine_Click);
   // 
   // GetPublicQueuesByLabel
   // 
   this.GetPublicQueuesByLabel.Location = new System.Drawing.Point(8, 304);
   this.GetPublicQueuesByLabel.Name = "GetPublicQueuesByLabel";
   this.GetPublicQueuesByLabel.Size = new System.Drawing.Size(192, 23);
   this.GetPublicQueuesByLabel.TabIndex = 11;
   this.GetPublicQueuesByLabel.Text = "GetPublicQueuesByLabel";
   this.GetPublicQueuesByLabel.Click += new System.EventHandler(this.GetPublicQueuesByLabel_Click);
   // 
   // GetPublicQueuesByCategory
   // 
   this.GetPublicQueuesByCategory.Location = new System.Drawing.Point(8, 264);
   this.GetPublicQueuesByCategory.Name = "GetPublicQueuesByCategory";
   this.GetPublicQueuesByCategory.Size = new System.Drawing.Size(192, 23);
   this.GetPublicQueuesByCategory.TabIndex = 10;
   this.GetPublicQueuesByCategory.Text = "GetPublicQueuesByCategory";
   this.GetPublicQueuesByCategory.Click += new System.EventHandler(this.GetPublicQueuesByCategory_Click);
   // 
   // GetPublicQueues
   // 
   this.GetPublicQueues.Location = new System.Drawing.Point(8, 224);
   this.GetPublicQueues.Name = "GetPublicQueues";
   this.GetPublicQueues.Size = new System.Drawing.Size(192, 23);
   this.GetPublicQueues.TabIndex = 9;
   this.GetPublicQueues.Text = "GetPublicQueues";
   this.GetPublicQueues.Click += new System.EventHandler(this.GetPublicQueues_Click);
   // 
   // GetPrivateQueuesByMachine
   // 
   this.GetPrivateQueuesByMachine.Location = new System.Drawing.Point(8, 184);
   this.GetPrivateQueuesByMachine.Name = "GetPrivateQueuesByMachine";
   this.GetPrivateQueuesByMachine.Size = new System.Drawing.Size(192, 23);
   this.GetPrivateQueuesByMachine.TabIndex = 8;
   this.GetPrivateQueuesByMachine.Text = "GetPrivateQueuesByMachine";
   this.GetPrivateQueuesByMachine.Click += new System.EventHandler(this.GetPrivateQueuesByMachine_Click);
   // 
   // GetMessageQueueEnumerator
   // 
   this.GetMessageQueueEnumerator.Location = new System.Drawing.Point(8, 144);
   this.GetMessageQueueEnumerator.Name = "GetMessageQueueEnumerator";
   this.GetMessageQueueEnumerator.Size = new System.Drawing.Size(192, 23);
   this.GetMessageQueueEnumerator.TabIndex = 7;
   this.GetMessageQueueEnumerator.Text = "GetMessageQueueEnumerator";
   this.GetMessageQueueEnumerator.Click += new System.EventHandler(this.GetMessageQueueEnumerator_Click);
   // 
   // GetMachineId
   // 
   this.GetMachineId.Location = new System.Drawing.Point(8, 104);
   this.GetMachineId.Name = "GetMachineId";
   this.GetMachineId.Size = new System.Drawing.Size(192, 24);
   this.GetMachineId.TabIndex = 5;
   this.GetMachineId.Text = "GetMachineId";
   this.GetMachineId.Click += new System.EventHandler(this.GetMachineId_Click);
   // 
   // label1
   // 
   this.label1.ForeColor = System.Drawing.Color.Green;
   this.label1.Location = new System.Drawing.Point(8, 32);
   this.label1.Name = "label1";
   this.label1.Size = new System.Drawing.Size(192, 16);
   this.label1.TabIndex = 8;
   this.label1.Text = "MachineName, GUID, Label";
   // 
   // Input
   // 
   this.Input.Location = new System.Drawing.Point(8, 56);
   this.Input.Name = "Input";
   this.Input.Size = new System.Drawing.Size(192, 20);
   this.Input.TabIndex = 7;
   this.Input.Text = "localhost";
   // 
   // MessageQueueOperations
   // 
   this.AutoScaleBaseSize = new System.Drawing.Size(6, 13);
   this.ClientSize = new System.Drawing.Size(752, 469);
   this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                              this.groupBox2,
                                                              this.mqfilter,
                                                              this.output_groupBox,
                                                              this.statusBar,
                                                              this.groupBox1});
   this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
   this.Name = "MessageQueueOperations";
   this.Text = "MessageQueueOperations Console";
   this.groupBox1.ResumeLayout(false);
   this.output_groupBox.ResumeLayout(false);
   this.mqfilter.ResumeLayout(false);
   this.groupBox2.ResumeLayout(false);
   this.ResumeLayout(false);

  }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MessageQueueOperations());
		}

  private void Create_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    MessageQueue.Create(path.Text.Trim(), transactional.Checked);
    this.statusBar.Text = "Queue created successfully";
   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }
  }

  private void Exists_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    this.output.Text = MessageQueue.Exists(path.Text.Trim()).ToString();
   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }
  }

  private void Delete_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    MessageQueue.Delete(path.Text.Trim());
    this.statusBar.Text = "Queue deleted successfully";
   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }
  }

  private void GetMachineId_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    this.output.Text = MessageQueue.GetMachineId(this.Input.Text.Trim()).ToString();
   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }
  }

  private void GetMessageQueueEnumerator_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    MessageQueueEnumerator en;
    if(this.UseMQCriteria.Checked)
    {
     MessageQueueCriteria mqc = this.GetMessageQueueCriteria();
     en = MessageQueue.GetMessageQueueEnumerator(mqc);
    }
    else
     en = MessageQueue.GetMessageQueueEnumerator();

    this.EnumerateOverMessageQueueEnumerator(en);
   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }


  }


  private void EnumerateOverMessageQueueEnumerator(MessageQueueEnumerator en)
  {

   while(en.MoveNext())
   {
    MessageQueue mq = en.Current;
    this.output.AppendText("------------------------------------");
    this.output.AppendText("\r\n");
    this.output.AppendText("Path = " + mq.Path);
    this.output.AppendText("\r\n");
    this.output.AppendText("FormatName = " + mq.FormatName);
    this.output.AppendText("\r\n");
    this.output.AppendText("------------------------------------");
    this.output.AppendText("\r\n");

   }

  }
  private MessageQueueCriteria GetMessageQueueCriteria()
  {
   MessageQueueCriteria mqc = new MessageQueueCriteria();
   
   if(this.Category_Check.Checked)
    mqc.Category = new System.Guid(this.Category_Value.Text.Trim());
   
   if(this.Label_Check.Checked)
    mqc.Label = this.Label_Value.Text.Trim();

   if(this.MachineName_Check.Checked)
    mqc.MachineName = this.MachineName_Value.Text.Trim();

   if(this.CreatedAfter_Check.Checked)
    mqc.CreatedAfter = this.CreatedAfter_Value.Value;

   if(this.CreatedBefore_Check.Checked)
    mqc.CreatedBefore = this.CreatedBefore_Value.Value;

   if(this.ModifiedAfter_Check.Checked)
    mqc.ModifiedAfter = this.ModifiedAfter_Value.Value;

   if(this.ModifiedBefore_Check.Checked)
    mqc.ModifiedBefore = this.ModifiedBefore_Value.Value;

   return mqc;


  }

  private void DisplayMessageQueueArray(MessageQueue[] mqArray)
  {
   this.output.Clear();
   this.statusBar.Text = "";
   foreach(MessageQueue mq in mqArray)
   {
    this.output.AppendText("------------------------------------");
    this.output.AppendText("\r\n");
    this.output.AppendText("Path = " + mq.Path);
    this.output.AppendText("\r\n");
    this.output.AppendText("FormatName = " + mq.FormatName);
    this.output.AppendText("\r\n");
    this.output.AppendText("------------------------------------");
    this.output.AppendText("\r\n");
   }


  }

  private void GetPublicQueues_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    MessageQueue[] mqArray;
    if(this.UseMQCriteria.Checked)
    {
     MessageQueueCriteria mqc = this.GetMessageQueueCriteria();
     mqArray = MessageQueue.GetPublicQueues(mqc);
    }
    else
     mqArray = MessageQueue.GetPublicQueues();

    this.DisplayMessageQueueArray(mqArray);
   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }

  }

  private void GetPublicQueuesByMachine_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    MessageQueue[] mqArray = 
     MessageQueue.GetPrivateQueuesByMachine(this.Input.Text.Trim());
    this.DisplayMessageQueueArray(mqArray);

   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }
  
  }

  private void GetPublicQueuesByLabel_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    MessageQueue[] mqArray = 
     MessageQueue.GetPublicQueuesByLabel(this.Input.Text.Trim());
    this.DisplayMessageQueueArray(mqArray);

   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }
  }

  private void GetPublicQueuesByCategory_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    MessageQueue[] mqArray = 
     MessageQueue.GetPublicQueuesByCategory(new System.Guid(this.Input.Text.Trim()));
    this.DisplayMessageQueueArray(mqArray);

   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }

  }

  private void GetPrivateQueuesByMachine_Click(object sender, System.EventArgs e)
  {
   try
   {
    this.output.Clear();
    this.statusBar.Text = "";
    MessageQueue[] mqArray = 
     MessageQueue.GetPrivateQueuesByMachine(this.Input.Text.Trim());
    DisplayMessageQueueArray(mqArray);
   }
   catch(Exception ex)
   {
    this.statusBar.Text = ex.Message;
   }

  }

  private void ClearAll_Click(object sender, System.EventArgs e)
  {
   this.output.Clear();
   this.statusBar.Text = "";
	  this.UseMQCriteria.Checked = false;
	  this.transactional.Checked = false;
   this.Category_Check.Checked = false;
   this.Label_Check.Checked = false;
   this.MachineName_Check.Checked = false;
  }

 
 

 
	}
}
