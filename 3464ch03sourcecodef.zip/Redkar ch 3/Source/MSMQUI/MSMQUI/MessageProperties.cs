using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MSMQUI
{
	/// <summary>
	/// Summary description for MessageProperties.
	/// </summary>
	public class MessageProperties : System.Windows.Forms.Form
	{
   private System.Windows.Forms.GroupBox groupBox1;
   private System.Windows.Forms.GroupBox Formatters;
   private System.Windows.Forms.RadioButton BinaryFormatter;
   private System.Windows.Forms.RadioButton ActiveXFormatter;
   private System.Windows.Forms.RadioButton XmlFormatter;
   private System.Windows.Forms.GroupBox groupBox2;
   private System.Windows.Forms.RadioButton radioButton1;
   private System.Windows.Forms.RadioButton radioButton2;
   private System.Windows.Forms.Label label1;
   private System.Windows.Forms.ComboBox comboBox1;
   private System.Windows.Forms.GroupBox groupBox3;
   private System.Windows.Forms.TextBox timeToReach;
   private System.Windows.Forms.TextBox timeToReceive;
   private System.Windows.Forms.RadioButton radioButton3;
   private System.Windows.Forms.Label label2;
   private System.Windows.Forms.Label label3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MessageProperties()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
    this.groupBox1 = new System.Windows.Forms.GroupBox();
    this.Formatters = new System.Windows.Forms.GroupBox();
    this.BinaryFormatter = new System.Windows.Forms.RadioButton();
    this.ActiveXFormatter = new System.Windows.Forms.RadioButton();
    this.XmlFormatter = new System.Windows.Forms.RadioButton();
    this.groupBox2 = new System.Windows.Forms.GroupBox();
    this.radioButton1 = new System.Windows.Forms.RadioButton();
    this.radioButton2 = new System.Windows.Forms.RadioButton();
    this.label1 = new System.Windows.Forms.Label();
    this.comboBox1 = new System.Windows.Forms.ComboBox();
    this.groupBox3 = new System.Windows.Forms.GroupBox();
    this.timeToReach = new System.Windows.Forms.TextBox();
    this.timeToReceive = new System.Windows.Forms.TextBox();
    this.radioButton3 = new System.Windows.Forms.RadioButton();
    this.label2 = new System.Windows.Forms.Label();
    this.label3 = new System.Windows.Forms.Label();
    this.groupBox1.SuspendLayout();
    this.Formatters.SuspendLayout();
    this.groupBox2.SuspendLayout();
    this.groupBox3.SuspendLayout();
    this.SuspendLayout();
    // 
    // groupBox1
    // 
    this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.groupBox3,
                                                                          this.groupBox2,
                                                                          this.Formatters});
    this.groupBox1.Location = new System.Drawing.Point(8, 16);
    this.groupBox1.Name = "groupBox1";
    this.groupBox1.Size = new System.Drawing.Size(336, 392);
    this.groupBox1.TabIndex = 0;
    this.groupBox1.TabStop = false;
    // 
    // Formatters
    // 
    this.Formatters.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                           this.BinaryFormatter,
                                                                           this.ActiveXFormatter,
                                                                           this.XmlFormatter});
    this.Formatters.Location = new System.Drawing.Point(8, 24);
    this.Formatters.Name = "Formatters";
    this.Formatters.Size = new System.Drawing.Size(320, 112);
    this.Formatters.TabIndex = 8;
    this.Formatters.TabStop = false;
    this.Formatters.Text = "Formatters";
    // 
    // BinaryFormatter
    // 
    this.BinaryFormatter.Location = new System.Drawing.Point(8, 80);
    this.BinaryFormatter.Name = "BinaryFormatter";
    this.BinaryFormatter.Size = new System.Drawing.Size(240, 24);
    this.BinaryFormatter.TabIndex = 2;
    this.BinaryFormatter.Text = "BinaryMessageFormatter";
    // 
    // ActiveXFormatter
    // 
    this.ActiveXFormatter.Location = new System.Drawing.Point(8, 56);
    this.ActiveXFormatter.Name = "ActiveXFormatter";
    this.ActiveXFormatter.Size = new System.Drawing.Size(248, 24);
    this.ActiveXFormatter.TabIndex = 1;
    this.ActiveXFormatter.Text = "ActiveXMessageFormatter";
    // 
    // XmlFormatter
    // 
    this.XmlFormatter.Checked = true;
    this.XmlFormatter.Location = new System.Drawing.Point(8, 32);
    this.XmlFormatter.Name = "XmlFormatter";
    this.XmlFormatter.Size = new System.Drawing.Size(208, 24);
    this.XmlFormatter.TabIndex = 0;
    this.XmlFormatter.TabStop = true;
    this.XmlFormatter.Text = "XmlMessageFormatter";
    // 
    // groupBox2
    // 
    this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.comboBox1,
                                                                          this.label1,
                                                                          this.radioButton2,
                                                                          this.radioButton1});
    this.groupBox2.Location = new System.Drawing.Point(8, 136);
    this.groupBox2.Name = "groupBox2";
    this.groupBox2.Size = new System.Drawing.Size(320, 72);
    this.groupBox2.TabIndex = 9;
    this.groupBox2.TabStop = false;
    // 
    // radioButton1
    // 
    this.radioButton1.Location = new System.Drawing.Point(8, 16);
    this.radioButton1.Name = "radioButton1";
    this.radioButton1.Size = new System.Drawing.Size(96, 24);
    this.radioButton1.TabIndex = 3;
    this.radioButton1.Text = "Recoverabe";
    // 
    // radioButton2
    // 
    this.radioButton2.Location = new System.Drawing.Point(8, 40);
    this.radioButton2.Name = "radioButton2";
    this.radioButton2.Size = new System.Drawing.Size(72, 24);
    this.radioButton2.TabIndex = 4;
    this.radioButton2.Text = "Express";
    // 
    // label1
    // 
    this.label1.Location = new System.Drawing.Point(144, 16);
    this.label1.Name = "label1";
    this.label1.TabIndex = 5;
    this.label1.Text = "Priority";
    // 
    // comboBox1
    // 
    this.comboBox1.Items.AddRange(new object[] {
                                                 "0",
                                                 "1",
                                                 "2",
                                                 "3",
                                                 "4",
                                                 "5",
                                                 "6",
                                                 "7"});
    this.comboBox1.Location = new System.Drawing.Point(144, 40);
    this.comboBox1.Name = "comboBox1";
    this.comboBox1.Size = new System.Drawing.Size(121, 24);
    this.comboBox1.TabIndex = 6;
    this.comboBox1.Text = "3";
    // 
    // groupBox3
    // 
    this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.label3,
                                                                          this.label2,
                                                                          this.radioButton3,
                                                                          this.timeToReceive,
                                                                          this.timeToReach});
    this.groupBox3.Location = new System.Drawing.Point(8, 216);
    this.groupBox3.Name = "groupBox3";
    this.groupBox3.Size = new System.Drawing.Size(320, 112);
    this.groupBox3.TabIndex = 10;
    this.groupBox3.TabStop = false;
    this.groupBox3.Text = "Timers";
    // 
    // timeToReach
    // 
    this.timeToReach.Location = new System.Drawing.Point(192, 24);
    this.timeToReach.Name = "timeToReach";
    this.timeToReach.Size = new System.Drawing.Size(120, 22);
    this.timeToReach.TabIndex = 0;
    this.timeToReach.Text = "";
    // 
    // timeToReceive
    // 
    this.timeToReceive.Location = new System.Drawing.Point(192, 56);
    this.timeToReceive.Name = "timeToReceive";
    this.timeToReceive.Size = new System.Drawing.Size(120, 22);
    this.timeToReceive.TabIndex = 1;
    this.timeToReceive.Text = "";
    // 
    // radioButton3
    // 
    this.radioButton3.Location = new System.Drawing.Point(192, 80);
    this.radioButton3.Name = "radioButton3";
    this.radioButton3.Size = new System.Drawing.Size(120, 24);
    this.radioButton3.TabIndex = 5;
    this.radioButton3.Text = "Use Dead-letter";
    // 
    // label2
    // 
    this.label2.Location = new System.Drawing.Point(8, 24);
    this.label2.Name = "label2";
    this.label2.Size = new System.Drawing.Size(176, 23);
    this.label2.TabIndex = 6;
    this.label2.Text = "Time To Reach(secs)";
    // 
    // label3
    // 
    this.label3.Location = new System.Drawing.Point(8, 56);
    this.label3.Name = "label3";
    this.label3.Size = new System.Drawing.Size(176, 23);
    this.label3.TabIndex = 7;
    this.label3.Text = "Time To Receive(secs)";
    // 
    // MessageProperties
    // 
    this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
    this.ClientSize = new System.Drawing.Size(352, 416);
    this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                this.groupBox1});
    this.Name = "MessageProperties";
    this.Text = "MessageProperties";
    this.groupBox1.ResumeLayout(false);
    this.Formatters.ResumeLayout(false);
    this.groupBox2.ResumeLayout(false);
    this.groupBox3.ResumeLayout(false);
    this.ResumeLayout(false);

  }
		#endregion
	}
}
