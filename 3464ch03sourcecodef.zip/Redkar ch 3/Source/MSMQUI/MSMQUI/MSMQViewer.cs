using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MSMQUI
{
	/// <summary>
	/// Summary description for MSMQViewer.
	/// </summary>
	public class MSMQViewer : System.Windows.Forms.Form
	{
   private System.Windows.Forms.TabControl tabControl1;
   private System.Windows.Forms.StatusBar statusBar1;
   private System.Windows.Forms.MainMenu mainMenu1;
   private System.Windows.Forms.MenuItem menuItem1;
   private System.Windows.Forms.MenuItem menuItem2;
   private System.Windows.Forms.MenuItem menuItem3;
   private System.Windows.Forms.MenuItem menuItem4;
   private System.Windows.Forms.MenuItem menuItem5;
   private System.Windows.Forms.TabPage messageQ;
   private System.Windows.Forms.TabPage SendMessage;
   private System.Windows.Forms.TabPage ReceiveMessage;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MSMQViewer()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
    this.tabControl1 = new System.Windows.Forms.TabControl();
    this.statusBar1 = new System.Windows.Forms.StatusBar();
    this.mainMenu1 = new System.Windows.Forms.MainMenu();
    this.menuItem1 = new System.Windows.Forms.MenuItem();
    this.menuItem2 = new System.Windows.Forms.MenuItem();
    this.menuItem3 = new System.Windows.Forms.MenuItem();
    this.menuItem4 = new System.Windows.Forms.MenuItem();
    this.menuItem5 = new System.Windows.Forms.MenuItem();
    this.messageQ = new System.Windows.Forms.TabPage();
    this.SendMessage = new System.Windows.Forms.TabPage();
    this.ReceiveMessage = new System.Windows.Forms.TabPage();
    this.tabControl1.SuspendLayout();
    this.SuspendLayout();
    // 
    // tabControl1
    // 
    this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.messageQ,
                                                                            this.SendMessage,
                                                                            this.ReceiveMessage});
    this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
    this.tabControl1.Name = "tabControl1";
    this.tabControl1.SelectedIndex = 0;
    this.tabControl1.Size = new System.Drawing.Size(632, 384);
    this.tabControl1.TabIndex = 0;
    // 
    // statusBar1
    // 
    this.statusBar1.Location = new System.Drawing.Point(0, 362);
    this.statusBar1.Name = "statusBar1";
    this.statusBar1.Size = new System.Drawing.Size(632, 22);
    this.statusBar1.TabIndex = 1;
    this.statusBar1.Text = "statusBar1";
    // 
    // mainMenu1
    // 
    this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.menuItem1,
                                                                            this.menuItem3,
                                                                            this.menuItem5});
    // 
    // menuItem1
    // 
    this.menuItem1.Index = 0;
    this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.menuItem2});
    this.menuItem1.Text = "&File";
    // 
    // menuItem2
    // 
    this.menuItem2.Index = 0;
    this.menuItem2.Text = "E&xit";
    // 
    // menuItem3
    // 
    this.menuItem3.Index = 1;
    this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.menuItem4});
    this.menuItem3.Text = "&Message";
    // 
    // menuItem4
    // 
    this.menuItem4.Index = 0;
    this.menuItem4.Text = "&Properties";
    // 
    // menuItem5
    // 
    this.menuItem5.Index = 2;
    this.menuItem5.Text = "MSM&Q";
    // 
    // messageQ
    // 
    this.messageQ.Location = new System.Drawing.Point(4, 25);
    this.messageQ.Name = "messageQ";
    this.messageQ.Size = new System.Drawing.Size(624, 355);
    this.messageQ.TabIndex = 0;
    this.messageQ.Text = "Message Queue";
    // 
    // SendMessage
    // 
    this.SendMessage.Location = new System.Drawing.Point(4, 25);
    this.SendMessage.Name = "SendMessage";
    this.SendMessage.Size = new System.Drawing.Size(624, 355);
    this.SendMessage.TabIndex = 1;
    this.SendMessage.Text = "Send Message";
    // 
    // ReceiveMessage
    // 
    this.ReceiveMessage.Location = new System.Drawing.Point(4, 25);
    this.ReceiveMessage.Name = "ReceiveMessage";
    this.ReceiveMessage.Size = new System.Drawing.Size(624, 355);
    this.ReceiveMessage.TabIndex = 2;
    this.ReceiveMessage.Text = "Receive/Peek Messages";
    // 
    // MSMQViewer
    // 
    this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
    this.ClientSize = new System.Drawing.Size(632, 384);
    this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                this.statusBar1,
                                                                this.tabControl1});
    this.Menu = this.mainMenu1;
    this.Name = "MSMQViewer";
    this.Text = "MSMQViewer";
    this.tabControl1.ResumeLayout(false);
    this.ResumeLayout(false);

  }
		#endregion
	}
}
