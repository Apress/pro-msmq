using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Messaging;

namespace MSMQUI
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Messaging.MessageQueue messageQueue1;
		private System.Windows.Forms.Label label4;
   private System.Windows.Forms.TextBox MessageLabel;
   private System.Windows.Forms.TextBox MessageBody;
   private System.Windows.Forms.TextBox SendPath;
   private System.Windows.Forms.Button SendMessage;
   private System.Windows.Forms.Button Clear;
   private System.Windows.Forms.Button ReceiveMessage;
   private System.Windows.Forms.TextBox ReceivePath;
   private System.Windows.Forms.TextBox Output;
   private System.Windows.Forms.Button PeekMessage;
   private System.Windows.Forms.Button GetAllMessages;
   private System.Windows.Forms.Button Purge;
   private System.Windows.Forms.GroupBox SendMessageGrp;
   private System.Windows.Forms.GroupBox Formatters;
   private System.Windows.Forms.RadioButton XmlFormatter;
   private System.Windows.Forms.RadioButton ActiveXFormatter;
   private System.Windows.Forms.RadioButton BinaryFormatter;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
    this.groupBox2 = new System.Windows.Forms.GroupBox();
    this.GetAllMessages = new System.Windows.Forms.Button();
    this.PeekMessage = new System.Windows.Forms.Button();
    this.Clear = new System.Windows.Forms.Button();
    this.ReceiveMessage = new System.Windows.Forms.Button();
    this.label3 = new System.Windows.Forms.Label();
    this.ReceivePath = new System.Windows.Forms.TextBox();
    this.Output = new System.Windows.Forms.TextBox();
    this.statusBar1 = new System.Windows.Forms.StatusBar();
    this.SendMessageGrp = new System.Windows.Forms.GroupBox();
    this.Purge = new System.Windows.Forms.Button();
    this.label4 = new System.Windows.Forms.Label();
    this.MessageLabel = new System.Windows.Forms.TextBox();
    this.label2 = new System.Windows.Forms.Label();
    this.SendMessage = new System.Windows.Forms.Button();
    this.MessageBody = new System.Windows.Forms.TextBox();
    this.SendPath = new System.Windows.Forms.TextBox();
    this.messageQueue1 = new System.Messaging.MessageQueue();
    this.Formatters = new System.Windows.Forms.GroupBox();
    this.XmlFormatter = new System.Windows.Forms.RadioButton();
    this.ActiveXFormatter = new System.Windows.Forms.RadioButton();
    this.BinaryFormatter = new System.Windows.Forms.RadioButton();
    this.groupBox2.SuspendLayout();
    this.SendMessageGrp.SuspendLayout();
    this.Formatters.SuspendLayout();
    this.SuspendLayout();
    // 
    // groupBox2
    // 
    this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.GetAllMessages,
                                                                          this.PeekMessage,
                                                                          this.Clear,
                                                                          this.ReceiveMessage,
                                                                          this.label3,
                                                                          this.ReceivePath,
                                                                          this.Output});
    this.groupBox2.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.groupBox2.ForeColor = System.Drawing.Color.Blue;
    this.groupBox2.Location = new System.Drawing.Point(471, 0);
    this.groupBox2.Name = "groupBox2";
    this.groupBox2.Size = new System.Drawing.Size(502, 434);
    this.groupBox2.TabIndex = 1;
    this.groupBox2.TabStop = false;
    this.groupBox2.Text = "Receive/Peek Message Synchronously";
    // 
    // GetAllMessages
    // 
    this.GetAllMessages.ForeColor = System.Drawing.Color.Blue;
    this.GetAllMessages.Location = new System.Drawing.Point(176, 384);
    this.GetAllMessages.Name = "GetAllMessages";
    this.GetAllMessages.Size = new System.Drawing.Size(164, 40);
    this.GetAllMessages.TabIndex = 8;
    this.GetAllMessages.Text = "GetAllMessages";
    this.GetAllMessages.Click += new System.EventHandler(this.GetAllMessages_Click);
    // 
    // PeekMessage
    // 
    this.PeekMessage.ForeColor = System.Drawing.Color.Blue;
    this.PeekMessage.Location = new System.Drawing.Point(352, 384);
    this.PeekMessage.Name = "PeekMessage";
    this.PeekMessage.Size = new System.Drawing.Size(136, 40);
    this.PeekMessage.TabIndex = 7;
    this.PeekMessage.Text = "Peek ";
    this.PeekMessage.Click += new System.EventHandler(this.PeekMessage_Click);
    // 
    // Clear
    // 
    this.Clear.ForeColor = System.Drawing.Color.Blue;
    this.Clear.Location = new System.Drawing.Point(389, 280);
    this.Clear.Name = "Clear";
    this.Clear.Size = new System.Drawing.Size(103, 40);
    this.Clear.TabIndex = 6;
    this.Clear.Text = "Clear";
    this.Clear.Click += new System.EventHandler(this.Clear_Click);
    // 
    // ReceiveMessage
    // 
    this.ReceiveMessage.ForeColor = System.Drawing.Color.Blue;
    this.ReceiveMessage.Location = new System.Drawing.Point(8, 384);
    this.ReceiveMessage.Name = "ReceiveMessage";
    this.ReceiveMessage.Size = new System.Drawing.Size(152, 40);
    this.ReceiveMessage.TabIndex = 5;
    this.ReceiveMessage.Text = "Receive";
    this.ReceiveMessage.Click += new System.EventHandler(this.ReceiveMessage_Click);
    // 
    // label3
    // 
    this.label3.Location = new System.Drawing.Point(236, 286);
    this.label3.Name = "label3";
    this.label3.Size = new System.Drawing.Size(133, 29);
    this.label3.TabIndex = 4;
    this.label3.Text = "Queue Path";
    // 
    // ReceivePath
    // 
    this.ReceivePath.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.ReceivePath.ForeColor = System.Drawing.SystemColors.WindowText;
    this.ReceivePath.Location = new System.Drawing.Point(8, 286);
    this.ReceivePath.Name = "ReceivePath";
    this.ReceivePath.Size = new System.Drawing.Size(216, 34);
    this.ReceivePath.TabIndex = 3;
    this.ReceivePath.Text = ".\\private$\\myfirstq";
    // 
    // Output
    // 
    this.Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.Output.Location = new System.Drawing.Point(8, 30);
    this.Output.Multiline = true;
    this.Output.Name = "Output";
    this.Output.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
    this.Output.Size = new System.Drawing.Size(480, 246);
    this.Output.TabIndex = 2;
    this.Output.Text = "";
    // 
    // statusBar1
    // 
    this.statusBar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.statusBar1.Location = new System.Drawing.Point(0, 433);
    this.statusBar1.Name = "statusBar1";
    this.statusBar1.Size = new System.Drawing.Size(983, 27);
    this.statusBar1.TabIndex = 2;
    // 
    // SendMessageGrp
    // 
    this.SendMessageGrp.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                               this.Formatters,
                                                                               this.Purge,
                                                                               this.label4,
                                                                               this.MessageLabel,
                                                                               this.label2,
                                                                               this.SendMessage,
                                                                               this.MessageBody,
                                                                               this.SendPath});
    this.SendMessageGrp.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.SendMessageGrp.ForeColor = System.Drawing.Color.DarkGreen;
    this.SendMessageGrp.Location = new System.Drawing.Point(20, 0);
    this.SendMessageGrp.Name = "SendMessageGrp";
    this.SendMessageGrp.Size = new System.Drawing.Size(441, 434);
    this.SendMessageGrp.TabIndex = 3;
    this.SendMessageGrp.TabStop = false;
    this.SendMessageGrp.Text = "Send Message";
    // 
    // Purge
    // 
    this.Purge.ForeColor = System.Drawing.Color.Green;
    this.Purge.Location = new System.Drawing.Point(280, 384);
    this.Purge.Name = "Purge";
    this.Purge.Size = new System.Drawing.Size(154, 39);
    this.Purge.TabIndex = 6;
    this.Purge.Text = "Purge";
    this.Purge.Click += new System.EventHandler(this.Purge_Click);
    // 
    // label4
    // 
    this.label4.Location = new System.Drawing.Point(287, 79);
    this.label4.Name = "label4";
    this.label4.Size = new System.Drawing.Size(128, 39);
    this.label4.TabIndex = 5;
    this.label4.Text = "Label";
    // 
    // MessageLabel
    // 
    this.MessageLabel.Font = new System.Drawing.Font("Comic Sans MS", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.MessageLabel.Location = new System.Drawing.Point(8, 79);
    this.MessageLabel.Name = "MessageLabel";
    this.MessageLabel.Size = new System.Drawing.Size(264, 31);
    this.MessageLabel.TabIndex = 4;
    this.MessageLabel.Text = "Message Label";
    // 
    // label2
    // 
    this.label2.Location = new System.Drawing.Point(287, 39);
    this.label2.Name = "label2";
    this.label2.Size = new System.Drawing.Size(128, 29);
    this.label2.TabIndex = 3;
    this.label2.Text = "Queue Path";
    // 
    // SendMessage
    // 
    this.SendMessage.ForeColor = System.Drawing.Color.Green;
    this.SendMessage.Location = new System.Drawing.Point(128, 384);
    this.SendMessage.Name = "SendMessage";
    this.SendMessage.Size = new System.Drawing.Size(144, 39);
    this.SendMessage.TabIndex = 2;
    this.SendMessage.Text = "Send Message";
    this.SendMessage.Click += new System.EventHandler(this.SendMessage_Click);
    // 
    // MessageBody
    // 
    this.MessageBody.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.MessageBody.Location = new System.Drawing.Point(8, 128);
    this.MessageBody.Multiline = true;
    this.MessageBody.Name = "MessageBody";
    this.MessageBody.ScrollBars = System.Windows.Forms.ScrollBars.Both;
    this.MessageBody.Size = new System.Drawing.Size(424, 99);
    this.MessageBody.TabIndex = 1;
    this.MessageBody.Text = "My Message";
    // 
    // SendPath
    // 
    this.SendPath.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.SendPath.Location = new System.Drawing.Point(8, 39);
    this.SendPath.Name = "SendPath";
    this.SendPath.Size = new System.Drawing.Size(264, 34);
    this.SendPath.TabIndex = 0;
    this.SendPath.Text = ".\\private$\\myfirstq";
    // 
    // messageQueue1
    // 
    this.messageQueue1.SynchronizingObject = this;
    // 
    // Formatters
    // 
    this.Formatters.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                           this.BinaryFormatter,
                                                                           this.ActiveXFormatter,
                                                                           this.XmlFormatter});
    this.Formatters.Location = new System.Drawing.Point(8, 232);
    this.Formatters.Name = "Formatters";
    this.Formatters.Size = new System.Drawing.Size(272, 112);
    this.Formatters.TabIndex = 7;
    this.Formatters.TabStop = false;
    this.Formatters.Text = "Formatters";
    // 
    // XmlFormatter
    // 
    this.XmlFormatter.Checked = true;
    this.XmlFormatter.Location = new System.Drawing.Point(8, 32);
    this.XmlFormatter.Name = "XmlFormatter";
    this.XmlFormatter.Size = new System.Drawing.Size(208, 24);
    this.XmlFormatter.TabIndex = 0;
    this.XmlFormatter.TabStop = true;
    this.XmlFormatter.Text = "XmlMessageFormatter";
    // 
    // ActiveXFormatter
    // 
    this.ActiveXFormatter.Location = new System.Drawing.Point(8, 56);
    this.ActiveXFormatter.Name = "ActiveXFormatter";
    this.ActiveXFormatter.Size = new System.Drawing.Size(248, 24);
    this.ActiveXFormatter.TabIndex = 1;
    this.ActiveXFormatter.Text = "ActiveXMessageFormatter";
    // 
    // BinaryFormatter
    // 
    this.BinaryFormatter.Location = new System.Drawing.Point(8, 80);
    this.BinaryFormatter.Name = "BinaryFormatter";
    this.BinaryFormatter.Size = new System.Drawing.Size(240, 24);
    this.BinaryFormatter.TabIndex = 2;
    this.BinaryFormatter.Text = "BinaryMessageFormatter";
    // 
    // Form1
    // 
    this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
    this.ClientSize = new System.Drawing.Size(983, 460);
    this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                this.SendMessageGrp,
                                                                this.statusBar1,
                                                                this.groupBox2});
    this.Name = "Form1";
    this.Text = "MSMQUI";
    this.groupBox2.ResumeLayout(false);
    this.SendMessageGrp.ResumeLayout(false);
    this.Formatters.ResumeLayout(false);
    this.ResumeLayout(false);

  }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void SendMessage_Click(object sender, System.EventArgs e)
		{
			try 
			{
				statusBar1.Text = "";

				//Set the Path property of the messageQueue1 object
				messageQueue1.Path = SendPath.Text.Trim ();

     //messageQueue1.Formatter = GetMessageFormatter();
     System.Messaging.Message msg = 
       new System.Messaging.Message((string)MessageBody.Text.Trim(),
       GetMessageFormatter());

					msg.UseTracing = true;

				//Send the message to the queue
					messageQueue1.Send (msg, this.MessageLabel.Text.Trim() );

				statusBar1.Text = "FormatName = " + messageQueue1.FormatName;	

			}
			catch(MessageQueueException ex)
			{
				statusBar1.Text = "";
				statusBar1.Text = ex.Message;

			}
			catch(Exception ex1)
			{

				statusBar1.Text = "";
				statusBar1.Text = ex1.Message;

			}
			



		}

		private void ReceiveMessage_Click(object sender, System.EventArgs e)
		{
			statusBar1.Text = "";
 
			try 
			{

				messageQueue1.Path = ReceivePath.Text.Trim();
				System.Messaging.Message msq = 
      messageQueue1.Receive (new TimeSpan(0, 0, 2));
   // msq.Formatter = new XmlMessageFormatter(new Type[]{typeof(System.String)});
     msq.Formatter = GetMessageFormatter();
     Output.AppendText("--------------------\r\n");
     Output.AppendText("Receive Operation\r\n");
     Output.AppendText("Body = " + msq.Body.ToString());
     Output.AppendText("\r\n");
     Output.AppendText("Id = " + msq.Id);
     Output.AppendText("\r\n--------------------\r\n");
				statusBar1.Text = "FormatName = " + messageQueue1.FormatName;	

			}
			catch(MessageQueueException ex)
			{

				statusBar1.Text = "";
				statusBar1.Text = ex.Message;

			}
			catch(Exception ex1)
			{

				statusBar1.Text = "";
				statusBar1.Text = ex1.Message;

			}
            
		}

		private void Clear_Click(object sender, System.EventArgs e)
		{
			Output.Clear();
		}

   private void PeekMessage_Click(object sender, System.EventArgs e)
   {
     statusBar1.Text = "";
 
     try 
     {

       messageQueue1.Path = ReceivePath.Text.Trim();
       System.Messaging.Message msq = 
         messageQueue1.Peek(new TimeSpan(0, 0, 2));
       msq.Formatter = new XmlMessageFormatter
         (new Type[]{typeof(System.String)});
       Output.AppendText("--------------------\r\n");
       Output.AppendText("Peek Operation\r\n");
       Output.AppendText("Body = " + (string)msq.Body);
       Output.AppendText("\r\n");
       Output.AppendText("Id = " + msq.Id);
       Output.AppendText("\r\n--------------------\r\n");
       statusBar1.Text = "FormatName = " 
         + messageQueue1.FormatName;	

     }
     catch(MessageQueueException ex)
     {
       statusBar1.Text = "";

        if(ex.MessageQueueErrorCode
          .Equals(MessageQueueErrorCode.IOTimeout))
          statusBar1.Text = "Queue is Empty";
        else
          statusBar1.Text = ex.Message;

     }
     catch(Exception ex1)
     {

       statusBar1.Text = "";
       statusBar1.Text = ex1.Message;

     }
   }

   private void GetAllMessages_Click(object sender, System.EventArgs e)
   {
     statusBar1.Text = "";
 
     try 
     {

       messageQueue1.Path = ReceivePath.Text.Trim();
       messageQueue1.Formatter = new XmlMessageFormatter
         (new Type[]{typeof(System.String)});
       System.Messaging.Message[] msqs = 
         messageQueue1.GetAllMessages();
       Output.AppendText("GetAllMessages Operation\r\n");
       foreach(System.Messaging.Message msq in msqs)
       {
         Output.AppendText("--------------------\r\n");
         Output.AppendText("Body = " + (string)msq.Body);
         Output.AppendText("\r\n");
         Output.AppendText("Id = " + msq.Id);
         Output.AppendText("\r\n--------------------\r\n");
       }
       
     }
     catch(MessageQueueException ex)
     {
       statusBar1.Text = "";

       if(ex.MessageQueueErrorCode
         .Equals(MessageQueueErrorCode.IOTimeout))
         statusBar1.Text = "Queue is Empty";
       else
         statusBar1.Text = ex.Message;

     }
     catch(Exception ex1)
     {

       statusBar1.Text = "";
       statusBar1.Text = ex1.Message;

     }
   }

   private void Purge_Click(object sender, System.EventArgs e)
   {
     try 
     {
       statusBar1.Text = "";

       //Set the Path property of the messageQueue1 object
       messageQueue1.Path = SendPath.Text.Trim ();

     	 messageQueue1.Purge();

     }
     catch(MessageQueueException ex)
     {
       statusBar1.Text = "";
       statusBar1.Text = ex.Message;

     }
     catch(Exception ex1)
     {

       statusBar1.Text = "";
       statusBar1.Text = ex1.Message;

     }
   }

   private IMessageFormatter GetMessageFormatter()
   {
    
     if(this.ActiveXFormatter.Checked)
       return new ActiveXMessageFormatter();
     else if(this.BinaryFormatter.Checked)
       return new BinaryMessageFormatter();
     else
       return new XmlMessageFormatter
         (new Type[]{typeof(System.String)}); 
   }
	}
}
