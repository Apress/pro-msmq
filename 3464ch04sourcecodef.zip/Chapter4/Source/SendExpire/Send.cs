using System;
using System.Messaging;

namespace SendExpire
{
	class Send
	{
		static void Main(string[] args)
		{
    if(args.Length >= 1)
    {
      try
      {
        if(!MessageQueue.Exists(args[0]))
        {
          MessageQueue.Create(args[0], true);
          Console.WriteLine("Queue was not registered,"+ 
            "so new queue created for you");

        }
        MessageQueue q = new MessageQueue
          (args[0]);
        using(MessageQueueTransaction mTx = 
                new MessageQueueTransaction())
        {
          mTx.Begin();
          try
          {
            for(int i = 0 ; i < 10 ; i++)
            {
              System.Messaging.Message m = 
                new System.Messaging.Message("Message " + i);
              m.TimeToBeReceived = new TimeSpan(0, 0, 3);
              m.UseDeadLetterQueue = true;
              q.Send(m, i.ToString(), mTx);
             

            }
            mTx.Commit();
            Console.WriteLine("Messages sent successfully");

          }
          catch(MessageQueueException mx)
          {
            mTx.Abort();
            Console.WriteLine
              ("Exception while sending transactional messages, " 
              + "aborting transaction. Error Code = " 
              + mx.MessageQueueErrorCode.ToString() 
              + ". Error Message " + mx.Message);

          }
        }
     
     
      }
      catch(Exception ex)
      {
        Console.WriteLine
          ("Exception " + ex.Message);
      }
			
    }
    else
    {
      Console.WriteLine
        ("Usage:SendExpire [Path of the queue]");
    }
		}
	}
}
