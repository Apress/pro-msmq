using System;
using System.EnterpriseServices;
using System.Data.SqlClient;
using System.Data;
using System.Messaging;

namespace OrderProcessingComponent
{
  [Transaction(TransactionOption.Required)]
	public class OrderProcessing : System.EnterpriseServices.ServicedComponent
	{
    private String _orderConStr = 
"server=(local);uid=order;pwd=pass;database=OrderProcessingSystem";
    private String _logConStr = 
      "server=(local);uid=order;pwd=pass;database=SystemLog";
    private MessageQueue _q;
    private String _qPath = @".\private$\pendingorderq";
		public OrderProcessing()
		{
			 if(!MessageQueue.Exists(this._qPath))
      this._q = MessageQueue.Create(this._qPath, true);
    else
      this._q = new MessageQueue(this._qPath);
		}

    [AutoComplete()]
    public void InsertOrder
      (String orderID, String customerName, String item, int quantity)
    {
      System.Messaging.Message or = new System.Messaging.Message
        (new Wrox.Order(orderID, customerName, item, quantity));
       this._q.Send(or, orderID, MessageQueueTransactionType.Automatic);
      SqlConnection order = new SqlConnection(this._orderConStr);
      SqlConnection log = new SqlConnection(this._logConStr);
      try
      {
        order.Open();
        log.Open();
        SqlCommand insertOrder  = new SqlCommand();
        SqlCommand insertLog = new SqlCommand();
        DateTime dt = DateTime.Now;
        insertOrder.CommandType = CommandType.StoredProcedure;
        insertOrder.CommandText = "InsertOrder";
        insertOrder.Connection = order;
        insertOrder.Parameters.Add
          (new SqlParameter("@OrderID_1", orderID));
        insertOrder.Parameters.Add(new SqlParameter
          ("@CustomerName_2", customerName));
        insertOrder.Parameters.Add(new SqlParameter
          ("@OrderTime_3", dt));
        insertOrder.Parameters.Add(new SqlParameter
          ("@Item_4", item));
        insertOrder.Parameters.Add(new SqlParameter
          ("@Quantity_5", quantity));
        int status = 1;
        insertOrder.Parameters.Add(new SqlParameter
          ("@Status_6", status));
        insertOrder.ExecuteNonQuery();
        insertLog.CommandType = CommandType.StoredProcedure;
        insertLog.CommandText = "InsertOrderLog";
        insertLog.Connection = log;
        insertLog.Parameters.Add
          (new SqlParameter("@OrderID_1", orderID));
        insertLog.Parameters.Add(new SqlParameter
          ("@OrderReceivedTime_2", dt));
        insertLog.ExecuteNonQuery();
      }
      finally
      {
        order.Close();
        log.Close();
      }
    }
	}
}
