using System;
using System.Messaging;

namespace ViewDeadLetterMessages
{
  //FormatName:DIRECT=OS:10.1.48.67\SYSTEM$;DEADXACT
  //MachineName\ XactDeadletter$
  //FormatName:DIRECT=AddressSpecification\SYSTEM$;DEADXACT  
  class Receive
  {
    static void Main(string[] args)
    {
      if(args.Length >= 1)
      {
        try
        {
          MessageQueue q = new MessageQueue
            (args[0]);
          q.Formatter = new XmlMessageFormatter
            (new String[]{"System.String"});

        
            try
            {
              for(int i = 0 ; i < 10 ; i++)
              {
                 Message m = q.Receive
                  (new TimeSpan(0, 0, 3));
                 Console.WriteLine(m.Label + " " + m.Body);
              }
             
            }
            catch(MessageQueueException mx)
            {
              //mTx.Abort();
              Console.WriteLine
                ("Exception while receiving transactional messages, " 
                + "aborting transaction. Error Code = " 
                + mx.MessageQueueErrorCode.ToString() 
                + ". Error Message " + mx.Message);

            }
             
     
        }
        catch(Exception ex)
        {
          Console.WriteLine
            ("Exception " + ex.Message);
        }
			
      }
      else
      {
        Console.WriteLine
          ("Usage:ViewDeadLetterMessages [Path of the dead-letter queue]");
      }
    }
  }
}
