using System;

namespace Wrox
{
	[Serializable]
	public class Order
	{
   private String _orderID;
   private String _customerName;
   private String _item;
   private int _qty;

		public Order()
		{
			
		}
   public Order (String orderID, String customerName, String item, int qty)
   {
     this._orderID = orderID;
     this._customerName = customerName;
     this._item = item;
     this._qty = qty;
   }
   public String OrderID
   {
     get
     {
       return this._orderID;
     }
     set
     {
       this._orderID = value;
     }

   }


   public String CustomerName
   {
     get
     {
       return this._customerName;
     }
     set
     {
       this._customerName = value;
     }
   }

   public String Item
   {
     get
     {
       return this._item;
     }
     set
     {
       this._item = value;
     }
   }

   public int Quantity
   {
     get
     {
       return this._qty;
     }
     set
     {
       this._qty = value;
     }
   }
	}
}
