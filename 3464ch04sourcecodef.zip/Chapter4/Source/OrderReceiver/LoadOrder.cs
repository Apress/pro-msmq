using System;

namespace OrderLoader
{
	
  public class LoadOrder
  {
    public LoadOrder()
    {
			
    }
    static void Main(string[] args)
    {
      try
      {
        OrderProcessingComponent.OrderProcessing order = 
          new OrderProcessingComponent.OrderProcessing();
        string orderid ="1";
        if(args[0].Length > 0)
          orderid = args[0];

        order.InsertOrder
          (orderid, "TestCustomer", "TestItem", 1);
      }
      catch(Exception ex)
      {
        Console.WriteLine(ex.Message);
      }
    }
   
  }
}
