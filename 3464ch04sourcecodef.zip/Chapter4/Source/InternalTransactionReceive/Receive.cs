using System;
using System.Messaging;

namespace InternalTransactionReceive
{
  class Receive
  {
    static void Main(string[] args)
    {
      if(args.Length >= 1)
      {
        try
        {
          MessageQueue q = new MessageQueue
            (args[0]);
          q.Formatter = new XmlMessageFormatter
            (new String[]{"System.String"});

          using(MessageQueueTransaction mTx = 
                  new MessageQueueTransaction())
          {
            mTx.Begin();
            try
            {
              for(int i = 0 ; i < 10 ; i++)
              {
                 Message m = q.Receive
                  (new TimeSpan(0, 0, 3), mTx);
                 Console.WriteLine(m.Label + " " + m.Body);
              }
              mTx.Commit();
            }
            catch(MessageQueueException mx)
            {
              mTx.Abort();
              Console.WriteLine
                ("Exception while receiving transactional messages, " 
                + "aborting transaction. Error Code = " 
                + mx.MessageQueueErrorCode.ToString() 
                + ". Error Message " + mx.Message);

            }
          }
     
     
        }
        catch(Exception ex)
        {
          Console.WriteLine
            ("Exception " + ex.Message);
        }
			
      }
      else
      {
        Console.WriteLine
          ("Usage:InternalTransactionReceive [Path of the queue]");
      }
    }
  }
}
