using System;
using System.Messaging;

namespace SingleTransaction
{
	class Send
	{
		static void Main(string[] args)
		{
    if(args.Length >= 1)
    {
     try
     {
      if(!MessageQueue.Exists(args[0]))
      {
       MessageQueue.Create(args[0], true);
       Console.WriteLine("Queue was not registered,"+ 
        "so new queue created for you");

      }
      MessageQueue q = new MessageQueue
       (args[0]);
       
      try
      {
       for(int i = 0 ; i < 10 ; i++)
       {
              
        q.Send("Message " + i, i.ToString(), MessageQueueTransactionType.Single);
             

       }
           
       Console.WriteLine("Messages sent successfully");

      }
      catch(MessageQueueException mx)
      {
            
       Console.WriteLine
        ("Exception while sending transactional messages, " 
        + "aborting transaction. Error Code = " 
        + mx.MessageQueueErrorCode.ToString() 
        + ". Error Message " + mx.Message);

      }
        
     
     
     }
     catch(Exception ex)
     {
      Console.WriteLine
       ("Exception " + ex.Message);
     }
			
    }
    else
    {
      Console.WriteLine
        ("Usage:InternalTransactionSend [Path of the queue]");
    }
		}
	}
}
